// App.tsx
import React from 'react'
import { ThemeProvider } from './src/theme/ThemeProvider'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClient } from './src/lib/queryClient'
import AppNavigator from './src/navigation/AppNavigator'

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AppNavigator />
      </ThemeProvider>
    </QueryClientProvider>
  )
}
