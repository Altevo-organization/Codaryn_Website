// src/navigation/types.ts

export type RootTabParamList = {
  Home: undefined
  Planning: undefined
  Dossier: undefined
  Messagerie: undefined
  Profil: undefined
}

export type DossierStackParamList = {
  PatientsList: undefined
  PatientDetail: { patientId?: number } | undefined
  PatientFiles: { patientId: number }
}


export type ProfileStackParamList = {
  Profil: undefined
  Settings: undefined
  PersonalInfo: undefined
  ProfessionalInfo: undefined
  Availability: undefined
  ChangePassword: undefined
  HelpCenter: undefined
  ContactSupport: undefined
  Legal: { type: 'terms' | 'privacy' }
}

export type MessagesStackParamList = {
  MessagesList: undefined
  MessageDetail: { messageId: number }
}

export type ChatStackParamList = {
  ConversationsList: undefined
  ChatScreen: {
    conversationId: string
    participantName: string
    participantId: number
  }
}
