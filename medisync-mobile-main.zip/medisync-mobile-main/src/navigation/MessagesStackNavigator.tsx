// src/navigation/MessagesStackNavigator.tsx
import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import MessagesListScreen from '../screens/messages/MessagesListScreen'
import MessageDetailScreen from '../screens/messages/MessageDetailScreen'
import { MessagesStackParamList } from './types'

const Stack = createNativeStackNavigator<MessagesStackParamList>()

export default function MessagesStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MessagesList" component={MessagesListScreen} />
      <Stack.Screen name="MessageDetail" component={MessageDetailScreen} />
    </Stack.Navigator>
  )
}
