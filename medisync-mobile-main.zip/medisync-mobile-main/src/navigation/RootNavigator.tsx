/**
 * RootNavigator - Modern Bottom Tab Navigation
 *
 * Redesigned with MediSync design system:
 * - Floating tab bar with blur effect
 * - Custom animated icons
 * - Smooth transitions
 */

import React from 'react';
import { View, Text, StyleSheet, Platform, TouchableOpacity } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import DashboardScreen from '../screens/home/HomeScreen';
import PlanningScreen from '../screens/planning/PlanningScreen';
import DossierStackNavigator from './DossierStackNavigator';
import ProfileStackNavigator from './ProfileStackNavigator';
import ChatStackNavigator from './ChatStackNavigator';

import { RootTabParamList } from './types';
import { useTheme, useIsDarkMode } from '../ui';
import { spacing, radius, shadows } from '../ui/theme';

const Tab = createBottomTabNavigator<RootTabParamList>();

// =============================================================================
// TYPES
// =============================================================================

type TabIconName = keyof typeof Ionicons.glyphMap;

interface TabConfig {
  iconFocused: TabIconName;
  iconUnfocused: TabIconName;
  label: string;
}

const TAB_CONFIG: Record<keyof RootTabParamList, TabConfig> = {
  Home: {
    iconFocused: 'home',
    iconUnfocused: 'home-outline',
    label: 'Accueil',
  },
  Planning: {
    iconFocused: 'calendar',
    iconUnfocused: 'calendar-outline',
    label: 'Planning',
  },
  Dossier: {
    iconFocused: 'people',
    iconUnfocused: 'people-outline',
    label: 'Patients',
  },
  Messagerie: {
    iconFocused: 'chatbubbles',
    iconUnfocused: 'chatbubbles-outline',
    label: 'Messages',
  },
  Profil: {
    iconFocused: 'person-circle',
    iconUnfocused: 'person-circle-outline',
    label: 'Profil',
  },
};

// =============================================================================
// CUSTOM TAB BAR
// =============================================================================

function CustomTabBar({ state, descriptors, navigation }: any) {
  const { colors } = useTheme();
  const isDark = useIsDarkMode();

  return (
    <View style={styles.tabBarWrapper}>
      <View
        style={[
          styles.tabBarContainer,
          {
            backgroundColor: isDark
              ? 'rgba(30, 30, 35, 0.95)'
              : 'rgba(255, 255, 255, 0.98)',
            borderColor: colors.border,
          },
        ]}
      >
        {state.routes.map((route: any, index: number) => {
          const { options } = descriptors[route.key];
          const isFocused = state.index === index;
          const config = TAB_CONFIG[route.name as keyof RootTabParamList];

          if (!config) return null;

          const onPress = () => {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          const onLongPress = () => {
            navigation.emit({
              type: 'tabLongPress',
              target: route.key,
            });
          };

          return (
            <TouchableOpacity
              key={route.key}
              style={styles.tabItem}
              accessibilityRole="button"
              accessibilityState={isFocused ? { selected: true } : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel || config.label}
              onPress={onPress}
              onLongPress={onLongPress}
              activeOpacity={0.7}
            >
              {/* Active indicator background */}
              {isFocused && (
                <View
                  style={[
                    styles.activeIndicator,
                    { backgroundColor: colors.primaryMuted },
                  ]}
                />
              )}

              {/* Icon */}
              <Ionicons
                name={isFocused ? config.iconFocused : config.iconUnfocused}
                size={22}
                color={isFocused ? colors.primary : colors.textTertiary}
                style={styles.tabIcon}
              />

              {/* Label */}
              <Text
                style={[
                  styles.tabLabel,
                  {
                    color: isFocused ? colors.primary : colors.textTertiary,
                    fontWeight: isFocused ? '600' : '500',
                  },
                ]}
                numberOfLines={1}
              >
                {config.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

// =============================================================================
// NAVIGATOR
// =============================================================================

export default function RootNavigator() {
  return (
    <Tab.Navigator
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{
        headerShown: false,
      }}
    >
      <Tab.Screen name="Home" component={DashboardScreen} />
      <Tab.Screen name="Planning" component={PlanningScreen} />
      <Tab.Screen name="Dossier" component={DossierStackNavigator} />
      <Tab.Screen name="Messagerie" component={ChatStackNavigator} />
      <Tab.Screen name="Profil" component={ProfileStackNavigator} />
    </Tab.Navigator>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  tabBarWrapper: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: spacing.lg,
    paddingBottom: Platform.OS === 'ios' ? spacing.xl : spacing.md,
  },
  tabBarContainer: {
    flexDirection: 'row',
    borderRadius: radius.xl,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.xs,
    borderWidth: 1,
    ...shadows.lg,
    overflow: 'hidden',
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    position: 'relative',
    minHeight: 52,
  },
  activeIndicator: {
    position: 'absolute',
    top: 4,
    left: '15%',
    right: '15%',
    bottom: 4,
    borderRadius: radius.lg,
  },
  tabIcon: {
    marginBottom: 2,
    zIndex: 1,
  },
  tabLabel: {
    fontSize: 11,
    marginTop: 2,
    textAlign: 'center',
    zIndex: 1,
  },
});
