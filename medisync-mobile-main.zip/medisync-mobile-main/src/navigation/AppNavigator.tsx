// src/navigation/AppNavigator.tsx
import React from 'react'
import RootNavigator from './RootNavigator'
import AuthStackNavigator from './AuthStackNavigator'
import { useAuthStore } from '../stores/authStore'

// 🔹 Auth activée pour la messagerie instantanée
const AUTH_ENABLED = true

export default function AppNavigator() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)

  if (!AUTH_ENABLED) {
    // Auth désactivée → on va toujours sur l'app principale
    return <RootNavigator />
  }

  if (!isAuthenticated) {
    return <AuthStackNavigator />
  }

  return <RootNavigator />
}
