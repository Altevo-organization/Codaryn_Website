// src/navigation/ChatStackNavigator.tsx
import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { ConversationsListScreen, ChatScreen } from '../screens/chat'
import { ChatStackParamList } from './types'
import { useTheme } from '../theme/ThemeProvider'

const Stack = createNativeStackNavigator<ChatStackParamList>()

export default function ChatStackNavigator() {
  const { colors } = useTheme()

  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        headerStyle: {
          backgroundColor: colors.card,
        },
        headerTintColor: colors.text,
        headerTitleStyle: {
          fontWeight: '600',
        },
      }}
    >
      <Stack.Screen name="ConversationsList" component={ConversationsListScreen} />
      <Stack.Screen
        name="ChatScreen"
        component={ChatScreen}
        options={{
          headerShown: true,
          headerBackTitle: 'Retour',
        }}
      />
    </Stack.Navigator>
  )
}
