import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import PatientsListScreen from '../screens/patients/PatientsListScreen'
import PatientDetailScreen from '../screens/patients/PatientDetailScreen'
import PatientFilesScreen from '../screens/patients/PatientFilesScreen'
import { DossierStackParamList } from './types'

const Stack = createNativeStackNavigator<DossierStackParamList>()

export default function DossierStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Patients" component={PatientsListScreen} />
      <Stack.Screen name="PatientDetail" component={PatientDetailScreen} />
      <Stack.Screen
  name="PatientFiles"
  component={PatientFilesScreen}
  options={{ title: 'Documents du patient' }}
/>

    </Stack.Navigator>
  )
}
