import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import ProfileScreen from '../screens/profile/ProfileScreen'
import SettingsScreen from '../screens/settings/SettingsScreen'
import PersonalInfoScreen from '../screens/profile/PersonalInfoScreen'
import ProfessionalInfoScreen from '../screens/profile/ProfessionalInfoScreen'
import AvailabilityScreen from '../screens/profile/AvailabilityScreen'
import ChangePasswordScreen from '../screens/profile/ChangePasswordScreen'
import HelpCenterScreen from '../screens/profile/HelpCenterScreen'
import ContactSupportScreen from '../screens/profile/ContactSupportScreen'
import LegalScreen from '../screens/profile/LegalScreen'
import { ProfileStackParamList } from './types'

const Stack = createNativeStackNavigator<ProfileStackParamList>()

export default function ProfileStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Profil" component={ProfileScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="PersonalInfo" component={PersonalInfoScreen} />
      <Stack.Screen name="ProfessionalInfo" component={ProfessionalInfoScreen} />
      <Stack.Screen name="Availability" component={AvailabilityScreen} />
      <Stack.Screen name="ChangePassword" component={ChangePasswordScreen} />
      <Stack.Screen name="HelpCenter" component={HelpCenterScreen} />
      <Stack.Screen name="ContactSupport" component={ContactSupportScreen} />
      <Stack.Screen name="Legal" component={LegalScreen} />
    </Stack.Navigator>
  )
}
