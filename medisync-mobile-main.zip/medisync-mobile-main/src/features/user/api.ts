// src/features/user/api.ts
import { api } from '../../lib/apiClient'
import type {
  UserProfile,
  UpdateProfileDto,
  ChangePasswordDto,
  CreateSupportRequestDto,
  SupportRequest,
} from './types'

// Standard API response structure
interface ApiResponse<T> {
  success: boolean
  message: string
  data?: T
  timestamp: string
}

/**
 * Fetch current user's full profile with all settings
 */
export async function fetchUserProfile(): Promise<UserProfile> {
  const res = await api.get<ApiResponse<UserProfile>>('/users/me')

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch profile')
  }

  return res.data.data
}

/**
 * Update user profile (partial update)
 */
export async function updateUserProfile(
  data: UpdateProfileDto
): Promise<UserProfile> {
  const res = await api.patch<ApiResponse<UserProfile>>('/users/me', data)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to update profile')
  }

  return res.data.data
}

/**
 * Change user password
 */
export async function changePassword(data: ChangePasswordDto): Promise<void> {
  const res = await api.patch<ApiResponse<void>>('/users/me/password', data)

  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to change password')
  }
}

/**
 * Submit a support request
 */
export async function submitSupportRequest(
  data: CreateSupportRequestDto
): Promise<SupportRequest> {
  const res = await api.post<ApiResponse<SupportRequest>>('/support', data)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to submit support request')
  }

  return res.data.data
}

/**
 * Get user's support requests
 */
export async function fetchSupportRequests(): Promise<SupportRequest[]> {
  const res = await api.get<ApiResponse<SupportRequest[]>>('/support')

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch support requests')
  }

  return res.data.data
}
