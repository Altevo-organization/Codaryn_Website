// User profile types matching backend

export interface TimeSlot {
  start: string // "08:00"
  end: string // "12:00"
}

export type DayOfWeek =
  | 'monday'
  | 'tuesday'
  | 'wednesday'
  | 'thursday'
  | 'friday'
  | 'saturday'
  | 'sunday'

export type AvailabilitySchedule = {
  [key in DayOfWeek]?: TimeSlot[]
}

export interface UserProfile {
  id: number
  firstName: string
  lastName: string
  email: string
  licenseNumber: string
  phone?: string
  specialization?: string
  // Personal info
  address?: string
  // Professional info
  rppsNumber?: string
  cabinetName?: string
  cabinetAddress?: string
  // Availability
  availability?: AvailabilitySchedule
  // Preferences - Appearance
  hapticsEnabled: boolean
  // Preferences - Notifications
  notifAppointments: boolean
  notifMessages: boolean
  notifReminders: boolean
  notifUpdates: boolean
  // Preferences - Privacy
  analyticsEnabled: boolean
  crashReportsEnabled: boolean
  // Preferences - Security
  biometricsEnabled: boolean
  // Status
  isActive: boolean
  lastLogin?: string
  createdAt: string
  updatedAt: string
}

// DTOs for updates
export interface UpdatePersonalInfoDto {
  firstName?: string
  lastName?: string
  phone?: string
  address?: string
}

export interface UpdateProfessionalInfoDto {
  rppsNumber?: string
  specialization?: string
  cabinetName?: string
  cabinetAddress?: string
}

export interface UpdateAvailabilityDto {
  availability: AvailabilitySchedule
}

export interface UpdatePreferencesDto {
  hapticsEnabled?: boolean
  notifAppointments?: boolean
  notifMessages?: boolean
  notifReminders?: boolean
  notifUpdates?: boolean
  analyticsEnabled?: boolean
  crashReportsEnabled?: boolean
  biometricsEnabled?: boolean
}

export interface UpdateProfileDto
  extends UpdatePersonalInfoDto,
    UpdateProfessionalInfoDto,
    UpdatePreferencesDto {
  availability?: AvailabilitySchedule
}

export interface ChangePasswordDto {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

export interface CreateSupportRequestDto {
  subject: string
  message: string
}

export interface SupportRequest {
  id: number
  nurseId: number
  subject: string
  message: string
  status: 'pending' | 'in_progress' | 'resolved' | 'closed'
  createdAt: string
  updatedAt: string
}
