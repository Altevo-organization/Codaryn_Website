// src/features/user/hooks.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  fetchUserProfile,
  updateUserProfile,
  changePassword,
  submitSupportRequest,
  fetchSupportRequests,
} from './api'
import type {
  UserProfile,
  UpdateProfileDto,
  ChangePasswordDto,
  CreateSupportRequestDto,
} from './types'

// Query keys
export const userKeys = {
  all: ['user'] as const,
  profile: () => [...userKeys.all, 'profile'] as const,
  support: () => [...userKeys.all, 'support'] as const,
}

/**
 * Hook to fetch current user's profile
 */
export function useUserProfile() {
  return useQuery({
    queryKey: userKeys.profile(),
    queryFn: fetchUserProfile,
    staleTime: 5 * 60 * 1000, // 5 minutes
  })
}

/**
 * Hook to update user profile
 */
export function useUpdateProfile() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (data: UpdateProfileDto) => updateUserProfile(data),
    onSuccess: (updatedProfile) => {
      // Update the cache with new profile data
      queryClient.setQueryData(userKeys.profile(), updatedProfile)
    },
  })
}

/**
 * Hook to change password
 */
export function useChangePassword() {
  return useMutation({
    mutationFn: (data: ChangePasswordDto) => changePassword(data),
  })
}

/**
 * Hook to submit support request
 */
export function useSubmitSupportRequest() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (data: CreateSupportRequestDto) => submitSupportRequest(data),
    onSuccess: () => {
      // Invalidate support requests cache
      queryClient.invalidateQueries({ queryKey: userKeys.support() })
    },
  })
}

/**
 * Hook to fetch support requests
 */
export function useSupportRequests() {
  return useQuery({
    queryKey: userKeys.support(),
    queryFn: fetchSupportRequests,
    staleTime: 5 * 60 * 1000,
  })
}

/**
 * Hook to update a single preference quickly
 */
export function useUpdatePreference() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (data: UpdateProfileDto) => updateUserProfile(data),
    // Optimistic update
    onMutate: async (newData) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey: userKeys.profile() })

      // Snapshot the previous value
      const previousProfile = queryClient.getQueryData<UserProfile>(
        userKeys.profile()
      )

      // Optimistically update
      if (previousProfile) {
        queryClient.setQueryData(userKeys.profile(), {
          ...previousProfile,
          ...newData,
        })
      }

      return { previousProfile }
    },
    // Rollback on error
    onError: (_err, _newData, context) => {
      if (context?.previousProfile) {
        queryClient.setQueryData(userKeys.profile(), context.previousProfile)
      }
    },
    // Refetch after success or error
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: userKeys.profile() })
    },
  })
}
