// src/features/files/fileAssignmentsStore.ts
// Store pour assigner les fichiers à des dossiers localement
// (le backend ne gère pas les dossiers pour l'instant)

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import AsyncStorage from '@react-native-async-storage/async-storage'

interface FileAssignmentsState {
  // Key: fileId, Value: folderId (null = racine)
  assignments: Record<number, string | null>

  // Actions
  assignFile: (fileId: number, folderId: string | null) => void
  removeAssignment: (fileId: number) => void
  getAssignment: (fileId: number) => string | null
  getFilesByFolder: (folderId: string | null, fileIds: number[]) => number[]
  moveFilesToRoot: (folderId: string) => void // When deleting a folder
}

export const useFileAssignmentsStore = create<FileAssignmentsState>()(
  persist(
    (set, get) => ({
      assignments: {},

      assignFile: (fileId, folderId) => {
        set((state) => ({
          assignments: {
            ...state.assignments,
            [fileId]: folderId,
          },
        }))
      },

      removeAssignment: (fileId) => {
        set((state) => {
          const { [fileId]: _, ...rest } = state.assignments
          return { assignments: rest }
        })
      },

      getAssignment: (fileId) => {
        return get().assignments[fileId] ?? null
      },

      getFilesByFolder: (folderId, fileIds) => {
        const { assignments } = get()
        return fileIds.filter((id) => {
          const assigned = assignments[id] ?? null
          return assigned === folderId
        })
      },

      moveFilesToRoot: (folderId) => {
        // When a folder is deleted, move all its files to root
        set((state) => {
          const newAssignments = { ...state.assignments }
          for (const [fileIdStr, assignedFolderId] of Object.entries(newAssignments)) {
            if (assignedFolderId === folderId) {
              newAssignments[Number(fileIdStr)] = null
            }
          }
          return { assignments: newAssignments }
        })
      },
    }),
    {
      name: 'medisync-file-assignments',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ assignments: state.assignments }),
    }
  )
)
