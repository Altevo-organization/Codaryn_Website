// src/features/files/api.ts
import { api } from '../../lib/apiClient'
// ⚠️ utiliser l’API legacy pour readAsStringAsync
import * as FileSystem from 'expo-file-system/legacy'
import type { FileItem, FileQuery, UploadFileInput } from './types'

interface PaginationMeta {
  currentPage: number
  totalPages: number
  totalItems: number
  itemsPerPage: number
  hasNext: boolean
  hasPrev: boolean
}

interface PaginatedResponse<T> {
  data: T[]
  pagination: PaginationMeta
}

interface ApiResponse<T = any> {
  success: boolean
  message: string
  data?: T
  error?: unknown
  timestamp: string
}

type FileApi = {
  id: number
  name: string
  type: string
  mimeType?: string
  size: number
  patientId?: number
  description?: string
  createdAt: string
  updatedAt: string
}

function mapFile(f: FileApi): FileItem {
  return {
    id: f.id,
    name: f.name,
    type: f.type,
    mimeType: f.mimeType,
    size: f.size,
    patientId: f.patientId,
    description: f.description,
    createdAt: f.createdAt,
    updatedAt: f.updatedAt,
  }
}

function buildQueryParams(query?: FileQuery): Record<string, unknown> {
  if (!query) return {}
  const params: Record<string, unknown> = {}
  if (query.page !== undefined) params.page = query.page
  if (query.limit !== undefined) params.limit = query.limit
  if (query.sortBy) params.sortBy = query.sortBy
  if (query.sortOrder) params.sortOrder = query.sortOrder
  if (query.patientId !== undefined) params.patientId = query.patientId
  if (query.type) params.type = query.type
  return params
}

// --- LISTE GLOBALE (si besoin plus tard) ---
export async function fetchFiles(
  query?: FileQuery,
): Promise<{ items: FileItem[]; pagination: PaginationMeta }> {
  const params = buildQueryParams(query)

  const res = await api.get<ApiResponse<PaginatedResponse<FileApi>>>(
    '/files',
    { params },
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch files')
  }

  return {
    items: res.data.data.data.map(mapFile),
    pagination: res.data.data.pagination,
  }
}

// --- LISTE PAR PATIENT ---
export async function fetchFilesByPatient(
  patientId: number,
  query?: FileQuery,
): Promise<{ items: FileItem[]; pagination: PaginationMeta }> {
  const params = buildQueryParams(query)

  const res = await api.get<ApiResponse<PaginatedResponse<FileApi>>>(
    `/files/patient/${patientId}`,
    { params },
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch patient files')
  }

  return {
    items: res.data.data.data.map(mapFile),
    pagination: res.data.data.pagination,
  }
}

// --- UPLOAD DEPUIS LE TÉLÉPHONE ---
const MAX_FILE_SIZE = 50 * 1024 * 1024 // 50MB

export async function uploadFileFromDevice(
  input: UploadFileInput,
): Promise<FileItem> {
  const { uri, name, mimeType, size, patientId, description } = input

  // 1. On récupère la taille exacte si besoin
  let finalSize = size ?? 0
  if (!finalSize || finalSize <= 0) {
    const info = await FileSystem.getInfoAsync(uri)
    if (!info.exists || typeof info.size !== 'number') {
      throw new Error("Impossible de lire la taille du fichier.")
    }
    finalSize = info.size
  }

  if (finalSize <= 0) {
    throw new Error('La taille du fichier doit être supérieure à 0.')
  }

  if (finalSize > MAX_FILE_SIZE) {
    throw new Error('Le fichier dépasse la taille maximale autorisée (50MB).')
  }

  if (!patientId || patientId <= 0) {
    throw new Error('Patient invalide pour ce fichier.')
  }

  // 2. Lecture en base64 (legacy API)
  const base64 = await FileSystem.readAsStringAsync(uri, {
    encoding: 'base64',
  })

  const logicalType: string =
    mimeType && mimeType.startsWith('application/pdf')
      ? 'PDF'
      : mimeType && mimeType.startsWith('image/')
        ? 'IMAGE'
        : 'OTHER'

  const payload = {
    name: name || 'document',
    type: logicalType,
    mimeType: mimeType ?? undefined,
    data: base64, // string base64 → convertDataToBuffer côté backend
    size: finalSize,
    patientId,
    description: description?.trim() || undefined,
  }

  const res = await api.post<ApiResponse<FileApi>>('/files', payload)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to upload file')
  }

  return mapFile(res.data.data)
}

// --- SUPPRESSION ---
export async function deleteFile(id: number): Promise<void> {
  const res = await api.delete<ApiResponse>(`/files/${id}`)

  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to delete file')
  }
}

// --- URL DE TÉLÉCHARGEMENT (pour ouvrir dans le navigateur / viewer natif) ---
export function buildDownloadUrl(fileId: number): string {
  // api.getUri permet de reconstruire l’URL complète basée sur baseURL
  return api.getUri({ url: `/files/${fileId}/download` })
}
