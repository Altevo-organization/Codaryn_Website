// src/features/files/types.ts

export type FileType = 'PDF' | 'IMAGE' | 'NOTE' | 'OTHER' | string

export interface FileItem {
  id: number
  name: string
  type: FileType
  mimeType?: string
  size: number
  patientId?: number
  folderId?: number | null // Parent folder (null = root)
  description?: string
  createdAt: string
  updatedAt: string
}

export interface FolderItem {
  id: string // Local unique ID (uuid or generated)
  name: string
  parentId: string | null // null = root
  patientId: number
  itemCount?: number // Optional count of items inside
  createdAt: string
  updatedAt: string
}

export interface FileQuery {
  page?: number
  limit?: number
  sortBy?: string
  sortOrder?: 'ASC' | 'DESC'
  patientId?: number
  type?: string
  folderId?: string | null // Filter by folder
}

// Pour l'upload depuis le téléphone
export interface UploadFileInput {
  uri: string
  name: string
  mimeType?: string | null
  size?: number | null
  patientId: number
  folderId?: string | null // Destination folder
  description?: string
}

// Sort options for documents view
export type SortOption = 'date-desc' | 'date-asc' | 'name-asc' | 'name-desc'

export interface SortConfig {
  sortBy: 'createdAt' | 'name'
  sortOrder: 'ASC' | 'DESC'
}

export const sortOptions: Record<SortOption, { label: string; config: SortConfig }> = {
  'date-desc': { label: 'Plus récent', config: { sortBy: 'createdAt', sortOrder: 'DESC' } },
  'date-asc': { label: 'Plus ancien', config: { sortBy: 'createdAt', sortOrder: 'ASC' } },
  'name-asc': { label: 'Nom (A→Z)', config: { sortBy: 'name', sortOrder: 'ASC' } },
  'name-desc': { label: 'Nom (Z→A)', config: { sortBy: 'name', sortOrder: 'DESC' } },
}
