// src/features/files/hooks.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  fetchFiles,
  fetchFilesByPatient,
  uploadFileFromDevice,
  deleteFile,
} from './api'
import type { FileQuery, UploadFileInput, FileItem } from './types'

export function usePatientFilesQuery(
  patientId: number,
  query?: FileQuery,
): {
  data?: FileItem[]
  isLoading: boolean
  error: unknown
  refetch: () => void
  isRefetching: boolean
} {
  const { data, isLoading, error, refetch, isRefetching } = useQuery({
    queryKey: ['files', 'patient', patientId, query],
    queryFn: async () => {
      const res = await fetchFilesByPatient(patientId, query)
      return res.items
    },
    enabled: !!patientId,
  })

  return {
    data,
    isLoading,
    error,
    refetch,
    isRefetching,
  }
}

export function useUploadFileMutation(patientId: number) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (input: Omit<UploadFileInput, 'patientId'>) =>
      uploadFileFromDevice({ ...input, patientId }),
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: ['files', 'patient', patientId],
      })
    },
  })
}

export function useDeleteFileMutation(patientId: number) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: number) => deleteFile(id),
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: ['files', 'patient', patientId],
      })
    },
  })
}

/**
 * Fichiers récents pour la page d’accueil
 */
export function useRecentFilesQuery(
  limit = 5,
): {
  data?: FileItem[]
  isLoading: boolean
  error: unknown
  refetch: () => void
  isRefetching: boolean
} {
  const { data, isLoading, error, refetch, isRefetching } = useQuery({
    queryKey: ['files', 'recent', { limit }],
    queryFn: async () => {
      const res = await fetchFiles({
        limit,
        sortBy: 'createdAt',
        sortOrder: 'DESC',
      })
      return res.items
    },
  })

  return {
    data,
    isLoading,
    error,
    refetch,
    isRefetching,
  }
}
