// src/features/files/foldersStore.ts
import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import AsyncStorage from '@react-native-async-storage/async-storage'
import type { FolderItem } from './types'

interface FoldersState {
  folders: Record<number, FolderItem[]> // Key: patientId

  // Actions
  getFoldersByPatient: (patientId: number) => FolderItem[]
  getFolderById: (patientId: number, folderId: string) => FolderItem | undefined
  getFoldersByParent: (patientId: number, parentId: string | null) => FolderItem[]
  getBreadcrumbPath: (patientId: number, folderId: string | null) => { id: string | null; name: string }[]

  createFolder: (patientId: number, name: string, parentId: string | null) => FolderItem
  deleteFolder: (patientId: number, folderId: string) => void
  renameFolder: (patientId: number, folderId: string, newName: string) => void
  moveFolder: (patientId: number, folderId: string, newParentId: string | null) => void

  getItemCount: (patientId: number, folderId: string, files: { folderId?: string | null }[]) => number
}

function generateId(): string {
  return `folder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

export const useFoldersStore = create<FoldersState>()(
  persist(
    (set, get) => ({
      folders: {},

      getFoldersByPatient: (patientId) => {
        return get().folders[patientId] ?? []
      },

      getFolderById: (patientId, folderId) => {
        const patientFolders = get().folders[patientId] ?? []
        return patientFolders.find((f) => f.id === folderId)
      },

      getFoldersByParent: (patientId, parentId) => {
        const patientFolders = get().folders[patientId] ?? []
        return patientFolders.filter((f) => f.parentId === parentId)
      },

      getBreadcrumbPath: (patientId, folderId) => {
        const path: { id: string | null; name: string }[] = [
          { id: null, name: 'Documents' },
        ]

        if (folderId === null) return path

        const patientFolders = get().folders[patientId] ?? []
        let currentId: string | null = folderId
        const visited = new Set<string>()

        while (currentId !== null) {
          if (visited.has(currentId)) break
          visited.add(currentId)

          const folder = patientFolders.find((f) => f.id === currentId)
          if (!folder) break

          path.push({ id: folder.id, name: folder.name })
          currentId = folder.parentId
        }

        // Reverse to get root-to-current order, but keep root first
        const [root, ...rest] = path
        return [root, ...rest.reverse()]
      },

      createFolder: (patientId, name, parentId) => {
        const now = new Date().toISOString()
        const newFolder: FolderItem = {
          id: generateId(),
          name: name.trim(),
          parentId,
          patientId,
          createdAt: now,
          updatedAt: now,
        }

        set((state) => ({
          folders: {
            ...state.folders,
            [patientId]: [...(state.folders[patientId] ?? []), newFolder],
          },
        }))

        return newFolder
      },

      deleteFolder: (patientId, folderId) => {
        const patientFolders = get().folders[patientId] ?? []

        // Get all descendant folder IDs (recursive)
        const getDescendants = (id: string): string[] => {
          const children = patientFolders.filter((f) => f.parentId === id)
          return [
            id,
            ...children.flatMap((child) => getDescendants(child.id)),
          ]
        }

        const idsToDelete = new Set(getDescendants(folderId))

        set((state) => ({
          folders: {
            ...state.folders,
            [patientId]: (state.folders[patientId] ?? []).filter(
              (f) => !idsToDelete.has(f.id)
            ),
          },
        }))
      },

      renameFolder: (patientId, folderId, newName) => {
        set((state) => ({
          folders: {
            ...state.folders,
            [patientId]: (state.folders[patientId] ?? []).map((f) =>
              f.id === folderId
                ? { ...f, name: newName.trim(), updatedAt: new Date().toISOString() }
                : f
            ),
          },
        }))
      },

      moveFolder: (patientId, folderId, newParentId) => {
        // Prevent moving a folder into itself or its descendants
        const patientFolders = get().folders[patientId] ?? []

        const getDescendants = (id: string): string[] => {
          const children = patientFolders.filter((f) => f.parentId === id)
          return [id, ...children.flatMap((child) => getDescendants(child.id))]
        }

        const descendants = new Set(getDescendants(folderId))
        if (newParentId && descendants.has(newParentId)) {
          // Invalid move - can't move into own descendant
          return
        }

        set((state) => ({
          folders: {
            ...state.folders,
            [patientId]: (state.folders[patientId] ?? []).map((f) =>
              f.id === folderId
                ? { ...f, parentId: newParentId, updatedAt: new Date().toISOString() }
                : f
            ),
          },
        }))
      },

      getItemCount: (patientId, folderId, files) => {
        const patientFolders = get().folders[patientId] ?? []
        const subfolderCount = patientFolders.filter((f) => f.parentId === folderId).length
        const fileCount = files.filter((f) => f.folderId === folderId).length
        return subfolderCount + fileCount
      },
    }),
    {
      name: 'medisync-folders',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ folders: state.folders }),
    }
  )
)
