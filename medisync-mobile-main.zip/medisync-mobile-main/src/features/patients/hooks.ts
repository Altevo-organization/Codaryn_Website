// src/features/patients/hooks.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  fetchPatients,
  fetchPatient,
  createPatient,
  updatePatient,
  deletePatient,
  type CreatePatientPayload,
  type UpdatePatientPayload,
} from './api'
import type { PatientQuery, Patient } from './types'

export function usePatientsQuery(query?: PatientQuery) {
  const { data, isLoading, error, refetch, isRefetching } = useQuery({
    queryKey: ['patients', query],
    queryFn: () => fetchPatients(query),
  })

  return {
    data: data?.items ?? [],
    pagination: data?.pagination,
    isLoading,
    error,
    refetch,
    isRefetching,
  }
}

export function usePatientQuery(id?: number) {
  return useQuery({
    queryKey: ['patients', 'detail', id],
    queryFn: () => fetchPatient(id as number),
    enabled: !!id,
  })
}

export function useCreatePatientMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (payload: CreatePatientPayload) => createPatient(payload),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['patients'] })
    },
  })
}

export function useUpdatePatientMutation(id: number) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (payload: UpdatePatientPayload) => updatePatient(id, payload),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['patients'] })
      void queryClient.invalidateQueries({
        queryKey: ['patients', 'detail', id],
      })
    },
  })
}

export function useDeletePatientMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: number) => deletePatient(id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['patients'] })
    },
  })
}
