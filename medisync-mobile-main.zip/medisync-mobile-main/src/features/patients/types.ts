// src/features/patients/types.ts

export interface Patient {
  id: number
  firstName: string
  lastName: string
  age: number
  height: number
  weight: number
  disease: string
  diagnosisDate: string // "YYYY-MM-DD"
  symptoms: string
  medications: string
  treatment: string
  lastVisit: string // "YYYY-MM-DD"
  additionalInfo?: string
  nurse?: string
  observations?: string
  createdAt?: string
  updatedAt?: string
}

export interface PatientQuery {
  page?: number
  limit?: number
  sortBy?: string
  sortOrder?: 'ASC' | 'DESC'
  search?: string
}

export interface PaginationMeta {
  currentPage: number
  totalPages: number
  totalItems: number
  itemsPerPage: number
  hasNext: boolean
  hasPrev: boolean
}

export interface PatientsListResult {
  items: Patient[]
  pagination: PaginationMeta
}
