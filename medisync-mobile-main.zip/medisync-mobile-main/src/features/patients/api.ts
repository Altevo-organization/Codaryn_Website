// src/features/patients/api.ts
import { api } from '../../lib/apiClient'
import type { Patient, PatientQuery, PatientsListResult, PaginationMeta } from './types'

// Types de réponse génériques (comme backend)
interface ApiResponse<T = any> {
  success: boolean
  message: string
  data?: T
  error?: unknown
  timestamp: string
}

interface PaginatedResponse<T> {
  data: T[]
  pagination: PaginationMeta
}

// DTO côté front alignés avec backend
export interface CreatePatientPayload {
  firstName: string
  lastName: string
  age: number
  height: number
  weight: number
  disease: string
  diagnosisDate: string // YYYY-MM-DD
  symptoms: string
  medications: string
  treatment: string
  lastVisit: string // YYYY-MM-DD
  additionalInfo?: string
  nurse?: string
  observations?: string
}

export type UpdatePatientPayload = Partial<CreatePatientPayload>

type PatientApi = {
  id: number
  firstName: string
  lastName: string
  age: number
  height: number
  weight: number
  disease: string
  diagnosisDate: string | Date
  symptoms: string
  medications: string
  treatment: string
  lastVisit: string | Date
  additionalInfo?: string
  nurse?: string
  observations?: string
  createdAt: string | Date
  updatedAt: string | Date
}

function toDateOnly(value: string | Date): string {
  const d = typeof value === 'string' ? new Date(value) : value
  if (Number.isNaN(d.getTime())) return ''
  return d.toISOString().split('T')[0]
}

// mapping API -> modèle front
function mapPatient(apiPatient: PatientApi): Patient {
  return {
    id: apiPatient.id,
    firstName: apiPatient.firstName,
    lastName: apiPatient.lastName,
    age: apiPatient.age,
    height: apiPatient.height,
    weight: apiPatient.weight,
    disease: apiPatient.disease,
    diagnosisDate: toDateOnly(apiPatient.diagnosisDate),
    symptoms: apiPatient.symptoms,
    medications: apiPatient.medications,
    treatment: apiPatient.treatment,
    lastVisit: toDateOnly(apiPatient.lastVisit),
    additionalInfo: apiPatient.additionalInfo,
    nurse: apiPatient.nurse,
    observations: apiPatient.observations,
    createdAt:
      typeof apiPatient.createdAt === 'string'
        ? apiPatient.createdAt
        : apiPatient.createdAt.toISOString(),
    updatedAt:
      typeof apiPatient.updatedAt === 'string'
        ? apiPatient.updatedAt
        : apiPatient.updatedAt.toISOString(),
  }
}

function buildQueryParams(query?: PatientQuery): Record<string, unknown> {
  if (!query) return {}
  const params: Record<string, unknown> = {}
  if (query.page !== undefined) params.page = query.page
  if (query.limit !== undefined) params.limit = query.limit
  if (query.sortBy) params.sortBy = query.sortBy
  if (query.sortOrder) params.sortOrder = query.sortOrder
  if (query.search) params.search = query.search
  return params
}

// --- API calls ---

export async function fetchPatients(
  query?: PatientQuery,
): Promise<PatientsListResult> {
  const params = buildQueryParams(query)

  const res = await api.get<ApiResponse<PaginatedResponse<PatientApi>>>(
    '/patients',
    { params },
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch patients')
  }

  return {
    items: res.data.data.data.map(mapPatient),
    pagination: res.data.data.pagination,
  }
}

export async function fetchPatient(id: number): Promise<Patient> {
  const res = await api.get<ApiResponse<PatientApi>>(`/patients/${id}`)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || `Patient ${id} not found`)
  }

  return mapPatient(res.data.data)
}

export async function createPatient(
  payload: CreatePatientPayload,
): Promise<Patient> {
  const res = await api.post<ApiResponse<PatientApi>>('/patients', payload)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to create patient')
  }

  return mapPatient(res.data.data)
}

export async function updatePatient(
  id: number,
  payload: UpdatePatientPayload,
): Promise<Patient> {
  const res = await api.put<ApiResponse<PatientApi>>(
    `/patients/${id}`,
    payload,
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to update patient')
  }

  return mapPatient(res.data.data)
}

export async function deletePatient(id: number): Promise<void> {
  const res = await api.delete<ApiResponse>(`/patients/${id}`)

  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to delete patient')
  }
}
