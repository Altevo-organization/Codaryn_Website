// src/features/chat/types.ts

export type MessageStatus = 'sent' | 'delivered' | 'read'

export interface ChatUser {
  id: number
  firstName: string
  lastName: string
  isActive?: boolean
}

export interface ChatMessage {
  id: number
  senderId: number
  receiverId: number
  conversationId: string
  content: string
  status: MessageStatus
  readAt: string | null
  deliveredAt: string | null
  attachmentUrl: string | null
  attachmentType: string | null
  replyToMessageId: number | null
  createdAt: string
  sender?: ChatUser
  receiver?: ChatUser
}

export interface Conversation {
  id: string
  participant: ChatUser
  lastMessage: {
    id: number
    content: string
    senderId: number
    createdAt: string
    status: MessageStatus
  } | null
  unreadCount: number
  lastMessageAt: string | null
  createdAt: string
}

export interface SendMessageDto {
  receiverId: number
  content: string
  attachmentUrl?: string
  attachmentType?: string
  replyToMessageId?: number
}

export interface GetMessagesQuery {
  conversationId?: string
  receiverId?: number
  limit?: number
  offset?: number
  before?: string
  after?: string
}

// WebSocket event payloads
export interface TypingEvent {
  conversationId: string
  userId: number
}

export interface PresenceEvent {
  userId: number
  status: 'online' | 'away' | 'offline'
  lastSeen?: string
}

export interface MessageReadEvent {
  messageId: number
  readAt: string
}

export interface MessageDeliveredEvent {
  messageId: number
  deliveredAt: string
}

export interface ConversationUpdatedEvent {
  conversationId: string
  unreadCount: number
}
