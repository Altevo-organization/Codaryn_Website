// src/features/chat/api.ts
import { api } from '../../lib/apiClient'
import type {
  ChatMessage,
  ChatUser,
  Conversation,
  GetMessagesQuery,
  MessageStatus,
  SendMessageDto,
} from './types'

// API response wrapper type
interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
  timestamp: string
}

// Backend API types (snake_case)
interface ChatUserApi {
  id: number
  first_name?: string
  firstName?: string
  last_name?: string
  lastName?: string
  is_active?: boolean
  isActive?: boolean
}

interface ChatMessageApi {
  id: number
  sender_id?: number
  senderId?: number
  receiver_id?: number
  receiverId?: number
  conversation_id?: string
  conversationId?: string
  content: string
  status: MessageStatus
  read_at?: string | null
  readAt?: string | null
  delivered_at?: string | null
  deliveredAt?: string | null
  attachment_url?: string | null
  attachmentUrl?: string | null
  attachment_type?: string | null
  attachmentType?: string | null
  reply_to_message_id?: number | null
  replyToMessageId?: number | null
  created_at?: string
  createdAt?: string
  sender?: ChatUserApi
  receiver?: ChatUserApi
}

interface ConversationApi {
  id: string
  participant: ChatUserApi
  last_message?: {
    id: number
    content: string
    sender_id?: number
    senderId?: number
    created_at?: string
    createdAt?: string
    status: MessageStatus
  } | null
  lastMessage?: {
    id: number
    content: string
    sender_id?: number
    senderId?: number
    created_at?: string
    createdAt?: string
    status: MessageStatus
  } | null
  unread_count?: number
  unreadCount?: number
  last_message_at?: string | null
  lastMessageAt?: string | null
  created_at?: string
  createdAt?: string
}

// Mapping functions
function mapUser(u: ChatUserApi): ChatUser {
  return {
    id: u.id,
    firstName: u.firstName ?? u.first_name ?? '',
    lastName: u.lastName ?? u.last_name ?? '',
    isActive: u.isActive ?? u.is_active ?? true,
  }
}

function mapMessage(m: ChatMessageApi): ChatMessage {
  return {
    id: m.id,
    senderId: m.senderId ?? m.sender_id ?? 0,
    receiverId: m.receiverId ?? m.receiver_id ?? 0,
    conversationId: m.conversationId ?? m.conversation_id ?? '',
    content: m.content,
    status: m.status,
    readAt: m.readAt ?? m.read_at ?? null,
    deliveredAt: m.deliveredAt ?? m.delivered_at ?? null,
    attachmentUrl: m.attachmentUrl ?? m.attachment_url ?? null,
    attachmentType: m.attachmentType ?? m.attachment_type ?? null,
    replyToMessageId: m.replyToMessageId ?? m.reply_to_message_id ?? null,
    createdAt: m.createdAt ?? m.created_at ?? '',
    sender: m.sender ? mapUser(m.sender) : undefined,
    receiver: m.receiver ? mapUser(m.receiver) : undefined,
  }
}

function mapConversation(c: ConversationApi): Conversation {
  const lastMsg = c.lastMessage ?? c.last_message
  return {
    id: c.id,
    participant: mapUser(c.participant),
    lastMessage: lastMsg
      ? {
          id: lastMsg.id,
          content: lastMsg.content,
          senderId: lastMsg.senderId ?? lastMsg.sender_id ?? 0,
          createdAt: lastMsg.createdAt ?? lastMsg.created_at ?? '',
          status: lastMsg.status,
        }
      : null,
    unreadCount: c.unreadCount ?? c.unread_count ?? 0,
    lastMessageAt: c.lastMessageAt ?? c.last_message_at ?? null,
    createdAt: c.createdAt ?? c.created_at ?? '',
  }
}

// API functions
export async function fetchConversations(): Promise<Conversation[]> {
  const res = await api.get<ApiResponse<ConversationApi[]>>(
    '/messages/conversations'
  )
  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch conversations')
  }
  return res.data.data.map(mapConversation)
}

export async function fetchMessages(
  query: GetMessagesQuery
): Promise<ChatMessage[]> {
  const params = new URLSearchParams()
  if (query.conversationId) params.append('conversationId', query.conversationId)
  if (query.receiverId) params.append('receiverId', query.receiverId.toString())
  if (query.limit) params.append('limit', query.limit.toString())
  if (query.offset) params.append('offset', query.offset.toString())
  if (query.before) params.append('before', query.before)
  if (query.after) params.append('after', query.after)

  const url = `/messages${params.toString() ? `?${params.toString()}` : ''}`
  const res = await api.get<ApiResponse<ChatMessageApi[]>>(url)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch messages')
  }
  return res.data.data.map(mapMessage)
}

export async function sendMessage(dto: SendMessageDto): Promise<ChatMessage> {
  const res = await api.post<ApiResponse<ChatMessageApi>>('/messages', dto)
  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to send message')
  }
  return mapMessage(res.data.data)
}

export async function markMessageAsRead(messageId: number): Promise<void> {
  const res = await api.patch<ApiResponse<null>>(
    `/messages/${messageId}/read`
  )
  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to mark message as read')
  }
}

export async function markConversationAsRead(
  conversationId: string
): Promise<void> {
  const res = await api.patch<ApiResponse<null>>(
    `/messages/conversations/${conversationId}/read`
  )
  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to mark conversation as read')
  }
}

export async function deleteMessage(messageId: number): Promise<void> {
  const res = await api.delete<ApiResponse<null>>(`/messages/${messageId}`)
  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to delete message')
  }
}

export async function fetchUnreadCount(): Promise<number> {
  const res = await api.get<ApiResponse<{ count: number }>>(
    '/messages/unread-count'
  )
  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch unread count')
  }
  return res.data.data.count
}
