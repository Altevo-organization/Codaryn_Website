// src/features/chat/hooks.ts
import { useCallback, useEffect, useRef, useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  fetchConversations,
  fetchMessages,
  fetchUnreadCount,
  markConversationAsRead,
  markMessageAsRead,
  sendMessage,
  deleteMessage,
} from './api'
import { chatSocketService } from './socketService'
import { useAuthStore } from '../../stores/authStore'
import type {
  ChatMessage,
  Conversation,
  GetMessagesQuery,
  SendMessageDto,
  TypingEvent,
} from './types'

// Query keys
const CHAT_KEYS = {
  conversations: ['chat', 'conversations'] as const,
  messages: (conversationId: string) =>
    ['chat', 'messages', conversationId] as const,
  unreadCount: ['chat', 'unreadCount'] as const,
}

// Conversations list query
export function useConversationsQuery() {
  return useQuery({
    queryKey: CHAT_KEYS.conversations,
    queryFn: fetchConversations,
  })
}

// Messages for a conversation
export function useMessagesQuery(conversationId: string) {
  return useQuery({
    queryKey: CHAT_KEYS.messages(conversationId),
    queryFn: () => fetchMessages({ conversationId, limit: 50 }),
    enabled: !!conversationId,
  })
}

// Load more messages (pagination)
export function useLoadMoreMessages(conversationId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (query: GetMessagesQuery) => fetchMessages(query),
    onSuccess: (newMessages) => {
      queryClient.setQueryData<ChatMessage[]>(
        CHAT_KEYS.messages(conversationId),
        (old) => {
          if (!old) return newMessages
          // Prepend older messages
          const existingIds = new Set(old.map((m) => m.id))
          const uniqueNew = newMessages.filter((m) => !existingIds.has(m.id))
          return [...uniqueNew, ...old]
        }
      )
    },
  })
}

// Unread count query
export function useUnreadCountQuery() {
  return useQuery({
    queryKey: CHAT_KEYS.unreadCount,
    queryFn: fetchUnreadCount,
    refetchInterval: 60000, // Refetch every minute as backup
  })
}

// Send message mutation
export function useSendMessageMutation(conversationId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (dto: SendMessageDto) => sendMessage(dto),
    onSuccess: (newMessage) => {
      // Add message to cache
      queryClient.setQueryData<ChatMessage[]>(
        CHAT_KEYS.messages(conversationId),
        (old) => (old ? [...old, newMessage] : [newMessage])
      )
      // Invalidate conversations to update last message
      void queryClient.invalidateQueries({
        queryKey: CHAT_KEYS.conversations,
      })
    },
  })
}

// Mark conversation as read mutation
export function useMarkConversationReadMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (conversationId: string) => markConversationAsRead(conversationId),
    onSuccess: (_, conversationId) => {
      // Update unread count locally
      void queryClient.invalidateQueries({
        queryKey: CHAT_KEYS.unreadCount,
      })
      // Update conversations list
      queryClient.setQueryData<Conversation[]>(
        CHAT_KEYS.conversations,
        (old) =>
          old?.map((c) =>
            c.id === conversationId ? { ...c, unreadCount: 0 } : c
          )
      )
    },
  })
}

// Mark single message as read mutation
export function useMarkMessageReadMutation(conversationId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (messageId: number) => markMessageAsRead(messageId),
    onSuccess: (_, messageId) => {
      // Update message status in cache
      queryClient.setQueryData<ChatMessage[]>(
        CHAT_KEYS.messages(conversationId),
        (old) =>
          old?.map((m) =>
            m.id === messageId
              ? { ...m, status: 'read', readAt: new Date().toISOString() }
              : m
          )
      )
    },
  })
}

// Delete message mutation
export function useDeleteMessageMutation(conversationId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (messageId: number) => deleteMessage(messageId),
    onSuccess: (_, messageId) => {
      // Remove message from cache
      queryClient.setQueryData<ChatMessage[]>(
        CHAT_KEYS.messages(conversationId),
        (old) => old?.filter((m) => m.id !== messageId)
      )
      // Refresh conversations
      void queryClient.invalidateQueries({
        queryKey: CHAT_KEYS.conversations,
      })
    },
  })
}

// WebSocket connection hook
export function useChatSocket() {
  const queryClient = useQueryClient()
  const clearAuth = useAuthStore((s) => s.clearAuth)

  useEffect(() => {
    chatSocketService.connect()

    // Handle auth errors (invalid/expired token)
    chatSocketService.setOnError((error) => {
      console.log('[ChatSocket] Error:', error.message)
      if (
        error.message === 'Invalid token' ||
        error.message === 'Token expired' ||
        error.message === 'Authentication failed'
      ) {
        console.log('[ChatSocket] Token invalid, clearing auth...')
        clearAuth()
      }
    })

    // Handle new messages
    chatSocketService.setOnNewMessage((message) => {
      queryClient.setQueryData<ChatMessage[]>(
        CHAT_KEYS.messages(message.conversationId),
        (old) => {
          if (!old) return [message]
          // Avoid duplicates
          if (old.some((m) => m.id === message.id)) return old
          return [...old, message]
        }
      )
      // Refresh conversations list
      void queryClient.invalidateQueries({
        queryKey: CHAT_KEYS.conversations,
      })
      void queryClient.invalidateQueries({
        queryKey: CHAT_KEYS.unreadCount,
      })
    })

    // Handle message read receipts
    chatSocketService.setOnMessageRead((event) => {
      // Update all message caches that might contain this message
      const queries = queryClient.getQueriesData<ChatMessage[]>({
        queryKey: ['chat', 'messages'],
      })
      queries.forEach(([key, data]) => {
        if (data?.some((m) => m.id === event.messageId)) {
          queryClient.setQueryData<ChatMessage[]>(key, (old) =>
            old?.map((m) =>
              m.id === event.messageId
                ? { ...m, status: 'read', readAt: event.readAt }
                : m
            )
          )
        }
      })
    })

    // Handle message delivered
    chatSocketService.setOnMessageDelivered((event) => {
      const queries = queryClient.getQueriesData<ChatMessage[]>({
        queryKey: ['chat', 'messages'],
      })
      queries.forEach(([key, data]) => {
        if (data?.some((m) => m.id === event.messageId)) {
          queryClient.setQueryData<ChatMessage[]>(key, (old) =>
            old?.map((m) =>
              m.id === event.messageId
                ? { ...m, status: 'delivered', deliveredAt: event.deliveredAt }
                : m
            )
          )
        }
      })
    })

    // Handle message deleted
    chatSocketService.setOnMessageDeleted((messageId) => {
      const queries = queryClient.getQueriesData<ChatMessage[]>({
        queryKey: ['chat', 'messages'],
      })
      queries.forEach(([key, data]) => {
        if (data?.some((m) => m.id === messageId)) {
          queryClient.setQueryData<ChatMessage[]>(key, (old) =>
            old?.filter((m) => m.id !== messageId)
          )
        }
      })
    })

    // Handle conversation updated
    chatSocketService.setOnConversationUpdated((event) => {
      queryClient.setQueryData<Conversation[]>(
        CHAT_KEYS.conversations,
        (old) =>
          old?.map((c) =>
            c.id === event.conversationId
              ? { ...c, unreadCount: event.unreadCount }
              : c
          )
      )
      void queryClient.invalidateQueries({
        queryKey: CHAT_KEYS.unreadCount,
      })
    })

    return () => {
      chatSocketService.setOnNewMessage(null)
      chatSocketService.setOnMessageRead(null)
      chatSocketService.setOnMessageDelivered(null)
      chatSocketService.setOnMessageDeleted(null)
      chatSocketService.setOnConversationUpdated(null)
      chatSocketService.setOnError(null)
      chatSocketService.disconnect()
    }
  }, [queryClient, clearAuth])
}

// Typing indicator hook
export function useTypingIndicator(conversationId: string) {
  const [typingUsers, setTypingUsers] = useState<number[]>([])
  const typingTimeouts = useRef<Map<number, NodeJS.Timeout>>(new Map())

  useEffect(() => {
    chatSocketService.setOnTypingStart((event: TypingEvent) => {
      if (event.conversationId !== conversationId) return

      setTypingUsers((prev) => {
        if (prev.includes(event.userId)) return prev
        return [...prev, event.userId]
      })

      // Auto-clear after 5 seconds
      const existingTimeout = typingTimeouts.current.get(event.userId)
      if (existingTimeout) clearTimeout(existingTimeout)

      const timeout = setTimeout(() => {
        setTypingUsers((prev) => prev.filter((id) => id !== event.userId))
        typingTimeouts.current.delete(event.userId)
      }, 5000)

      typingTimeouts.current.set(event.userId, timeout)
    })

    chatSocketService.setOnTypingStop((event: TypingEvent) => {
      if (event.conversationId !== conversationId) return

      setTypingUsers((prev) => prev.filter((id) => id !== event.userId))
      const timeout = typingTimeouts.current.get(event.userId)
      if (timeout) {
        clearTimeout(timeout)
        typingTimeouts.current.delete(event.userId)
      }
    })

    return () => {
      chatSocketService.setOnTypingStart(null)
      chatSocketService.setOnTypingStop(null)
      typingTimeouts.current.forEach((t) => clearTimeout(t))
      typingTimeouts.current.clear()
    }
  }, [conversationId])

  const sendTypingStart = useCallback(() => {
    chatSocketService.startTyping(conversationId)
  }, [conversationId])

  const sendTypingStop = useCallback(() => {
    chatSocketService.stopTyping(conversationId)
  }, [conversationId])

  return {
    typingUsers,
    sendTypingStart,
    sendTypingStop,
  }
}

// Join/leave conversation for real-time updates
export function useConversationSubscription(conversationId: string) {
  useEffect(() => {
    if (!conversationId) return

    chatSocketService.joinConversation(conversationId)

    return () => {
      chatSocketService.leaveConversation(conversationId)
    }
  }, [conversationId])
}
