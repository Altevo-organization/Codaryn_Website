// src/features/chat/socketService.ts
import { io, Socket } from 'socket.io-client'
import { useAuthStore } from '../../stores/authStore'
import type {
  ChatMessage,
  ConversationUpdatedEvent,
  MessageDeliveredEvent,
  MessageReadEvent,
  PresenceEvent,
  SendMessageDto,
  TypingEvent,
} from './types'

type MessageCallback = (message: ChatMessage) => void
type TypingCallback = (event: TypingEvent) => void
type PresenceCallback = (event: PresenceEvent) => void
type MessageReadCallback = (event: MessageReadEvent) => void
type MessageDeliveredCallback = (event: MessageDeliveredEvent) => void
type ConversationUpdatedCallback = (event: ConversationUpdatedEvent) => void
type MessageDeletedCallback = (messageId: number) => void
type ErrorCallback = (error: { message: string; code?: string }) => void

class ChatSocketService {
  private socket: Socket | null = null
  private baseUrl: string

  // Event listeners
  private onNewMessage: MessageCallback | null = null
  private onTypingStart: TypingCallback | null = null
  private onTypingStop: TypingCallback | null = null
  private onPresenceChange: PresenceCallback | null = null
  private onMessageRead: MessageReadCallback | null = null
  private onMessageDelivered: MessageDeliveredCallback | null = null
  private onConversationUpdated: ConversationUpdatedCallback | null = null
  private onMessageDeleted: MessageDeletedCallback | null = null
  private onError: ErrorCallback | null = null

  constructor() {
    // Remove /api suffix from URL for WebSocket connection
    const apiUrl = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3000/api'
    this.baseUrl = apiUrl.replace(/\/api\/?$/, '')
  }

  connect(): void {
    // Always disconnect existing socket first to get fresh token
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
    }

    const token = useAuthStore.getState().accessToken
    if (!token) {
      console.warn('[Socket] No auth token available, cannot connect')
      return
    }

    console.log('[Socket] Connecting to:', this.baseUrl)
    console.log('[Socket] With token:', token.substring(0, 50) + '...')

    this.socket = io(this.baseUrl, {
      auth: { token },
      transports: ['websocket'],
      reconnection: false,
    })

    this.setupListeners()
  }

  private setupListeners(): void {
    if (!this.socket) return

    this.socket.on('connect', () => {
      console.log('[Socket] Connected:', this.socket?.id)
    })

    this.socket.on('disconnect', (reason) => {
      console.log('[Socket] Disconnected:', reason)
    })

    this.socket.on('connect_error', (error) => {
      console.error('[Socket] Connection error:', error.message)
      // Stop reconnection attempts on auth errors
      if (
        error.message === 'Invalid token' ||
        error.message === 'Token expired' ||
        error.message === 'Authentication failed'
      ) {
        this.socket?.disconnect()
        this.socket = null
      }
      this.onError?.({ message: error.message })
    })

    // Message events
    this.socket.on('message:new', (message: ChatMessage) => {
      this.onNewMessage?.(message)
    })

    this.socket.on('message:read', (event: MessageReadEvent) => {
      this.onMessageRead?.(event)
    })

    this.socket.on('message:delivered', (event: MessageDeliveredEvent) => {
      this.onMessageDelivered?.(event)
    })

    this.socket.on('message:deleted', (messageId: number) => {
      this.onMessageDeleted?.(messageId)
    })

    // Conversation events
    this.socket.on('conversation:updated', (event: ConversationUpdatedEvent) => {
      this.onConversationUpdated?.(event)
    })

    // Typing events
    this.socket.on('typing:start', (event: TypingEvent) => {
      this.onTypingStart?.(event)
    })

    this.socket.on('typing:stop', (event: TypingEvent) => {
      this.onTypingStop?.(event)
    })

    // Presence events
    this.socket.on('presence:change', (event: PresenceEvent) => {
      this.onPresenceChange?.(event)
    })

    // Error event
    this.socket.on('error', (error: { message: string; code?: string }) => {
      console.error('[Socket] Error:', error)
      this.onError?.(error)
    })
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
    }
  }

  isConnected(): boolean {
    return this.socket?.connected ?? false
  }

  // Send message via WebSocket
  sendMessage(
    dto: SendMessageDto,
    callback?: (response: { success: boolean; data?: ChatMessage; error?: string }) => void
  ): void {
    if (!this.socket?.connected) {
      callback?.({ success: false, error: 'Socket not connected' })
      return
    }

    this.socket.emit('message:send', dto, callback)
  }

  // Mark message as read
  markMessageRead(messageId: number): void {
    if (this.socket?.connected) {
      this.socket.emit('message:markRead', messageId)
    }
  }

  // Typing indicators
  startTyping(conversationId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('typing:start', conversationId)
    }
  }

  stopTyping(conversationId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('typing:stop', conversationId)
    }
  }

  // Presence
  updatePresence(status: 'online' | 'away'): void {
    if (this.socket?.connected) {
      this.socket.emit('presence:update', status)
    }
  }

  // Conversation subscription
  joinConversation(conversationId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('conversation:join', conversationId)
    }
  }

  leaveConversation(conversationId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('conversation:leave', conversationId)
    }
  }

  // Event subscriptions
  setOnNewMessage(callback: MessageCallback | null): void {
    this.onNewMessage = callback
  }

  setOnTypingStart(callback: TypingCallback | null): void {
    this.onTypingStart = callback
  }

  setOnTypingStop(callback: TypingCallback | null): void {
    this.onTypingStop = callback
  }

  setOnPresenceChange(callback: PresenceCallback | null): void {
    this.onPresenceChange = callback
  }

  setOnMessageRead(callback: MessageReadCallback | null): void {
    this.onMessageRead = callback
  }

  setOnMessageDelivered(callback: MessageDeliveredCallback | null): void {
    this.onMessageDelivered = callback
  }

  setOnConversationUpdated(callback: ConversationUpdatedCallback | null): void {
    this.onConversationUpdated = callback
  }

  setOnMessageDeleted(callback: MessageDeletedCallback | null): void {
    this.onMessageDeleted = callback
  }

  setOnError(callback: ErrorCallback | null): void {
    this.onError = callback
  }
}

// Singleton instance
export const chatSocketService = new ChatSocketService()
