// src/features/auth/types.ts

export interface AuthUser {
  id: number
  fullName: string
  email: string
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface LoginResponse {
  user: AuthUser
  accessToken: string
}
