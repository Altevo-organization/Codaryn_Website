// src/features/auth/hooks.ts
import { useQuery } from '@tanstack/react-query'
import { fetchCurrentUser } from './api'

export function useCurrentUserQuery() {
  return useQuery({
    queryKey: ['auth', 'me'],
    queryFn: fetchCurrentUser,
  })
}
