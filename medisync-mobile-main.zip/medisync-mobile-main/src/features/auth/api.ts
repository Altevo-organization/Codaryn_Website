// src/features/auth/api.ts
import { api } from '../../lib/apiClient'
import type { LoginCredentials, LoginResponse, AuthUser } from './types'

// Structure de réponse API backend standard
interface ApiResponse<T> {
  success: boolean
  message: string
  data?: T
  timestamp: string
}

type AuthUserApi = {
  id: number
  fullName?: string
  full_name?: string
  firstName?: string
  lastName?: string
  email: string
}

type LoginApiData = {
  user: AuthUserApi
  accessToken: string
  refreshToken: string
  expiresIn: number
}

function mapAuthUser(apiUser: AuthUserApi | undefined): AuthUser {
  if (!apiUser) {
    return {
      id: 0,
      fullName: 'Utilisateur',
      email: '',
    }
  }

  const fullName =
    apiUser.fullName ??
    apiUser.full_name ??
    `${apiUser.firstName ?? ''} ${apiUser.lastName ?? ''}`.trim()

  return {
    id: apiUser.id,
    fullName: fullName || 'Utilisateur',
    email: apiUser.email,
  }
}

export async function login(credentials: LoginCredentials): Promise<LoginResponse> {
  const res = await api.post<ApiResponse<LoginApiData>>('/auth/login', credentials)

  // Debug log
  console.log('[Auth] Login response:', JSON.stringify(res.data, null, 2))

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Échec de la connexion')
  }

  const { user, accessToken } = res.data.data

  console.log('[Auth] Token extracted:', accessToken ? `${accessToken.substring(0, 20)}...` : 'EMPTY')

  return {
    user: mapAuthUser(user),
    accessToken,
  }
}

export async function fetchCurrentUser(): Promise<AuthUser> {
  const res = await api.get<ApiResponse<AuthUserApi>>('/auth/profile')

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Échec de récupération du profil')
  }

  return mapAuthUser(res.data.data)
}
