// src/features/appointments/api.ts
import { api } from '../../lib/apiClient'
import type { Appointment, AppointmentQuery } from './types'

// Types alignés avec le backend

interface PaginationMeta {
  currentPage: number
  totalPages: number
  totalItems: number
  itemsPerPage: number
  hasNext: boolean
  hasPrev: boolean
}

interface PaginatedResponse<T> {
  data: T[]
  pagination: PaginationMeta
}

interface ApiResponse<T = any> {
  success: boolean
  message: string
  data?: T
  error?: unknown
  timestamp: string
}

type PatientApi = {
  id: number
  firstName?: string
  lastName?: string
}

type AppointmentApi = {
  id: number
  startDate: string
  endDate: string
  patientId: number
  patient?: PatientApi
  createdAt: string
  updatedAt: string
}

// DTOs alignés avec CreateAppointmentDto / UpdateAppointmentDto
export interface CreateAppointmentDto {
  startDate: string
  endDate: string
  patientId: number
}

export interface UpdateAppointmentDto {
  startDate?: string | null
  endDate?: string | null
  patientId?: number
}

// --- mapping API -> modèle front ---

function mapAppointment(a: AppointmentApi): Appointment {
  const patientName =
    a.patient
      ? `${a.patient.lastName ?? ''} ${a.patient.firstName ?? ''}`.trim()
      : undefined

  return {
    id: a.id,
    patientId: a.patientId,
    startDate: a.startDate,
    endDate: a.endDate,
    patientName: patientName && patientName.length > 0 ? patientName : undefined,
    createdAt: a.createdAt,
    updatedAt: a.updatedAt,
  }
}

// Utilitaire pour transformer AppointmentQuery en params d’URL
function buildQueryParams(query?: AppointmentQuery): Record<string, unknown> {
  if (!query) return {}
  const params: Record<string, unknown> = {}

  if (query.page !== undefined) params.page = query.page
  if (query.limit !== undefined) params.limit = query.limit
  if (query.sortBy) params.sortBy = query.sortBy
  if (query.sortOrder) params.sortOrder = query.sortOrder
  if (query.patientId !== undefined) params.patientId = query.patientId
  if (query.startDate) params.startDate = query.startDate
  if (query.endDate) params.endDate = query.endDate

  return params
}

// --- Fonctions API ---

export async function fetchAppointments(
  query?: AppointmentQuery,
): Promise<{ items: Appointment[]; pagination: PaginationMeta }> {
  const params = buildQueryParams(query)

  const res = await api.get<ApiResponse<any>>('/appointments', { params })

  // 🔍 Log de debug pour voir la forme exacte
  console.log('[Appointments] /appointments response:', res.data)

  if (!res.data) {
    throw new Error('Réponse vide du serveur')
  }

  if (res.data.success === false) {
    throw new Error(res.data.message || 'Failed to fetch appointments')
  }

  const apiData = res.data.data

  if (!apiData) {
    // Pas de champ data -> on considère qu'il n'y a pas de rendez-vous
    return {
      items: [],
      pagination: {
        currentPage: 1,
        totalPages: 1,
        totalItems: 0,
        itemsPerPage: query?.limit ?? 10,
        hasNext: false,
        hasPrev: false,
      },
    }
  }

  let rawItems: AppointmentApi[] = []
  let pagination: PaginationMeta = {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: query?.limit ?? 10,
    hasNext: false,
    hasPrev: false,
  }

  // Cas 1 : le backend renvoie directement un tableau dans data
  if (Array.isArray(apiData)) {
    rawItems = apiData
  }
  // Cas 2 : notre cas attendu : { data: [...], pagination: {...} }
  else if (Array.isArray(apiData.data)) {
    rawItems = apiData.data
    if (apiData.pagination) {
      pagination = apiData.pagination as PaginationMeta
    }
  }
  // Cas 3 : autre shape : { items: [...], ... }
  else if (Array.isArray(apiData.items)) {
    rawItems = apiData.items
    if (apiData.pagination) {
      pagination = apiData.pagination as PaginationMeta
    }
  } else {
    console.warn('[Appointments] Forme de data inattendue:', apiData)
    rawItems = []
  }

  return {
    items: rawItems.map(mapAppointment),
    pagination,
  }
}


export async function fetchAppointment(id: number): Promise<Appointment> {
  const res = await api.get<ApiResponse<AppointmentApi>>(`/appointments/${id}`)

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || `Appointment ${id} not found`)
  }

  return mapAppointment(res.data.data)
}

export async function fetchAppointmentsByPatient(
  patientId: number,
  query?: AppointmentQuery,
): Promise<{ items: Appointment[]; pagination: PaginationMeta }> {
  const params = buildQueryParams(query)

  const res = await api.get<ApiResponse<PaginatedResponse<AppointmentApi>>>(
    `/appointments/patient/${patientId}`,
    { params },
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to fetch appointments')
  }

  return {
    items: res.data.data.data.map(mapAppointment),
    pagination: res.data.data.pagination,
  }
}

export async function createAppointment(
  dto: CreateAppointmentDto,
): Promise<Appointment> {
  const res = await api.post<ApiResponse<AppointmentApi>>(
    '/appointments',
    dto,
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to create appointment')
  }

  return mapAppointment(res.data.data)
}

export async function updateAppointment(
  id: number,
  dto: UpdateAppointmentDto,
): Promise<Appointment> {
  const res = await api.put<ApiResponse<AppointmentApi>>(
    `/appointments/${id}`,
    dto,
  )

  if (!res.data.success || !res.data.data) {
    throw new Error(res.data.message || 'Failed to update appointment')
  }

  return mapAppointment(res.data.data)
}

export async function deleteAppointment(id: number): Promise<void> {
  const res = await api.delete<ApiResponse>(`/appointments/${id}`)

  if (!res.data.success) {
    throw new Error(res.data.message || 'Failed to delete appointment')
  }
}
