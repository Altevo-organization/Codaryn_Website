// src/features/appointments/utils.ts
import type { Appointment, AppointmentsByDate } from './types'

export function groupAppointmentsByDate(appointments: Appointment[]): AppointmentsByDate[] {
  const map = new Map<string, Appointment[]>()

  appointments.forEach((appt) => {
    if (!appt.startDate) return
    const dateKey = appt.startDate.split('T')[0] // "2025-11-29"
    const existing = map.get(dateKey) ?? []
    existing.push(appt)
    map.set(dateKey, existing)
  })

  const sortedDates = Array.from(map.entries()).sort(([d1], [d2]) =>
    d1.localeCompare(d2),
  )

  return sortedDates.map(([date, items]) => ({
    date,
    appointments: items.sort((a, b) =>
      a.startDate.localeCompare(b.startDate),
    ),
  }))
}
