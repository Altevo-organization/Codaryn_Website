// src/features/appointments/types.ts

export interface Appointment {
  id: number
  patientId: number
  startDate: string // ISO string venant du backend
  endDate: string   // ISO string
  patientName?: string
  createdAt?: string
  updatedAt?: string
}

export interface AppointmentQuery {
  page?: number
  limit?: number
  sortBy?: 'startDate' | 'endDate' | 'createdAt'
  sortOrder?: 'ASC' | 'DESC'
  patientId?: number
  startDate?: string // filtre >= startDate
  endDate?: string   // filtre <= endDate
}

// Grille par date pour l’UI Planning
export interface AppointmentsByDate {
  date: string // "YYYY-MM-DD"
  appointments: Appointment[]
}
