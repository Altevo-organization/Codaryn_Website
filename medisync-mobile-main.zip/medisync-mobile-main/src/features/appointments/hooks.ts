// src/features/appointments/hooks.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  fetchAppointments,
  fetchAppointment,
  fetchAppointmentsByPatient,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  type CreateAppointmentDto,
  type UpdateAppointmentDto,
} from './api'
import type { AppointmentQuery } from './types'
import { groupAppointmentsByDate } from './utils'
import type { AppointmentsByDate, Appointment } from './types'

export function useAppointmentsQuery(
  query?: AppointmentQuery,
): {
  data?: AppointmentsByDate[]
  isLoading: boolean
  error: unknown
  refetch: () => void
  isRefetching: boolean
} {
  const { data, isLoading, error, refetch, isRefetching } = useQuery({
    queryKey: ['appointments', query],
    queryFn: async () => {
      const res = await fetchAppointments(query)
      return groupAppointmentsByDate(res.items)
    },
  })

  return {
    data,
    isLoading,
    error,
    refetch,
    isRefetching,
  }
}

export function useAppointmentQuery(id: number) {
  return useQuery({
    queryKey: ['appointments', 'detail', id],
    queryFn: () => fetchAppointment(id),
    enabled: !!id,
  })
}

export function useAppointmentsByPatientQuery(
  patientId: number,
  query?: AppointmentQuery,
) {
  return useQuery({
    queryKey: ['appointments', 'patient', patientId, query],
    queryFn: async () => {
      const res = await fetchAppointmentsByPatient(patientId, query)
      return res.items
    },
    enabled: !!patientId,
  })
}

export function useCreateAppointmentMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (dto: CreateAppointmentDto) => createAppointment(dto),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['appointments'] })
    },
  })
}

export function useUpdateAppointmentMutation(id: number) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (dto: UpdateAppointmentDto) => updateAppointment(id, dto),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['appointments'] })
      void queryClient.invalidateQueries({
        queryKey: ['appointments', 'detail', id],
      })
    },
  })
}

export function useDeleteAppointmentMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: number) => deleteAppointment(id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['appointments'] })
    },
  })
}
