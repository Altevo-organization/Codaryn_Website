// src/features/messages/api.ts
import { api } from '../../lib/apiClient'
import type { Message } from './types'

type MessageApi = {
  id: number
  senderName?: string
  sender_name?: string
  subject: string
  preview?: string
  body: string
  sentAt?: string
  sent_at?: string
  isRead?: boolean
  is_read?: boolean
  patientId?: number
  patient_id?: number
}

function mapMessage(m: MessageApi): Message {
  const preview =
    m.preview ??
    (m.body ? m.body.slice(0, 120) + (m.body.length > 120 ? '…' : '') : '')

  return {
    id: m.id,
    senderName: m.senderName ?? m.sender_name ?? 'Inconnu',
    subject: m.subject,
    preview,
    body: m.body,
    sentAt: m.sentAt ?? m.sent_at ?? '',
    isRead: m.isRead ?? m.is_read ?? false,
    patientId: m.patientId ?? m.patient_id,
  }
}

export async function fetchMessages(): Promise<Message[]> {
  const res = await api.get<MessageApi[]>('/messages')
  return res.data.map(mapMessage)
}

export async function fetchMessage(id: number): Promise<Message> {
  const res = await api.get<MessageApi>(`/messages/${id}`)
  return mapMessage(res.data)
}
