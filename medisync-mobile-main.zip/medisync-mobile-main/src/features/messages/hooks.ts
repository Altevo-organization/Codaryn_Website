// src/features/messages/hooks.ts
import { useQuery } from '@tanstack/react-query'
import { fetchMessage, fetchMessages } from './api'

export function useMessagesQuery() {
  return useQuery({
    queryKey: ['messages'],
    queryFn: fetchMessages,
  })
}

export function useMessageQuery(id: number) {
  return useQuery({
    queryKey: ['messages', id],
    queryFn: () => fetchMessage(id),
    enabled: !!id,
  })
}
