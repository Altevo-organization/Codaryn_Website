// src/features/messages/types.ts

export interface Message {
  id: number
  senderName: string
  subject: string
  preview: string
  body: string
  sentAt: string // "2025-11-20T08:30:00Z"
  isRead: boolean
  patientId?: number
}
