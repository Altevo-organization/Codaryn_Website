/**
 * Preferences Store
 *
 * Manages user preferences that don't require backend sync.
 * Persisted locally using AsyncStorage.
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

// =============================================================================
// TYPES
// =============================================================================

export type ThemeMode = 'light' | 'dark' | 'system';
export type Language = 'fr' | 'en';

interface NotificationPreferences {
  appointments: boolean;
  messages: boolean;
  reminders: boolean;
  updates: boolean;
}

interface PrivacyPreferences {
  analyticsEnabled: boolean;
  crashReportsEnabled: boolean;
}

interface PreferencesState {
  // Appearance
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;

  // Language
  language: Language;
  setLanguage: (lang: Language) => void;

  // Notifications
  notifications: NotificationPreferences;
  setNotificationPreference: (
    key: keyof NotificationPreferences,
    value: boolean
  ) => void;
  toggleNotificationPreference: (key: keyof NotificationPreferences) => void;

  // Privacy
  privacy: PrivacyPreferences;
  setPrivacyPreference: (
    key: keyof PrivacyPreferences,
    value: boolean
  ) => void;
  togglePrivacyPreference: (key: keyof PrivacyPreferences) => void;

  // Biometrics
  biometricsEnabled: boolean;
  setBiometricsEnabled: (enabled: boolean) => void;

  // Haptics
  hapticsEnabled: boolean;
  setHapticsEnabled: (enabled: boolean) => void;

  // Reset
  resetPreferences: () => void;
}

// =============================================================================
// DEFAULTS
// =============================================================================

const DEFAULT_NOTIFICATIONS: NotificationPreferences = {
  appointments: true,
  messages: true,
  reminders: true,
  updates: false,
};

const DEFAULT_PRIVACY: PrivacyPreferences = {
  analyticsEnabled: true,
  crashReportsEnabled: true,
};

// =============================================================================
// STORE
// =============================================================================

export const usePreferencesStore = create<PreferencesState>()(
  persist(
    (set) => ({
      // Appearance
      themeMode: 'system',
      setThemeMode: (mode) => set({ themeMode: mode }),

      // Language
      language: 'fr',
      setLanguage: (lang) => set({ language: lang }),

      // Notifications
      notifications: DEFAULT_NOTIFICATIONS,
      setNotificationPreference: (key, value) =>
        set((state) => ({
          notifications: { ...state.notifications, [key]: value },
        })),
      toggleNotificationPreference: (key) =>
        set((state) => ({
          notifications: {
            ...state.notifications,
            [key]: !state.notifications[key],
          },
        })),

      // Privacy
      privacy: DEFAULT_PRIVACY,
      setPrivacyPreference: (key, value) =>
        set((state) => ({
          privacy: { ...state.privacy, [key]: value },
        })),
      togglePrivacyPreference: (key) =>
        set((state) => ({
          privacy: {
            ...state.privacy,
            [key]: !state.privacy[key],
          },
        })),

      // Biometrics
      biometricsEnabled: false,
      setBiometricsEnabled: (enabled) => set({ biometricsEnabled: enabled }),

      // Haptics
      hapticsEnabled: true,
      setHapticsEnabled: (enabled) => set({ hapticsEnabled: enabled }),

      // Reset
      resetPreferences: () =>
        set({
          themeMode: 'system',
          language: 'fr',
          notifications: DEFAULT_NOTIFICATIONS,
          privacy: DEFAULT_PRIVACY,
          biometricsEnabled: false,
          hapticsEnabled: true,
        }),
    }),
    {
      name: 'medisync-preferences',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
