/**
 * MediSync Design System
 *
 * Complete design system with theme tokens, components, and utilities.
 *
 * Usage:
 * ```ts
 * import { useTheme, Button, Card, spacing } from '@/ui';
 * ```
 */

// =============================================================================
// THEME
// =============================================================================

export {
  // Color palette
  palette,
  lightColors,
  darkColors,

  // Tokens
  spacing,
  typography,
  textStyles,
  radius,
  shadows,
  zIndex,
  animation,
  accessibility,

  // Theme objects
  lightTheme,
  darkTheme,

  // Legacy compatibility
  toLegacyColors,
} from './theme';

export type {
  SemanticColors,
  LegacyColors,
  Theme,
} from './theme';

// =============================================================================
// THEME PROVIDER
// =============================================================================

export {
  ThemeProvider,
  useTheme,
  useColors,
  useIsDarkMode,
  useThemedStyles,
} from './ThemeProvider';

export type { ThemeName, ThemeContextValue } from './ThemeProvider';

// =============================================================================
// COMPONENTS
// =============================================================================

export {
  // Base UI
  Button,
  Input,
  Card,
  Badge,
  Avatar,
  ListItem,
  EmptyState,
  Skeleton,
  SkeletonText,
  SkeletonAvatar,
  SkeletonCard,
  SkeletonListItem,
  Divider,
  Text,
  H1,
  H2,
  H3,
  H4,
  Body,
  BodySmall,
  Label,
  Caption,

  // Layout
  Stack,
  Row,
  Spacer,
  Box,
  Center,
  ScreenContainer,
} from './components';

export type {
  ButtonProps,
  ButtonVariant,
  ButtonSize,
  InputProps,
  CardProps,
  CardVariant,
  BadgeProps,
  BadgeVariant,
  BadgeSize,
  AvatarProps,
  AvatarSize,
  ListItemProps,
  EmptyStateProps,
  SkeletonProps,
  SkeletonVariant,
  DividerProps,
  TextProps,
  TextVariant,
  TextColor,
  StackProps,
  RowProps,
  SpacerProps,
  BoxProps,
  CenterProps,
  ScreenContainerProps,
} from './components';
