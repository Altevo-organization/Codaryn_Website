/**
 * MediSync Theme Provider
 *
 * Provides theme context with full design tokens access.
 * Backward compatible with existing useTheme() calls.
 */

import React, {
  createContext,
  useContext,
  useMemo,
  useCallback,
  useEffect,
  useState,
} from 'react';
import { useColorScheme } from 'react-native';
import {
  DarkTheme as NavigationDarkTheme,
  DefaultTheme as NavigationDefaultTheme,
  NavigationContainer,
} from '@react-navigation/native';
import {
  Theme,
  lightTheme,
  darkTheme,
  SemanticColors,
  LegacyColors,
  toLegacyColors,
  spacing,
  typography,
  textStyles,
  radius,
  shadows,
  zIndex,
  animation,
  accessibility,
} from './theme';
import {
  usePreferencesStore,
  ThemeMode,
} from '../stores/preferencesStore';

// =============================================================================
// TYPES
// =============================================================================

export type ThemeName = 'light' | 'dark';

export interface ThemeContextValue {
  // Theme identity
  themeName: ThemeName;
  isDark: boolean;

  // Full theme object
  theme: Theme;

  // Direct access to tokens
  colors: SemanticColors;
  spacing: typeof spacing;
  typography: typeof typography;
  textStyles: typeof textStyles;
  radius: typeof radius;
  shadows: typeof shadows;
  zIndex: typeof zIndex;
  animation: typeof animation;
  accessibility: typeof accessibility;

  // Theme controls
  toggleTheme: () => void;
  setTheme: (theme: ThemeName) => void;

  // Backward compatibility - legacy colors shape
  /** @deprecated Use colors directly instead */
  legacyColors: LegacyColors;
}

// =============================================================================
// CONTEXT
// =============================================================================

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

// =============================================================================
// PROVIDER
// =============================================================================

interface ThemeProviderProps {
  children: React.ReactNode;
  initialTheme?: ThemeName;
}

export function ThemeProvider({
  children,
  initialTheme = 'dark',
}: ThemeProviderProps) {
  // System color scheme
  const systemColorScheme = useColorScheme();

  // User preference from store
  const themeMode = usePreferencesStore((s) => s.themeMode);
  const setThemeMode = usePreferencesStore((s) => s.setThemeMode);

  // Resolve actual theme based on mode
  const resolvedTheme = useMemo<ThemeName>(() => {
    if (themeMode === 'system') {
      return systemColorScheme === 'dark' ? 'dark' : 'light';
    }
    return themeMode;
  }, [themeMode, systemColorScheme]);

  const themeName = resolvedTheme;
  const theme = themeName === 'dark' ? darkTheme : lightTheme;

  const toggleTheme = useCallback(() => {
    const newMode: ThemeMode = themeMode === 'dark' ? 'light' : 'dark';
    setThemeMode(newMode);
  }, [themeMode, setThemeMode]);

  const setTheme = useCallback(
    (newTheme: ThemeName) => {
      setThemeMode(newTheme);
    },
    [setThemeMode]
  );

  const value = useMemo<ThemeContextValue>(
    () => ({
      themeName,
      isDark: themeName === 'dark',
      theme,
      colors: theme.colors,
      spacing: theme.spacing,
      typography: theme.typography,
      textStyles: theme.textStyles,
      radius: theme.radius,
      shadows: theme.shadows,
      zIndex: theme.zIndex,
      animation: theme.animation,
      accessibility: theme.accessibility,
      toggleTheme,
      setTheme,
      legacyColors: toLegacyColors(theme.colors),
    }),
    [themeName, theme, toggleTheme, setTheme]
  );

  // Navigation theme integration
  const navTheme = useMemo(() => {
    const baseTheme =
      themeName === 'dark' ? NavigationDarkTheme : NavigationDefaultTheme;

    return {
      ...baseTheme,
      colors: {
        ...baseTheme.colors,
        background: theme.colors.background,
        card: theme.colors.surface,
        text: theme.colors.text,
        border: theme.colors.border,
        primary: theme.colors.primary,
        notification: theme.colors.danger,
      },
    };
  }, [themeName, theme]);

  return (
    <ThemeContext.Provider value={value}>
      <NavigationContainer theme={navTheme}>{children}</NavigationContainer>
    </ThemeContext.Provider>
  );
}

// =============================================================================
// HOOKS
// =============================================================================

/**
 * Access the full theme context
 */
export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return ctx;
}

/**
 * Access only colors (lighter context subscription)
 */
export function useColors(): SemanticColors {
  const { colors } = useTheme();
  return colors;
}

/**
 * Check if dark mode is active
 */
export function useIsDarkMode(): boolean {
  const { isDark } = useTheme();
  return isDark;
}

// =============================================================================
// UTILITY HOOKS
// =============================================================================

/**
 * Create a themed StyleSheet that updates with theme changes
 * Usage: const styles = useThemedStyles((theme) => ({ container: { ... } }))
 */
export function useThemedStyles<T>(
  createStyles: (theme: Theme) => T
): T {
  const { theme } = useTheme();
  return useMemo(() => createStyles(theme), [theme, createStyles]);
}
