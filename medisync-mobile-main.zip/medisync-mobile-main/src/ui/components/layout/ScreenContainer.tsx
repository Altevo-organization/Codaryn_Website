/**
 * MediSync ScreenContainer Component
 *
 * Base screen wrapper with safe area, theme background, and consistent padding.
 */

import React from 'react';
import {
  View,
  StyleSheet,
  ViewStyle,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, Edge } from 'react-native-safe-area-context';
import { useTheme } from '../../ThemeProvider';
import { spacing } from '../../theme';

// =============================================================================
// TYPES
// =============================================================================

export interface ScreenContainerProps {
  /** Screen content */
  children: React.ReactNode;
  /** Safe area edges to apply */
  edges?: Edge[];
  /** Disable horizontal padding */
  noPadding?: boolean;
  /** Custom horizontal padding */
  paddingHorizontal?: number;
  /** Make content scrollable */
  scrollable?: boolean;
  /** Enable pull to refresh (requires scrollable) */
  refreshing?: boolean;
  /** Pull to refresh handler */
  onRefresh?: () => void;
  /** Center content vertically */
  centerContent?: boolean;
  /** Enable keyboard avoiding behavior */
  keyboardAvoiding?: boolean;
  /** Custom container style */
  style?: ViewStyle;
  /** Custom content container style (for ScrollView) */
  contentContainerStyle?: ViewStyle;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function ScreenContainer({
  children,
  edges = ['top', 'left', 'right'],
  noPadding = false,
  paddingHorizontal: customPaddingHorizontal,
  scrollable = false,
  refreshing = false,
  onRefresh,
  centerContent = false,
  keyboardAvoiding = false,
  style,
  contentContainerStyle,
}: ScreenContainerProps) {
  const { colors, isDark } = useTheme();

  const horizontalPadding =
    customPaddingHorizontal ?? (noPadding ? 0 : spacing.lg);

  const containerStyle: ViewStyle = {
    flex: 1,
    backgroundColor: colors.background,
  };

  const innerStyle: ViewStyle = {
    flex: 1,
    paddingHorizontal: horizontalPadding,
    ...(centerContent && {
      justifyContent: 'center',
      alignItems: 'center',
    }),
  };

  const content = scrollable ? (
    <ScrollView
      style={{ flex: 1 }}
      contentContainerStyle={[
        {
          flexGrow: 1,
          paddingHorizontal: horizontalPadding,
          paddingBottom: spacing.lg,
        },
        centerContent && {
          justifyContent: 'center',
          alignItems: 'center',
        },
        contentContainerStyle,
      ]}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      refreshControl={
        onRefresh ? (
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[colors.primary]}
            tintColor={colors.primary}
          />
        ) : undefined
      }
    >
      {children}
    </ScrollView>
  ) : (
    <View style={[innerStyle, style]}>{children}</View>
  );

  const wrappedContent = keyboardAvoiding ? (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
    >
      {content}
    </KeyboardAvoidingView>
  ) : (
    content
  );

  return (
    <SafeAreaView style={containerStyle} edges={edges}>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.background}
      />
      {wrappedContent}
    </SafeAreaView>
  );
}

export default ScreenContainer;
