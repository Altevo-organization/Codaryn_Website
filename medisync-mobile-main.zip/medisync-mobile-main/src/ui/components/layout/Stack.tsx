/**
 * MediSync Stack & Row Layout Components
 *
 * Flexbox-based layout primitives with consistent spacing.
 */

import React from 'react';
import { View, ViewStyle, StyleSheet } from 'react-native';
import { spacing as spacingTokens } from '../../theme';

// =============================================================================
// TYPES
// =============================================================================

export type SpacingKey = keyof typeof spacingTokens;

export interface StackProps {
  /** Children elements */
  children: React.ReactNode;
  /** Gap between children */
  gap?: SpacingKey | number;
  /** Horizontal alignment */
  align?: 'stretch' | 'flex-start' | 'flex-end' | 'center';
  /** Vertical distribution */
  justify?:
    | 'flex-start'
    | 'flex-end'
    | 'center'
    | 'space-between'
    | 'space-around'
    | 'space-evenly';
  /** Padding */
  padding?: SpacingKey | number;
  /** Horizontal padding */
  paddingHorizontal?: SpacingKey | number;
  /** Vertical padding */
  paddingVertical?: SpacingKey | number;
  /** Fill available space */
  flex?: number;
  /** Custom style */
  style?: ViewStyle;
}

export interface RowProps extends StackProps {
  /** Wrap children to next line */
  wrap?: boolean;
}

// =============================================================================
// HELPERS
// =============================================================================

function resolveSpacing(value: SpacingKey | number | undefined): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value === 'number') return value;
  return spacingTokens[value];
}

// =============================================================================
// STACK COMPONENT (Vertical)
// =============================================================================

export function Stack({
  children,
  gap,
  align = 'stretch',
  justify = 'flex-start',
  padding,
  paddingHorizontal,
  paddingVertical,
  flex,
  style,
}: StackProps) {
  const computedStyle: ViewStyle = {
    flexDirection: 'column',
    alignItems: align,
    justifyContent: justify,
    gap: resolveSpacing(gap),
    padding: resolveSpacing(padding),
    paddingHorizontal: resolveSpacing(paddingHorizontal),
    paddingVertical: resolveSpacing(paddingVertical),
    ...(flex !== undefined && { flex }),
  };

  return <View style={[computedStyle, style]}>{children}</View>;
}

// =============================================================================
// ROW COMPONENT (Horizontal)
// =============================================================================

export function Row({
  children,
  gap,
  align = 'center',
  justify = 'flex-start',
  padding,
  paddingHorizontal,
  paddingVertical,
  flex,
  wrap = false,
  style,
}: RowProps) {
  const computedStyle: ViewStyle = {
    flexDirection: 'row',
    alignItems: align,
    justifyContent: justify,
    gap: resolveSpacing(gap),
    padding: resolveSpacing(padding),
    paddingHorizontal: resolveSpacing(paddingHorizontal),
    paddingVertical: resolveSpacing(paddingVertical),
    flexWrap: wrap ? 'wrap' : 'nowrap',
    ...(flex !== undefined && { flex }),
  };

  return <View style={[computedStyle, style]}>{children}</View>;
}

// =============================================================================
// SPACER COMPONENT
// =============================================================================

export interface SpacerProps {
  /** Size of the spacer */
  size?: SpacingKey | number;
  /** Expand to fill available space */
  flex?: number;
}

export function Spacer({ size, flex = 1 }: SpacerProps) {
  if (size !== undefined) {
    const resolvedSize = resolveSpacing(size);
    return <View style={{ width: resolvedSize, height: resolvedSize }} />;
  }

  return <View style={{ flex }} />;
}

// =============================================================================
// BOX COMPONENT (General purpose container)
// =============================================================================

export interface BoxProps {
  /** Children elements */
  children?: React.ReactNode;
  /** Flex value */
  flex?: number;
  /** Padding */
  padding?: SpacingKey | number;
  /** Horizontal padding */
  paddingHorizontal?: SpacingKey | number;
  /** Vertical padding */
  paddingVertical?: SpacingKey | number;
  /** Margin */
  margin?: SpacingKey | number;
  /** Horizontal margin */
  marginHorizontal?: SpacingKey | number;
  /** Vertical margin */
  marginVertical?: SpacingKey | number;
  /** Background color */
  backgroundColor?: string;
  /** Border radius */
  borderRadius?: number;
  /** Custom style */
  style?: ViewStyle;
}

export function Box({
  children,
  flex,
  padding,
  paddingHorizontal,
  paddingVertical,
  margin,
  marginHorizontal,
  marginVertical,
  backgroundColor,
  borderRadius,
  style,
}: BoxProps) {
  const computedStyle: ViewStyle = {
    ...(flex !== undefined && { flex }),
    padding: resolveSpacing(padding),
    paddingHorizontal: resolveSpacing(paddingHorizontal),
    paddingVertical: resolveSpacing(paddingVertical),
    margin: resolveSpacing(margin),
    marginHorizontal: resolveSpacing(marginHorizontal),
    marginVertical: resolveSpacing(marginVertical),
    backgroundColor,
    borderRadius,
  };

  return <View style={[computedStyle, style]}>{children}</View>;
}

// =============================================================================
// CENTER COMPONENT
// =============================================================================

export interface CenterProps {
  /** Children elements */
  children: React.ReactNode;
  /** Fill available space */
  flex?: number;
  /** Custom style */
  style?: ViewStyle;
}

export function Center({ children, flex = 1, style }: CenterProps) {
  return (
    <View
      style={[
        {
          flex,
          alignItems: 'center',
          justifyContent: 'center',
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export default Stack;
