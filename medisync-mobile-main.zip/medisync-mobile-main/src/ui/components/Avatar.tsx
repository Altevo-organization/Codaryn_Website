/**
 * MediSync Avatar Component
 *
 * User/patient avatar with initials fallback and status indicator.
 */

import React from 'react';
import { View, Text, Image, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, radius, typography } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export interface AvatarProps {
  /** Full name (used for initials) */
  name?: string;
  /** Image source URI */
  imageUri?: string;
  /** Size preset */
  size?: AvatarSize;
  /** Background color override */
  backgroundColor?: string;
  /** Show online status indicator */
  showStatus?: boolean;
  /** Online status */
  isOnline?: boolean;
  /** Custom style */
  style?: ViewStyle;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Avatar({
  name,
  imageUri,
  size = 'md',
  backgroundColor,
  showStatus = false,
  isOnline = false,
  style,
}: AvatarProps) {
  const { colors } = useTheme();

  const sizeValue = getSizeValue(size);
  const initials = getInitials(name);

  const containerStyle: ViewStyle = {
    width: sizeValue,
    height: sizeValue,
    borderRadius: sizeValue / 2,
    backgroundColor: backgroundColor || colors.primaryMuted,
  };

  return (
    <View style={[styles.container, containerStyle, style]}>
      {imageUri ? (
        <Image
          source={{ uri: imageUri }}
          style={[styles.image, { borderRadius: sizeValue / 2 }]}
          resizeMode="cover"
        />
      ) : (
        <Text
          style={[
            styles.initials,
            { fontSize: sizeValue * 0.4, color: colors.primary },
          ]}
        >
          {initials}
        </Text>
      )}

      {showStatus && (
        <View
          style={[
            styles.statusIndicator,
            {
              backgroundColor: isOnline ? colors.success : colors.textTertiary,
              borderColor: colors.surface,
              width: sizeValue * 0.28,
              height: sizeValue * 0.28,
              borderRadius: sizeValue * 0.14,
            },
          ]}
        />
      )}
    </View>
  );
}

// =============================================================================
// HELPERS
// =============================================================================

function getSizeValue(size: AvatarSize): number {
  switch (size) {
    case 'xs':
      return 28;
    case 'sm':
      return 36;
    case 'md':
      return 44;
    case 'lg':
      return 56;
    case 'xl':
      return 72;
    default:
      return 44;
  }
}

function getInitials(name?: string): string {
  if (!name) return '?';

  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return parts[0].charAt(0).toUpperCase();
  }

  return (
    parts[0].charAt(0).toUpperCase() +
    parts[parts.length - 1].charAt(0).toUpperCase()
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  initials: {
    fontWeight: typography.weight.semibold,
  },
  statusIndicator: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    borderWidth: 2,
  },
});

export default Avatar;
