/**
 * MediSync ListItem Component
 *
 * Versatile list row with support for leading/trailing content.
 * Touch target minimum 44px for accessibility.
 */

import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, radius, typography, accessibility } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export interface ListItemProps {
  /** Primary text */
  title: string;
  /** Secondary text */
  subtitle?: string;
  /** Tertiary text (e.g., meta info) */
  meta?: string;
  /** Leading element (icon, avatar, etc.) */
  leading?: React.ReactNode;
  /** Trailing element (chevron, badge, switch, etc.) */
  trailing?: React.ReactNode;
  /** Press handler */
  onPress?: () => void;
  /** Long press handler */
  onLongPress?: () => void;
  /** Disabled state */
  disabled?: boolean;
  /** Show bottom border */
  showDivider?: boolean;
  /** Background variant */
  variant?: 'default' | 'card';
  /** Custom style */
  style?: ViewStyle;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function ListItem({
  title,
  subtitle,
  meta,
  leading,
  trailing,
  onPress,
  onLongPress,
  disabled = false,
  showDivider = false,
  variant = 'default',
  style,
}: ListItemProps) {
  const { colors } = useTheme();

  const isInteractive = Boolean(onPress || onLongPress);

  const containerStyles: ViewStyle[] = [
    styles.container,
    { minHeight: accessibility.minTouchTarget },
    variant === 'card' && {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: radius.md,
      marginBottom: spacing.sm,
    },
    showDivider && {
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    disabled && { opacity: 0.5 },
    style,
  ];

  const content = (
    <>
      {leading && <View style={styles.leading}>{leading}</View>}

      <View style={styles.content}>
        <Text
          style={[styles.title, { color: colors.text }]}
          numberOfLines={1}
        >
          {title}
        </Text>

        {subtitle && (
          <Text
            style={[styles.subtitle, { color: colors.textSecondary }]}
            numberOfLines={2}
          >
            {subtitle}
          </Text>
        )}

        {meta && (
          <Text
            style={[styles.meta, { color: colors.textTertiary }]}
            numberOfLines={1}
          >
            {meta}
          </Text>
        )}
      </View>

      {trailing && <View style={styles.trailing}>{trailing}</View>}
    </>
  );

  if (isInteractive && !disabled) {
    return (
      <TouchableOpacity
        style={containerStyles}
        onPress={onPress}
        onLongPress={onLongPress}
        activeOpacity={0.6}
        accessibilityRole="button"
      >
        {content}
      </TouchableOpacity>
    );
  }

  return <View style={containerStyles}>{content}</View>;
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  leading: {
    marginRight: spacing.md,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: typography.size.base,
    fontWeight: typography.weight.medium,
  },
  subtitle: {
    fontSize: typography.size.sm,
    marginTop: spacing.xxs,
    lineHeight: typography.size.sm * typography.lineHeight.normal,
  },
  meta: {
    fontSize: typography.size.xs,
    marginTop: spacing.xxs,
  },
  trailing: {
    marginLeft: spacing.md,
  },
});

export default ListItem;
