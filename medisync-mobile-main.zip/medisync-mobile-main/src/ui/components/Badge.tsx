/**
 * MediSync Badge Component
 *
 * Status indicators and labels with semantic colors.
 */

import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, radius, typography } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export type BadgeVariant =
  | 'default'
  | 'primary'
  | 'success'
  | 'warning'
  | 'danger'
  | 'muted';

export type BadgeSize = 'sm' | 'md';

export interface BadgeProps {
  /** Badge label */
  label: string;
  /** Semantic color variant */
  variant?: BadgeVariant;
  /** Size preset */
  size?: BadgeSize;
  /** Icon element to show before label */
  icon?: React.ReactNode;
  /** Container style */
  style?: ViewStyle;
  /** Label style */
  labelStyle?: TextStyle;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Badge({
  label,
  variant = 'default',
  size = 'md',
  icon,
  style,
  labelStyle,
}: BadgeProps) {
  const { colors } = useTheme();

  const variantStyles = getVariantStyles(variant, colors);
  const sizeStyles = getSizeStyles(size);

  return (
    <View
      style={[
        styles.base,
        sizeStyles.container,
        { backgroundColor: variantStyles.backgroundColor },
        style,
      ]}
    >
      {icon && <View style={styles.icon}>{icon}</View>}
      <Text
        style={[
          styles.label,
          sizeStyles.label,
          { color: variantStyles.textColor },
          labelStyle,
        ]}
        numberOfLines={1}
      >
        {label}
      </Text>
    </View>
  );
}

// =============================================================================
// HELPERS
// =============================================================================

function getVariantStyles(
  variant: BadgeVariant,
  colors: ReturnType<typeof useTheme>['colors']
): { backgroundColor: string; textColor: string } {
  switch (variant) {
    case 'primary':
      return {
        backgroundColor: colors.primaryMuted,
        textColor: colors.primary,
      };

    case 'success':
      return {
        backgroundColor: colors.successMuted,
        textColor: colors.success,
      };

    case 'warning':
      return {
        backgroundColor: colors.warningMuted,
        textColor: colors.warning,
      };

    case 'danger':
      return {
        backgroundColor: colors.dangerMuted,
        textColor: colors.danger,
      };

    case 'muted':
      return {
        backgroundColor: colors.backgroundTertiary,
        textColor: colors.textSecondary,
      };

    case 'default':
    default:
      return {
        backgroundColor: colors.backgroundTertiary,
        textColor: colors.text,
      };
  }
}

function getSizeStyles(size: BadgeSize): {
  container: ViewStyle;
  label: TextStyle;
} {
  switch (size) {
    case 'sm':
      return {
        container: {
          paddingVertical: spacing.xxs,
          paddingHorizontal: spacing.sm,
        },
        label: {
          fontSize: typography.size.xs,
        },
      };

    case 'md':
    default:
      return {
        container: {
          paddingVertical: spacing.xs,
          paddingHorizontal: spacing.md,
        },
        label: {
          fontSize: typography.size.sm,
        },
      };
  }
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    borderRadius: radius.full,
  },
  icon: {
    marginRight: spacing.xs,
  },
  label: {
    fontWeight: typography.weight.medium,
  },
});

export default Badge;
