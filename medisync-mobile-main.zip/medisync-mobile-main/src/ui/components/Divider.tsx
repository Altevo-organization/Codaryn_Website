/**
 * MediSync Divider Component
 *
 * Visual separator for content sections.
 */

import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, typography } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export interface DividerProps {
  /** Optional label text */
  label?: string;
  /** Orientation */
  orientation?: 'horizontal' | 'vertical';
  /** Spacing around the divider */
  spacing?: 'none' | 'sm' | 'md' | 'lg';
  /** Custom style */
  style?: ViewStyle;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Divider({
  label,
  orientation = 'horizontal',
  spacing: spacingProp = 'md',
  style,
}: DividerProps) {
  const { colors } = useTheme();

  const spacingValue = getSpacingValue(spacingProp);

  if (orientation === 'vertical') {
    return (
      <View
        style={[
          styles.vertical,
          {
            backgroundColor: colors.border,
            marginHorizontal: spacingValue,
          },
          style,
        ]}
      />
    );
  }

  // Horizontal with optional label
  if (label) {
    return (
      <View
        style={[
          styles.horizontalContainer,
          { marginVertical: spacingValue },
          style,
        ]}
      >
        <View style={[styles.line, { backgroundColor: colors.border }]} />
        <Text style={[styles.label, { color: colors.textTertiary }]}>
          {label}
        </Text>
        <View style={[styles.line, { backgroundColor: colors.border }]} />
      </View>
    );
  }

  return (
    <View
      style={[
        styles.horizontal,
        {
          backgroundColor: colors.border,
          marginVertical: spacingValue,
        },
        style,
      ]}
    />
  );
}

// =============================================================================
// HELPERS
// =============================================================================

function getSpacingValue(spacingProp: 'none' | 'sm' | 'md' | 'lg'): number {
  switch (spacingProp) {
    case 'none':
      return 0;
    case 'sm':
      return spacing.sm;
    case 'md':
      return spacing.md;
    case 'lg':
      return spacing.lg;
    default:
      return spacing.md;
  }
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  horizontal: {
    height: 1,
    width: '100%',
  },
  vertical: {
    width: 1,
    alignSelf: 'stretch',
  },
  horizontalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  line: {
    flex: 1,
    height: 1,
  },
  label: {
    fontSize: typography.size.xs,
    fontWeight: typography.weight.medium,
    marginHorizontal: spacing.md,
    textTransform: 'uppercase',
    letterSpacing: typography.letterSpacing.wide,
  },
});

export default Divider;
