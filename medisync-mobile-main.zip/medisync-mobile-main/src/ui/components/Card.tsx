/**
 * MediSync Card Component
 *
 * Versatile card container with variants and press support.
 */

import React from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, radius, shadows } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export type CardVariant = 'elevated' | 'outlined' | 'filled';

export interface CardProps {
  /** Card content */
  children: React.ReactNode;
  /** Visual variant */
  variant?: CardVariant;
  /** Press handler (makes card touchable) */
  onPress?: () => void;
  /** Long press handler */
  onLongPress?: () => void;
  /** Disabled state */
  disabled?: boolean;
  /** Padding preset */
  padding?: 'none' | 'sm' | 'md' | 'lg';
  /** Custom style */
  style?: StyleProp<ViewStyle>;
  /** Accessibility label */
  accessibilityLabel?: string;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Card({
  children,
  variant = 'outlined',
  onPress,
  onLongPress,
  disabled = false,
  padding = 'md',
  style,
  accessibilityLabel,
}: CardProps) {
  const { colors } = useTheme();

  const variantStyles = getVariantStyles(variant, colors);
  const paddingValue = getPaddingValue(padding);

  const cardStyle: ViewStyle = {
    ...styles.base,
    ...variantStyles,
    padding: paddingValue,
    ...(disabled && { opacity: 0.5 }),
  };

  // If touchable
  if (onPress || onLongPress) {
    return (
      <TouchableOpacity
        style={[cardStyle, style]}
        onPress={onPress}
        onLongPress={onLongPress}
        disabled={disabled}
        activeOpacity={0.7}
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
      >
        {children}
      </TouchableOpacity>
    );
  }

  // Static card
  return (
    <View
      style={[cardStyle, style]}
      accessibilityLabel={accessibilityLabel}
    >
      {children}
    </View>
  );
}

// =============================================================================
// HELPERS
// =============================================================================

function getVariantStyles(
  variant: CardVariant,
  colors: ReturnType<typeof useTheme>['colors']
): ViewStyle {
  switch (variant) {
    case 'elevated':
      return {
        backgroundColor: colors.surface,
        ...shadows.md,
      };

    case 'outlined':
      return {
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
      };

    case 'filled':
      return {
        backgroundColor: colors.backgroundSecondary,
      };

    default:
      return {
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
      };
  }
}

function getPaddingValue(padding: 'none' | 'sm' | 'md' | 'lg'): number {
  switch (padding) {
    case 'none':
      return 0;
    case 'sm':
      return spacing.sm;
    case 'md':
      return spacing.lg;
    case 'lg':
      return spacing.xl;
    default:
      return spacing.lg;
  }
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  base: {
    borderRadius: radius.lg,
    overflow: 'hidden',
  },
});

export default Card;
