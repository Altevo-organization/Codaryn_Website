/**
 * MediSync Skeleton Component
 *
 * Loading placeholder with subtle animation.
 */

import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '../ThemeProvider';
import { radius, spacing } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export type SkeletonVariant = 'text' | 'circular' | 'rectangular' | 'rounded';

export interface SkeletonProps {
  /** Shape variant */
  variant?: SkeletonVariant;
  /** Width (number or string like '100%') */
  width?: number | string;
  /** Height (number or string) */
  height?: number | string;
  /** Border radius override */
  borderRadius?: number;
  /** Disable animation */
  disableAnimation?: boolean;
  /** Custom style */
  style?: ViewStyle;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Skeleton({
  variant = 'text',
  width,
  height,
  borderRadius,
  disableAnimation = false,
  style,
}: SkeletonProps) {
  const { colors, isDark } = useTheme();
  const opacity = useRef(new Animated.Value(0.5)).current;

  useEffect(() => {
    if (disableAnimation) return;

    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0.5,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    );

    animation.start();

    return () => animation.stop();
  }, [opacity, disableAnimation]);

  const variantStyles = getVariantStyles(variant, width, height, borderRadius);

  return (
    <Animated.View
      style={[
        styles.base,
        {
          backgroundColor: isDark
            ? 'rgba(255, 255, 255, 0.1)'
            : 'rgba(0, 0, 0, 0.08)',
          opacity: disableAnimation ? 0.7 : opacity,
        },
        variantStyles,
        style,
      ]}
    />
  );
}

// =============================================================================
// SKELETON PRESETS
// =============================================================================

/** Skeleton for a text line */
export function SkeletonText({
  width = '100%',
  ...props
}: Omit<SkeletonProps, 'variant'>) {
  return <Skeleton variant="text" width={width} {...props} />;
}

/** Skeleton for an avatar */
export function SkeletonAvatar({
  size = 44,
  ...props
}: Omit<SkeletonProps, 'variant' | 'width' | 'height'> & { size?: number }) {
  return <Skeleton variant="circular" width={size} height={size} {...props} />;
}

/** Skeleton for a card */
export function SkeletonCard({
  height = 120,
  ...props
}: Omit<SkeletonProps, 'variant'>) {
  return <Skeleton variant="rounded" width="100%" height={height} {...props} />;
}

/** Pre-built skeleton for a list item */
export function SkeletonListItem() {
  return (
    <View style={skeletonStyles.listItem}>
      <SkeletonAvatar size={44} />
      <View style={skeletonStyles.listItemContent}>
        <SkeletonText width="70%" height={16} />
        <SkeletonText width="50%" height={14} style={{ marginTop: spacing.xs }} />
      </View>
    </View>
  );
}

// =============================================================================
// HELPERS
// =============================================================================

function getVariantStyles(
  variant: SkeletonVariant,
  width?: number | string,
  height?: number | string,
  borderRadiusOverride?: number
): ViewStyle {
  switch (variant) {
    case 'text':
      return {
        width: width ?? '100%',
        height: height ?? 16,
        borderRadius: borderRadiusOverride ?? radius.xs,
      };

    case 'circular':
      const size = typeof width === 'number' ? width : 44;
      return {
        width: size,
        height: size,
        borderRadius: size / 2,
      };

    case 'rectangular':
      return {
        width: width ?? '100%',
        height: height ?? 100,
        borderRadius: borderRadiusOverride ?? 0,
      };

    case 'rounded':
      return {
        width: width ?? '100%',
        height: height ?? 100,
        borderRadius: borderRadiusOverride ?? radius.md,
      };

    default:
      return {
        width: width ?? '100%',
        height: height ?? 16,
        borderRadius: borderRadiusOverride ?? radius.xs,
      };
  }
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  base: {
    overflow: 'hidden',
  },
});

const skeletonStyles = StyleSheet.create({
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  listItemContent: {
    flex: 1,
    marginLeft: spacing.md,
  },
});

export default Skeleton;
