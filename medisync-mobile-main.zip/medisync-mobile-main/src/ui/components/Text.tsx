/**
 * MediSync Text Component
 *
 * Typography component with preset styles and theme awareness.
 */

import React from 'react';
import { Text as RNText, TextStyle, TextProps as RNTextProps } from 'react-native';
import { useTheme } from '../ThemeProvider';
import { textStyles } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export type TextVariant =
  | 'displayLarge'
  | 'h1'
  | 'h2'
  | 'h3'
  | 'h4'
  | 'bodyLarge'
  | 'body'
  | 'bodySmall'
  | 'label'
  | 'labelSmall'
  | 'caption'
  | 'button'
  | 'buttonSmall';

export type TextColor =
  | 'primary'
  | 'secondary'
  | 'tertiary'
  | 'inverse'
  | 'danger'
  | 'success'
  | 'warning'
  | 'link';

export interface TextProps extends RNTextProps {
  /** Typography variant preset */
  variant?: TextVariant;
  /** Semantic color */
  color?: TextColor;
  /** Text alignment */
  align?: 'left' | 'center' | 'right';
  /** Bold text */
  bold?: boolean;
  /** Custom style */
  style?: TextStyle;
  /** Children content */
  children: React.ReactNode;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Text({
  variant = 'body',
  color,
  align,
  bold,
  style,
  children,
  ...props
}: TextProps) {
  const { colors } = useTheme();

  const variantStyle = textStyles[variant];
  const textColor = getColorValue(color, colors);

  const computedStyle: TextStyle = {
    ...variantStyle,
    color: textColor,
    ...(align && { textAlign: align }),
    ...(bold && { fontWeight: '700' }),
  };

  return (
    <RNText style={[computedStyle, style]} {...props}>
      {children}
    </RNText>
  );
}

// =============================================================================
// HELPERS
// =============================================================================

function getColorValue(
  color: TextColor | undefined,
  colors: ReturnType<typeof useTheme>['colors']
): string {
  if (!color) return colors.text;

  switch (color) {
    case 'primary':
      return colors.text;
    case 'secondary':
      return colors.textSecondary;
    case 'tertiary':
      return colors.textTertiary;
    case 'inverse':
      return colors.textInverse;
    case 'danger':
      return colors.danger;
    case 'success':
      return colors.success;
    case 'warning':
      return colors.warning;
    case 'link':
      return colors.link;
    default:
      return colors.text;
  }
}

// =============================================================================
// CONVENIENCE EXPORTS
// =============================================================================

// Pre-configured heading components
export const H1 = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="h1" {...props} />
);

export const H2 = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="h2" {...props} />
);

export const H3 = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="h3" {...props} />
);

export const H4 = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="h4" {...props} />
);

// Pre-configured body text
export const Body = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="body" {...props} />
);

export const BodySmall = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="bodySmall" {...props} />
);

// Pre-configured UI text
export const Label = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="label" {...props} />
);

export const Caption = (props: Omit<TextProps, 'variant'>) => (
  <Text variant="caption" {...props} />
);

export default Text;
