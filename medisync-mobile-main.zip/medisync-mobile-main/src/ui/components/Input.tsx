/**
 * MediSync Input Component
 *
 * Text input with label, helper text, error state, and icons.
 * Accessible and theme-aware.
 */

import React, { useState, useCallback, forwardRef } from 'react';
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
  TextInputProps,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, radius, typography, accessibility } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export interface InputProps extends Omit<TextInputProps, 'style'> {
  /** Input label */
  label?: string;
  /** Helper text below input */
  helper?: string;
  /** Error message (shows error state when provided) */
  error?: string;
  /** Icon element on the left */
  iconLeft?: React.ReactNode;
  /** Icon element on the right (or action button) */
  iconRight?: React.ReactNode;
  /** Press handler for right icon */
  onPressIconRight?: () => void;
  /** Disabled state */
  disabled?: boolean;
  /** Container style */
  containerStyle?: ViewStyle;
  /** Input field style */
  inputStyle?: TextStyle;
  /** Required field indicator */
  required?: boolean;
}

// =============================================================================
// COMPONENT
// =============================================================================

export const Input = forwardRef<TextInput, InputProps>(
  (
    {
      label,
      helper,
      error,
      iconLeft,
      iconRight,
      onPressIconRight,
      disabled = false,
      containerStyle,
      inputStyle,
      required = false,
      placeholder,
      ...textInputProps
    },
    ref
  ) => {
    const { colors } = useTheme();
    const [isFocused, setIsFocused] = useState(false);

    const hasError = Boolean(error);
    const showHelper = helper && !hasError;

    const handleFocus = useCallback(
      (e: any) => {
        setIsFocused(true);
        textInputProps.onFocus?.(e);
      },
      [textInputProps.onFocus]
    );

    const handleBlur = useCallback(
      (e: any) => {
        setIsFocused(false);
        textInputProps.onBlur?.(e);
      },
      [textInputProps.onBlur]
    );

    // Border color based on state
    const getBorderColor = () => {
      if (hasError) return colors.danger;
      if (isFocused) return colors.borderFocus;
      return colors.border;
    };

    return (
      <View style={[styles.container, containerStyle]}>
        {/* Label */}
        {label && (
          <Text style={[styles.label, { color: colors.text }]}>
            {label}
            {required && (
              <Text style={{ color: colors.danger }}> *</Text>
            )}
          </Text>
        )}

        {/* Input field */}
        <View
          style={[
            styles.inputContainer,
            {
              backgroundColor: colors.surface,
              borderColor: getBorderColor(),
            },
            isFocused && styles.inputFocused,
            hasError && styles.inputError,
            disabled && styles.inputDisabled,
          ]}
        >
          {iconLeft && <View style={styles.iconLeft}>{iconLeft}</View>}

          <TextInput
            ref={ref}
            style={[
              styles.input,
              { color: colors.text },
              iconLeft && styles.inputWithLeftIcon,
              iconRight && styles.inputWithRightIcon,
              inputStyle,
            ]}
            placeholder={placeholder}
            placeholderTextColor={colors.textTertiary}
            editable={!disabled}
            onFocus={handleFocus}
            onBlur={handleBlur}
            selectionColor={colors.primary}
            {...textInputProps}
          />

          {iconRight && (
            <TouchableOpacity
              style={styles.iconRight}
              onPress={onPressIconRight}
              disabled={!onPressIconRight || disabled}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              {iconRight}
            </TouchableOpacity>
          )}
        </View>

        {/* Helper / Error text */}
        {(showHelper || hasError) && (
          <Text
            style={[
              styles.helperText,
              { color: hasError ? colors.danger : colors.textSecondary },
            ]}
          >
            {hasError ? error : helper}
          </Text>
        )}
      </View>
    );
  }
);

Input.displayName = 'Input';

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  label: {
    fontSize: typography.size.md,
    fontWeight: typography.weight.medium,
    marginBottom: spacing.xs,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: radius.md,
    minHeight: accessibility.minTouchTarget + 4,
  },
  inputFocused: {
    borderWidth: 2,
  },
  inputError: {
    borderWidth: 1.5,
  },
  inputDisabled: {
    opacity: 0.5,
  },
  input: {
    flex: 1,
    fontSize: typography.size.base,
    paddingHorizontal: spacing.md,
    paddingVertical: Platform.OS === 'ios' ? spacing.md : spacing.sm,
    minHeight: accessibility.minTouchTarget,
  },
  inputWithLeftIcon: {
    paddingLeft: spacing.xs,
  },
  inputWithRightIcon: {
    paddingRight: spacing.xs,
  },
  iconLeft: {
    paddingLeft: spacing.md,
  },
  iconRight: {
    paddingRight: spacing.md,
  },
  helperText: {
    fontSize: typography.size.sm,
    marginTop: spacing.xs,
  },
});

export default Input;
