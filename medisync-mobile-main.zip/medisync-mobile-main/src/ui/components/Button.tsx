/**
 * MediSync Button Component
 *
 * Accessible button with multiple variants, sizes, and states.
 * Touch target minimum 44px for accessibility.
 */

import React, { useCallback } from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
  ActivityIndicator,
  View,
} from 'react-native';
import { useTheme } from '../ThemeProvider';
import { spacing, radius, typography, accessibility } from '../theme';

// =============================================================================
// TYPES
// =============================================================================

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  /** Button label text */
  label: string;
  /** Press handler */
  onPress: () => void;
  /** Visual variant */
  variant?: ButtonVariant;
  /** Size preset */
  size?: ButtonSize;
  /** Disabled state */
  disabled?: boolean;
  /** Loading state - shows spinner and disables interaction */
  loading?: boolean;
  /** Icon element to show before label */
  iconLeft?: React.ReactNode;
  /** Icon element to show after label */
  iconRight?: React.ReactNode;
  /** Full width button */
  fullWidth?: boolean;
  /** Custom container style */
  style?: ViewStyle;
  /** Custom label style */
  labelStyle?: TextStyle;
  /** Accessibility label (defaults to label) */
  accessibilityLabel?: string;
}

// =============================================================================
// COMPONENT
// =============================================================================

export function Button({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  iconLeft,
  iconRight,
  fullWidth = false,
  style,
  labelStyle,
  accessibilityLabel,
}: ButtonProps) {
  const { colors } = useTheme();

  const isDisabled = disabled || loading;

  // Get variant-specific styles
  const variantStyles = getVariantStyles(variant, colors, isDisabled);
  const sizeStyles = getSizeStyles(size);

  const handlePress = useCallback(() => {
    if (!isDisabled) {
      onPress();
    }
  }, [isDisabled, onPress]);

  return (
    <TouchableOpacity
      style={[
        styles.base,
        sizeStyles.container,
        variantStyles.container,
        fullWidth && styles.fullWidth,
        style,
      ]}
      onPress={handlePress}
      disabled={isDisabled}
      activeOpacity={0.7}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || label}
      accessibilityState={{ disabled: isDisabled, busy: loading }}
    >
      {loading ? (
        <ActivityIndicator
          size="small"
          color={variantStyles.textColor}
          style={styles.loader}
        />
      ) : (
        <View style={styles.content}>
          {iconLeft && <View style={styles.iconLeft}>{iconLeft}</View>}
          <Text
            style={[
              styles.label,
              sizeStyles.label,
              { color: variantStyles.textColor },
              labelStyle,
            ]}
            numberOfLines={1}
          >
            {label}
          </Text>
          {iconRight && <View style={styles.iconRight}>{iconRight}</View>}
        </View>
      )}
    </TouchableOpacity>
  );
}

// =============================================================================
// VARIANT STYLES
// =============================================================================

function getVariantStyles(
  variant: ButtonVariant,
  colors: ReturnType<typeof useTheme>['colors'],
  disabled: boolean
): { container: ViewStyle; textColor: string } {
  const opacity = disabled ? 0.5 : 1;

  switch (variant) {
    case 'primary':
      return {
        container: {
          backgroundColor: colors.primary,
          opacity,
        },
        textColor: '#FFFFFF',
      };

    case 'secondary':
      return {
        container: {
          backgroundColor: colors.primaryMuted,
          opacity,
        },
        textColor: colors.primary,
      };

    case 'outline':
      return {
        container: {
          backgroundColor: 'transparent',
          borderWidth: 1.5,
          borderColor: colors.border,
          opacity,
        },
        textColor: colors.text,
      };

    case 'ghost':
      return {
        container: {
          backgroundColor: 'transparent',
          opacity,
        },
        textColor: colors.primary,
      };

    case 'danger':
      return {
        container: {
          backgroundColor: colors.danger,
          opacity,
        },
        textColor: '#FFFFFF',
      };

    default:
      return {
        container: {
          backgroundColor: colors.primary,
          opacity,
        },
        textColor: '#FFFFFF',
      };
  }
}

// =============================================================================
// SIZE STYLES
// =============================================================================

function getSizeStyles(size: ButtonSize): {
  container: ViewStyle;
  label: TextStyle;
} {
  switch (size) {
    case 'sm':
      return {
        container: {
          paddingVertical: spacing.sm,
          paddingHorizontal: spacing.md,
          minHeight: accessibility.minTouchTarget,
        },
        label: {
          fontSize: typography.size.sm,
        },
      };

    case 'md':
      return {
        container: {
          paddingVertical: spacing.md,
          paddingHorizontal: spacing.lg,
          minHeight: accessibility.minTouchTarget + 4,
        },
        label: {
          fontSize: typography.size.md,
        },
      };

    case 'lg':
      return {
        container: {
          paddingVertical: spacing.lg,
          paddingHorizontal: spacing.xl,
          minHeight: accessibility.minTouchTarget + 12,
        },
        label: {
          fontSize: typography.size.base,
        },
      };
  }
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  base: {
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  fullWidth: {
    width: '100%',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontWeight: typography.weight.semibold,
    textAlign: 'center',
  },
  iconLeft: {
    marginRight: spacing.sm,
  },
  iconRight: {
    marginLeft: spacing.sm,
  },
  loader: {
    marginVertical: 2,
  },
});

export default Button;
