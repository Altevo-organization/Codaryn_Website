/**
 * MediSync Design System - Theme Tokens
 *
 * Palette sobre "santé" avec accent bleu médical
 * Optimisé pour lisibilité en mobilité et accessibilité WCAG AA
 */

// =============================================================================
// COLOR PALETTE
// =============================================================================

export const palette = {
  // Primary - Bleu médical / Indigo
  indigo50: '#EEF2FF',
  indigo100: '#E0E7FF',
  indigo200: '#C7D2FE',
  indigo300: '#A5B4FC',
  indigo400: '#818CF8',
  indigo500: '#6366F1',
  indigo600: '#4F46E5',
  indigo700: '#4338CA',

  // Success - Vert doux
  green50: '#F0FDF4',
  green100: '#DCFCE7',
  green400: '#4ADE80',
  green500: '#22C55E',
  green600: '#16A34A',
  green700: '#15803D',

  // Warning - Ambre
  amber50: '#FFFBEB',
  amber100: '#FEF3C7',
  amber400: '#FBBF24',
  amber500: '#F59E0B',
  amber600: '#D97706',

  // Danger - Rouge désaturé
  red50: '#FEF2F2',
  red100: '#FEE2E2',
  red400: '#F87171',
  red500: '#EF4444',
  red600: '#DC2626',

  // Neutrals
  white: '#FFFFFF',
  gray50: '#F9FAFB',
  gray100: '#F3F4F6',
  gray200: '#E5E7EB',
  gray300: '#D1D5DB',
  gray400: '#9CA3AF',
  gray500: '#6B7280',
  gray600: '#4B5563',
  gray700: '#374151',
  gray800: '#1F2937',
  gray900: '#111827',
  gray950: '#030712',

  // Dark mode specific
  dark50: '#1A1F2E',
  dark100: '#151A28',
  dark200: '#111520',
  dark300: '#0D111A',
  dark400: '#0B0E15',
} as const;

// =============================================================================
// SEMANTIC COLORS
// =============================================================================

export type SemanticColors = {
  // Backgrounds
  background: string;
  backgroundSecondary: string;
  backgroundTertiary: string;

  // Surfaces
  surface: string;
  surfaceHover: string;
  surfacePressed: string;

  // Text
  text: string;
  textSecondary: string;
  textTertiary: string;
  textInverse: string;

  // Brand
  primary: string;
  primaryHover: string;
  primaryPressed: string;
  primaryMuted: string;

  // Status
  success: string;
  successMuted: string;
  warning: string;
  warningMuted: string;
  danger: string;
  dangerMuted: string;

  // Borders
  border: string;
  borderStrong: string;
  borderFocus: string;

  // Interactive
  link: string;
  linkHover: string;

  // Overlays
  overlay: string;
  scrim: string;
};

export const lightColors: SemanticColors = {
  // Backgrounds
  background: palette.gray50,
  backgroundSecondary: palette.white,
  backgroundTertiary: palette.gray100,

  // Surfaces (cards, modals)
  surface: palette.white,
  surfaceHover: palette.gray50,
  surfacePressed: palette.gray100,

  // Text
  text: palette.gray900,
  textSecondary: palette.gray600,
  textTertiary: palette.gray400,
  textInverse: palette.white,

  // Brand
  primary: palette.indigo600,
  primaryHover: palette.indigo700,
  primaryPressed: palette.indigo700,
  primaryMuted: palette.indigo50,

  // Status
  success: palette.green600,
  successMuted: palette.green50,
  warning: palette.amber500,
  warningMuted: palette.amber50,
  danger: palette.red500,
  dangerMuted: palette.red50,

  // Borders
  border: palette.gray200,
  borderStrong: palette.gray300,
  borderFocus: palette.indigo500,

  // Interactive
  link: palette.indigo600,
  linkHover: palette.indigo700,

  // Overlays
  overlay: 'rgba(0, 0, 0, 0.5)',
  scrim: 'rgba(0, 0, 0, 0.3)',
};

export const darkColors: SemanticColors = {
  // Backgrounds
  background: palette.dark300,
  backgroundSecondary: palette.dark200,
  backgroundTertiary: palette.dark100,

  // Surfaces
  surface: palette.dark100,
  surfaceHover: palette.dark50,
  surfacePressed: palette.gray800,

  // Text
  text: palette.gray50,
  textSecondary: palette.gray400,
  textTertiary: palette.gray500,
  textInverse: palette.gray900,

  // Brand
  primary: palette.indigo400,
  primaryHover: palette.indigo300,
  primaryPressed: palette.indigo500,
  primaryMuted: 'rgba(99, 102, 241, 0.15)',

  // Status
  success: palette.green400,
  successMuted: 'rgba(74, 222, 128, 0.15)',
  warning: palette.amber400,
  warningMuted: 'rgba(251, 191, 36, 0.15)',
  danger: palette.red400,
  dangerMuted: 'rgba(248, 113, 113, 0.15)',

  // Borders
  border: palette.gray800,
  borderStrong: palette.gray700,
  borderFocus: palette.indigo400,

  // Interactive
  link: palette.indigo400,
  linkHover: palette.indigo300,

  // Overlays
  overlay: 'rgba(0, 0, 0, 0.7)',
  scrim: 'rgba(0, 0, 0, 0.5)',
};

// =============================================================================
// SPACING
// =============================================================================

export const spacing = {
  /** 0px */
  none: 0,
  /** 2px */
  xxs: 2,
  /** 4px */
  xs: 4,
  /** 8px */
  sm: 8,
  /** 12px */
  md: 12,
  /** 16px */
  lg: 16,
  /** 20px */
  xl: 20,
  /** 24px */
  xxl: 24,
  /** 32px */
  xxxl: 32,
  /** 40px */
  huge: 40,
  /** 48px */
  massive: 48,
} as const;

// =============================================================================
// TYPOGRAPHY
// =============================================================================

export const typography = {
  // Font sizes
  size: {
    /** 11px - Labels, captions */
    xs: 11,
    /** 12px - Small text, meta */
    sm: 12,
    /** 14px - Body small */
    md: 14,
    /** 16px - Body default */
    base: 16,
    /** 18px - Body large */
    lg: 18,
    /** 20px - Heading small */
    xl: 20,
    /** 24px - Heading medium */
    xxl: 24,
    /** 28px - Heading large */
    xxxl: 28,
    /** 32px - Display */
    display: 32,
  },

  // Line heights (multipliers)
  lineHeight: {
    tight: 1.2,
    normal: 1.4,
    relaxed: 1.6,
  },

  // Font weights
  weight: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },

  // Letter spacing
  letterSpacing: {
    tight: -0.5,
    normal: 0,
    wide: 0.5,
    wider: 1,
  },
} as const;

// Pre-defined text styles
export const textStyles = {
  // Display
  displayLarge: {
    fontSize: typography.size.display,
    fontWeight: typography.weight.bold,
    lineHeight: typography.size.display * typography.lineHeight.tight,
  },

  // Headings
  h1: {
    fontSize: typography.size.xxxl,
    fontWeight: typography.weight.bold,
    lineHeight: typography.size.xxxl * typography.lineHeight.tight,
  },
  h2: {
    fontSize: typography.size.xxl,
    fontWeight: typography.weight.bold,
    lineHeight: typography.size.xxl * typography.lineHeight.tight,
  },
  h3: {
    fontSize: typography.size.xl,
    fontWeight: typography.weight.semibold,
    lineHeight: typography.size.xl * typography.lineHeight.tight,
  },
  h4: {
    fontSize: typography.size.lg,
    fontWeight: typography.weight.semibold,
    lineHeight: typography.size.lg * typography.lineHeight.normal,
  },

  // Body
  bodyLarge: {
    fontSize: typography.size.base,
    fontWeight: typography.weight.regular,
    lineHeight: typography.size.base * typography.lineHeight.relaxed,
  },
  body: {
    fontSize: typography.size.md,
    fontWeight: typography.weight.regular,
    lineHeight: typography.size.md * typography.lineHeight.relaxed,
  },
  bodySmall: {
    fontSize: typography.size.sm,
    fontWeight: typography.weight.regular,
    lineHeight: typography.size.sm * typography.lineHeight.relaxed,
  },

  // UI
  label: {
    fontSize: typography.size.md,
    fontWeight: typography.weight.medium,
    lineHeight: typography.size.md * typography.lineHeight.normal,
  },
  labelSmall: {
    fontSize: typography.size.sm,
    fontWeight: typography.weight.medium,
    lineHeight: typography.size.sm * typography.lineHeight.normal,
  },
  caption: {
    fontSize: typography.size.xs,
    fontWeight: typography.weight.regular,
    lineHeight: typography.size.xs * typography.lineHeight.normal,
    letterSpacing: typography.letterSpacing.wide,
  },
  button: {
    fontSize: typography.size.md,
    fontWeight: typography.weight.semibold,
    lineHeight: typography.size.md * typography.lineHeight.normal,
  },
  buttonSmall: {
    fontSize: typography.size.sm,
    fontWeight: typography.weight.semibold,
    lineHeight: typography.size.sm * typography.lineHeight.normal,
  },
} as const;

// =============================================================================
// BORDER RADIUS
// =============================================================================

export const radius = {
  /** 0px */
  none: 0,
  /** 4px */
  xs: 4,
  /** 8px */
  sm: 8,
  /** 12px */
  md: 12,
  /** 16px */
  lg: 16,
  /** 20px */
  xl: 20,
  /** 24px */
  xxl: 24,
  /** 9999px - Pill shape */
  full: 9999,
} as const;

// =============================================================================
// SHADOWS
// =============================================================================

export const shadows = {
  none: {
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
  xl: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 8,
  },
} as const;

// =============================================================================
// Z-INDEX
// =============================================================================

export const zIndex = {
  base: 0,
  dropdown: 10,
  sticky: 20,
  fixed: 30,
  modal: 40,
  popover: 50,
  tooltip: 60,
  toast: 70,
} as const;

// =============================================================================
// ANIMATION
// =============================================================================

export const animation = {
  duration: {
    instant: 100,
    fast: 150,
    normal: 250,
    slow: 400,
  },
  easing: {
    default: 'ease-out',
    spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
} as const;

// =============================================================================
// ACCESSIBILITY
// =============================================================================

export const accessibility = {
  /** Minimum touch target size (44x44 per Apple HIG / WCAG) */
  minTouchTarget: 44,
  /** Minimum focus ring width */
  focusRingWidth: 2,
  /** Minimum contrast ratio for normal text (WCAG AA) */
  minContrastNormal: 4.5,
  /** Minimum contrast ratio for large text (WCAG AA) */
  minContrastLarge: 3,
} as const;

// =============================================================================
// THEME OBJECT
// =============================================================================

export type Theme = {
  colors: SemanticColors;
  spacing: typeof spacing;
  typography: typeof typography;
  textStyles: typeof textStyles;
  radius: typeof radius;
  shadows: typeof shadows;
  zIndex: typeof zIndex;
  animation: typeof animation;
  accessibility: typeof accessibility;
};

export const lightTheme: Theme = {
  colors: lightColors,
  spacing,
  typography,
  textStyles,
  radius,
  shadows,
  zIndex,
  animation,
  accessibility,
};

export const darkTheme: Theme = {
  colors: darkColors,
  spacing,
  typography,
  textStyles,
  radius,
  shadows,
  zIndex,
  animation,
  accessibility,
};

// =============================================================================
// BACKWARD COMPATIBILITY
// Legacy Colors type for existing components during migration
// =============================================================================

export type LegacyColors = {
  background: string;
  text: string;
  primary: string;
  muted: string;
  card: string;
  border: string;
  danger: string;
  success: string;
};

export function toLegacyColors(colors: SemanticColors): LegacyColors {
  return {
    background: colors.background,
    text: colors.text,
    primary: colors.primary,
    muted: colors.textSecondary,
    card: colors.surface,
    border: colors.border,
    danger: colors.danger,
    success: colors.success,
  };
}
