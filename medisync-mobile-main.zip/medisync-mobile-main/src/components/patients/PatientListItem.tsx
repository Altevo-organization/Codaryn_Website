/**
 * PatientListItem Component
 *
 * Card-style list item for patient display with avatar, info, and status.
 * Uses the MediSync design system for consistent styling.
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  Card,
  Avatar,
  Text,
  Badge,
  Row,
  spacing,
  useTheme,
} from '../../ui';
import type { Patient } from '../../features/patients/types';

// =============================================================================
// TYPES
// =============================================================================

interface PatientListItemProps {
  patient: Patient;
  onPress: () => void;
  onLongPress?: () => void;
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function PatientListItem({
  patient,
  onPress,
  onLongPress,
}: PatientListItemProps) {
  const { colors } = useTheme();

  const fullName = `${patient.firstName} ${patient.lastName}`;
  const displayName = `${patient.lastName.toUpperCase()} ${patient.firstName}`;

  // Format last visit date
  const lastVisitText = patient.lastVisit
    ? `Dernière visite : ${patient.lastVisit}`
    : 'Aucune visite';

  return (
    <Card
      variant="outlined"
      padding="md"
      onPress={onPress}
      onLongPress={onLongPress}
      style={styles.card}
      accessibilityLabel={`Patient ${fullName}, ${patient.disease}, ${patient.age} ans`}
    >
      <Row gap="md" align="flex-start">
        {/* Avatar */}
        <Avatar
          name={fullName}
          size="md"
        />

        {/* Content */}
        <View style={styles.content}>
          {/* Name and age row */}
          <Row justify="space-between" align="flex-start" style={styles.headerRow}>
            <View style={styles.nameContainer}>
              <Text variant="label" numberOfLines={1} style={styles.name}>
                {displayName}
              </Text>
              {patient.disease && (
                <Text
                  variant="bodySmall"
                  color="secondary"
                  numberOfLines={1}
                  style={styles.disease}
                >
                  {patient.disease}
                </Text>
              )}
            </View>

            <Badge
              label={`${patient.age} ans`}
              variant="muted"
              size="sm"
            />
          </Row>

          {/* Meta info row */}
          <Row gap="sm" align="center" style={styles.metaRow}>
            <Ionicons
              name="calendar-outline"
              size={14}
              color={colors.textTertiary}
            />
            <Text variant="caption" color="tertiary">
              {lastVisitText}
            </Text>
          </Row>
        </View>

        {/* Chevron */}
        <View style={styles.chevronContainer}>
          <Ionicons
            name="chevron-forward"
            size={20}
            color={colors.textTertiary}
          />
        </View>
      </Row>
    </Card>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing.sm,
  },
  content: {
    flex: 1,
    minHeight: 44,
  },
  headerRow: {
    flex: 1,
  },
  nameContainer: {
    flex: 1,
    marginRight: spacing.sm,
  },
  name: {
    marginBottom: spacing.xxs,
  },
  disease: {
    marginTop: spacing.xxs,
  },
  metaRow: {
    marginTop: spacing.sm,
  },
  chevronContainer: {
    justifyContent: 'center',
    alignSelf: 'center',
  },
});
