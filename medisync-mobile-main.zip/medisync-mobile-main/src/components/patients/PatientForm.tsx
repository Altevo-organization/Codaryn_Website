// src/components/patients/PatientForm.tsx
import React, { useState, useEffect, useRef, useMemo } from 'react'
import {
  View,
  StyleSheet,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native'
import AppText from '../ui/AppText'
import AppButton from '../ui/AppButton'
import { useTheme } from '../../theme/ThemeProvider'
import type { Patient } from '../../features/patients/types'
import type {
  CreatePatientPayload,
  UpdatePatientPayload,
} from '../../features/patients/api'
import { Ionicons } from '@expo/vector-icons'
import { TouchableOpacity } from 'react-native'

interface PatientFormProps {
  mode: 'create' | 'edit'
  initialPatient?: Patient
  onCreate?: (payload: CreatePatientPayload) => void
  onAutoSave?: (payload: UpdatePatientPayload) => void
  submitting?: boolean
  onOpenFiles?: () => void
  onExportPDF?: () => void
  exporting?: boolean
}

// ============================================================================
// UTILS
// ============================================================================

function isValidDate(value: string): boolean {
  if (!value) return false
  const regex = /^\d{4}-\d{2}-\d{2}$/
  if (!regex.test(value)) return false
  const d = new Date(value)
  return !Number.isNaN(d.getTime())
}

function parseNumberSafe(value: string): number | null {
  const trimmed = value.trim()
  if (trimmed === '') return null
  const n = Number(trimmed)
  if (!Number.isFinite(n)) return null
  return n
}

function computeBMI(heightCm: number | null, weightKg: number | null): number | null {
  if (heightCm === null || weightKg === null) return null
  if (heightCm <= 0 || weightKg <= 0) return null
  const heightM = heightCm / 100
  const bmi = weightKg / (heightM * heightM)
  return Math.round(bmi * 10) / 10
}

function getBMICategory(bmi: number | null): { label: string; color: string; bgColor: string } | null {
  if (bmi === null) return null
  if (bmi < 18.5) return { label: 'Insuffisance', color: '#B45309', bgColor: '#FEF3C7' }
  if (bmi < 25) return { label: 'Normal', color: '#15803D', bgColor: '#DCFCE7' }
  if (bmi < 30) return { label: 'Surpoids', color: '#B45309', bgColor: '#FEF3C7' }
  return { label: 'Obésité', color: '#DC2626', bgColor: '#FEE2E2' }
}

// ============================================================================
// COMPONENT
// ============================================================================

export default function PatientForm({
  mode,
  initialPatient,
  onCreate,
  onAutoSave,
  submitting,
  onOpenFiles,
  onExportPDF,
  exporting,
}: PatientFormProps) {
  const { colors, isDark } = useTheme()

  // --- State ---
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [age, setAge] = useState('')
  const [height, setHeight] = useState('')
  const [weight, setWeight] = useState('')
  const [antecedentsMedicaux, setAntecedentsMedicaux] = useState('')
  const [antecedentsChirurgicaux, setAntecedentsChirurgicaux] = useState('')
  const [diagnosticMedical, setDiagnosticMedical] = useState('')
  const [additionalInfo, setAdditionalInfo] = useState('')
  const [observations, setObservations] = useState('')
  const [diagnosisDate, setDiagnosisDate] = useState('')
  const [lastVisit, setLastVisit] = useState('')
  const [medications, setMedications] = useState('')
  const [nurse, setNurse] = useState('')

  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // IMC
  const heightNum = parseNumberSafe(height)
  const weightNum = parseNumberSafe(weight)
  const bmi = useMemo(() => computeBMI(heightNum, weightNum), [heightNum, weightNum])
  const bmiCategory = useMemo(() => getBMICategory(bmi), [bmi])

  // Init
  useEffect(() => {
    if (initialPatient) {
      setFirstName(initialPatient.firstName)
      setLastName(initialPatient.lastName)
      setAge(String(initialPatient.age))
      setHeight(String(initialPatient.height))
      setWeight(String(initialPatient.weight))
      setAntecedentsMedicaux(initialPatient.disease)
      setAntecedentsChirurgicaux(initialPatient.symptoms)
      setDiagnosticMedical(initialPatient.treatment)
      setDiagnosisDate(initialPatient.diagnosisDate)
      setMedications(initialPatient.medications)
      setLastVisit(initialPatient.lastVisit)
      setNurse(initialPatient.nurse ?? '')
      setAdditionalInfo(initialPatient.additionalInfo ?? '')
      setObservations(initialPatient.observations ?? '')
    }
  }, [initialPatient])

  const buildPayload = (
    _forMode: 'create' | 'edit',
    showAlertOnError: boolean,
  ): { ok: true; payload: CreatePatientPayload | UpdatePatientPayload } | { ok: false } => {
    const fn = firstName.trim()
    const ln = lastName.trim()
    const antMed = antecedentsMedicaux.trim()
    const antChir = antecedentsChirurgicaux.trim()
    const diag = diagnosticMedical.trim()
    const meds = medications.trim()
    const diagDate = diagnosisDate.trim()
    const last = lastVisit.trim()

    const ageNum = parseNumberSafe(age)
    const hNum = parseNumberSafe(height)
    const wNum = parseNumberSafe(weight)

    const errorMsgs: string[] = []

    if (!ln || !fn) errorMsgs.push('Nom et prénom sont obligatoires.')
    if (ageNum === null || ageNum < 0 || ageNum > 150) errorMsgs.push("L'âge doit être entre 0 et 150.")
    if (hNum === null || hNum < 0 || hNum > 300) errorMsgs.push('La taille doit être entre 0 et 300 cm.')
    if (wNum === null || wNum < 0 || wNum > 500) errorMsgs.push('Le poids doit être entre 0 et 500 kg.')
    if (!antMed) errorMsgs.push('Les antécédents médicaux sont obligatoires.')
    if (!antChir) errorMsgs.push('Les antécédents chirurgicaux sont obligatoires.')
    if (!meds) errorMsgs.push('Les médicaments sont obligatoires.')
    if (!diag) errorMsgs.push('Le diagnostic médical est obligatoire.')
    if (!isValidDate(diagDate) || !isValidDate(last)) {
      errorMsgs.push('Les dates doivent être au format YYYY-MM-DD.')
    }

    if (errorMsgs.length > 0) {
      if (showAlertOnError) Alert.alert('Formulaire incomplet', errorMsgs.join('\n'))
      return { ok: false }
    }

    return {
      ok: true,
      payload: {
        firstName: fn,
        lastName: ln,
        age: ageNum!,
        height: hNum!,
        weight: wNum!,
        disease: antMed,
        diagnosisDate: diagDate,
        symptoms: antChir,
        medications: meds,
        treatment: diag,
        lastVisit: last,
        nurse: nurse.trim() || undefined,
        additionalInfo: additionalInfo.trim() || undefined,
        observations: observations.trim() || undefined,
      },
    }
  }

  const handleCreateSubmit = () => {
    if (!onCreate) return
    const result = buildPayload('create', true)
    if (!result.ok) return
    onCreate(result.payload as CreatePatientPayload)
  }

  // Auto-save
  useEffect(() => {
    if (mode !== 'edit' || !onAutoSave) return
    if (debounceTimer.current) clearTimeout(debounceTimer.current)
    debounceTimer.current = setTimeout(() => {
      const result = buildPayload('edit', false)
      if (result.ok) onAutoSave(result.payload as UpdatePatientPayload)
    }, 800)
    return () => { if (debounceTimer.current) clearTimeout(debounceTimer.current) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, firstName, lastName, age, height, weight, antecedentsMedicaux, antecedentsChirurgicaux, diagnosticMedical, diagnosisDate, medications, lastVisit, nurse, additionalInfo, observations])

  // ============================================================================
  // STYLES DYNAMIQUES
  // ============================================================================

  const cardStyle = {
    backgroundColor: isDark ? colors.surface : '#FFFFFF',
    borderRadius: 14,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: isDark ? 0.3 : 0.06,
    shadowRadius: 8,
    elevation: 2,
  }

  const inputBaseStyle = {
    backgroundColor: isDark ? colors.backgroundTertiary : '#F8FAFC',
    borderWidth: 1,
    borderColor: isDark ? colors.border : '#E2E8F0',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: colors.text,
  }

  const textareaStyle = {
    ...inputBaseStyle,
    minHeight: 80,
    textAlignVertical: 'top' as const,
  }

  const labelStyle = {
    fontSize: 13,
    fontWeight: '500' as const,
    color: colors.textSecondary,
    marginBottom: 6,
  }

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: isDark ? colors.background : '#F1F5F9' }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* ================================================================
            HEADER - Identité patient
        ================================================================ */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <AppText style={[styles.patientName, { color: colors.text }]}>
              {mode === 'create'
                ? 'Nouveau patient'
                : `${firstName} ${lastName}`.trim() || 'Patient'}
            </AppText>
            <AppText style={[styles.headerSubtitle, { color: colors.textSecondary }]}>
              Dossier patient
            </AppText>
          </View>
          {mode === 'edit' && (
            <View style={styles.headerButtons}>
              {onExportPDF && (
                <TouchableOpacity
                  onPress={onExportPDF}
                  style={[styles.headerButton, { borderColor: colors.border }]}
                  activeOpacity={0.7}
                  disabled={exporting}
                >
                  <Ionicons
                    name="download-outline"
                    size={16}
                    color={exporting ? colors.textTertiary : colors.textSecondary}
                  />
                  <AppText
                    style={[
                      styles.headerButtonText,
                      { color: exporting ? colors.textTertiary : colors.textSecondary }
                    ]}
                  >
                    {exporting ? 'Export...' : 'Exporter'}
                  </AppText>
                </TouchableOpacity>
              )}
              {onOpenFiles && (
                <TouchableOpacity
                  onPress={onOpenFiles}
                  style={[styles.headerButton, { borderColor: colors.border }]}
                  activeOpacity={0.7}
                >
                  <Ionicons name="folder-outline" size={16} color={colors.textSecondary} />
                  <AppText style={[styles.headerButtonText, { color: colors.textSecondary }]}>
                    Documents
                  </AppText>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>

        {/* ================================================================
            SECTION 1: INFORMATIONS GÉNÉRALES + IMC
        ================================================================ */}
        <View style={cardStyle}>
          <AppText style={[styles.sectionLabel, { color: colors.textTertiary }]}>
            INFORMATIONS GÉNÉRALES
          </AppText>

          <View style={styles.infoRow}>
            {/* Zone gauche : champs */}
            <View style={styles.fieldsZone}>
              {/* Ligne 1: Nom / Prénom */}
              <View style={styles.fieldRow}>
                <View style={styles.fieldHalf}>
                  <AppText style={labelStyle}>Nom</AppText>
                  <TextInput
                    value={lastName}
                    onChangeText={setLastName}
                    placeholder="DUPONT"
                    placeholderTextColor={colors.textTertiary}
                    style={inputBaseStyle}
                    autoCapitalize="characters"
                  />
                </View>
                <View style={styles.fieldHalf}>
                  <AppText style={labelStyle}>Prénom</AppText>
                  <TextInput
                    value={firstName}
                    onChangeText={setFirstName}
                    placeholder="Marie"
                    placeholderTextColor={colors.textTertiary}
                    style={inputBaseStyle}
                    autoCapitalize="words"
                  />
                </View>
              </View>

              {/* Ligne 2: Âge */}
              <View style={[styles.fieldRow, { marginTop: 12 }]}>
                <View style={styles.fieldCompact}>
                  <AppText style={labelStyle}>Âge</AppText>
                  <TextInput
                    value={age}
                    onChangeText={(v) => setAge(v.replace(/[^0-9]/g, ''))}
                    placeholder="65"
                    placeholderTextColor={colors.textTertiary}
                    style={inputBaseStyle}
                    keyboardType="numeric"
                    maxLength={3}
                  />
                </View>
              </View>

              {/* Ligne 3: Taille / Poids */}
              <View style={[styles.fieldRow, { marginTop: 12 }]}>
                <View style={styles.fieldHalf}>
                  <AppText style={labelStyle}>Taille (cm)</AppText>
                  <TextInput
                    value={height}
                    onChangeText={(v) => setHeight(v.replace(/[^0-9]/g, ''))}
                    placeholder="170"
                    placeholderTextColor={colors.textTertiary}
                    style={inputBaseStyle}
                    keyboardType="numeric"
                    maxLength={3}
                  />
                </View>
                <View style={styles.fieldHalf}>
                  <AppText style={labelStyle}>Poids (kg)</AppText>
                  <TextInput
                    value={weight}
                    onChangeText={(v) => setWeight(v.replace(/[^0-9.]/g, ''))}
                    placeholder="72"
                    placeholderTextColor={colors.textTertiary}
                    style={inputBaseStyle}
                    keyboardType="decimal-pad"
                    maxLength={5}
                  />
                </View>
              </View>
            </View>

            {/* Zone droite : IMC Card */}
            <View
              style={[
                styles.bmiCard,
                {
                  backgroundColor: bmiCategory?.bgColor ?? (isDark ? colors.backgroundTertiary : '#F8FAFC'),
                  borderColor: bmiCategory?.color ?? colors.border,
                },
              ]}
            >
              <AppText style={[styles.bmiLabel, { color: colors.textTertiary }]}>
                IMC
              </AppText>
              <AppText
                style={[
                  styles.bmiValue,
                  { color: bmiCategory?.color ?? colors.textTertiary },
                ]}
              >
                {bmi !== null ? bmi.toFixed(1) : '—'}
              </AppText>
              {bmiCategory && (
                <View style={[styles.bmiPill, { backgroundColor: bmiCategory.color + '20' }]}>
                  <AppText style={[styles.bmiPillText, { color: bmiCategory.color }]}>
                    {bmiCategory.label}
                  </AppText>
                </View>
              )}
              {!bmiCategory && (
                <AppText style={[styles.bmiHint, { color: colors.textTertiary }]}>
                  Auto
                </AppText>
              )}
            </View>
          </View>
        </View>

        {/* ================================================================
            SECTION 2: PATHOLOGIE
        ================================================================ */}
        <View style={cardStyle}>
          <AppText style={[styles.sectionLabel, { color: colors.textTertiary }]}>
            PATHOLOGIE
          </AppText>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Antécédents médicaux</AppText>
            <TextInput
              value={antecedentsMedicaux}
              onChangeText={setAntecedentsMedicaux}
              placeholder="Diabète type 2, HTA, dyslipidémie..."
              placeholderTextColor={colors.textTertiary}
              style={textareaStyle}
              multiline
            />
          </View>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Antécédents chirurgicaux</AppText>
            <TextInput
              value={antecedentsChirurgicaux}
              onChangeText={setAntecedentsChirurgicaux}
              placeholder="Appendicectomie 2015, PTH droite 2020..."
              placeholderTextColor={colors.textTertiary}
              style={textareaStyle}
              multiline
            />
          </View>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Diagnostic médical</AppText>
            <TextInput
              value={diagnosticMedical}
              onChangeText={setDiagnosticMedical}
              placeholder="Insuffisance cardiaque stade II, BPCO Gold 2..."
              placeholderTextColor={colors.textTertiary}
              style={textareaStyle}
              multiline
            />
          </View>

          {/* Dates + Médicaments */}
          <View style={[styles.fieldRow, { marginTop: 4 }]}>
            <View style={styles.fieldHalf}>
              <AppText style={labelStyle}>Date diagnostic</AppText>
              <TextInput
                value={diagnosisDate}
                onChangeText={setDiagnosisDate}
                placeholder="2024-01-15"
                placeholderTextColor={colors.textTertiary}
                style={inputBaseStyle}
              />
            </View>
            <View style={styles.fieldHalf}>
              <AppText style={labelStyle}>Dernière visite</AppText>
              <TextInput
                value={lastVisit}
                onChangeText={setLastVisit}
                placeholder="2025-12-01"
                placeholderTextColor={colors.textTertiary}
                style={inputBaseStyle}
              />
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Médicaments en cours</AppText>
            <TextInput
              value={medications}
              onChangeText={setMedications}
              placeholder="Metformine 1000mg x2/j, Lisinopril 10mg..."
              placeholderTextColor={colors.textTertiary}
              style={textareaStyle}
              multiline
            />
          </View>
        </View>

        {/* ================================================================
            SECTION 3: SUIVI CLINIQUE
        ================================================================ */}
        <View style={cardStyle}>
          <AppText style={[styles.sectionLabel, { color: colors.textTertiary }]}>
            SUIVI CLINIQUE
          </AppText>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Informations complémentaires</AppText>
            <TextInput
              value={additionalInfo}
              onChangeText={setAdditionalInfo}
              placeholder="Contexte social, aidants, autonomie, allergies..."
              placeholderTextColor={colors.textTertiary}
              style={textareaStyle}
              multiline
            />
          </View>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Observations</AppText>
            <TextInput
              value={observations}
              onChangeText={setObservations}
              placeholder="Évolution clinique, tolérance traitement, points de vigilance..."
              placeholderTextColor={colors.textTertiary}
              style={[textareaStyle, { minHeight: 100 }]}
              multiline
            />
          </View>

          <View style={styles.fieldGroup}>
            <AppText style={labelStyle}>Infirmier(ère) référent(e)</AppText>
            <TextInput
              value={nurse}
              onChangeText={setNurse}
              placeholder="Nom du soignant référent"
              placeholderTextColor={colors.textTertiary}
              style={inputBaseStyle}
            />
          </View>
        </View>

        {/* ================================================================
            BOUTON CRÉER
        ================================================================ */}
        {mode === 'create' && (
          <AppButton
            label={submitting ? 'Enregistrement...' : 'Créer le dossier'}
            onPress={handleCreateSubmit}
            disabled={submitting}
            style={styles.createButton}
          />
        )}

        <View style={{ height: 32 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  )
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  scroll: {
    paddingHorizontal: 20,
    paddingTop: 16,
  },

  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  headerLeft: {
    flex: 1,
  },
  patientName: {
    fontSize: 26,
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 14,
    marginTop: 2,
    opacity: 0.7,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    gap: 6,
  },
  headerButtonText: {
    fontSize: 13,
    fontWeight: '500',
  },

  // Section
  sectionLabel: {
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 1.2,
    marginBottom: 16,
    textTransform: 'uppercase',
  },

  // Info row (champs + IMC)
  infoRow: {
    flexDirection: 'row',
    gap: 16,
  },
  fieldsZone: {
    flex: 1,
  },
  fieldRow: {
    flexDirection: 'row',
    gap: 12,
  },
  fieldHalf: {
    flex: 1,
  },
  fieldCompact: {
    flex: 1,
  },

  // IMC Card
  bmiCard: {
    width: 90,
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bmiLabel: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  bmiValue: {
    fontSize: 28,
    fontWeight: '700',
    marginVertical: 2,
  },
  bmiPill: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    marginTop: 4,
  },
  bmiPillText: {
    fontSize: 10,
    fontWeight: '600',
  },
  bmiHint: {
    fontSize: 10,
    marginTop: 4,
  },

  // Field groups
  fieldGroup: {
    marginBottom: 16,
  },

  // Create button
  createButton: {
    marginTop: 8,
  },
})
