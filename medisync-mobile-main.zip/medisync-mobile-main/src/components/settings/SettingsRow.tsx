import React from 'react'
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import { useTheme } from '../../theme/ThemeProvider'

interface SettingsRowProps {
  label: string
  description?: string
  rightElement?: React.ReactNode
  onPress?: () => void
}

export default function SettingsRow({
  label,
  description,
  rightElement,
  onPress,
}: SettingsRowProps) {
  const { colors } = useTheme()

  const Container = onPress ? TouchableOpacity : View

  return (
    <Container
      style={[styles.row, { borderBottomColor: colors.border }]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.textContainer}>
        <Text style={[styles.label, { color: colors.text }]}>{label}</Text>
        {description ? (
          <Text style={[styles.description, { color: colors.muted }]}>{description}</Text>
        ) : null}
      </View>
      {rightElement ? <View style={styles.right}>{rightElement}</View> : null}
    </Container>
  )
}

const styles = StyleSheet.create({
  row: {
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
  },
  textContainer: {
    flex: 1,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
  },
  description: {
    fontSize: 13,
    marginTop: 2,
  },
  right: {
    marginLeft: 12,
  },
})
