// src/components/messages/MessageRow.tsx
import React from 'react'
import { View, StyleSheet } from 'react-native'
import Card from '../ui/Card'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { Message } from '../../features/messages/types'

interface MessageRowProps {
  message: Message
}

function formatTimeLabel(sentAt: string) {
  const timePart = sentAt.split('T')[1] ?? ''
  const [hh, mm] = timePart.split(':')
  return `${hh}:${mm}`
}

export default function MessageRow({ message }: MessageRowProps) {
  const { colors } = useTheme()

  return (
    <Card style={[styles.card, !message.isRead && styles.unread]}>
      <View style={styles.headerRow}>
        <AppText style={styles.sender}>{message.senderName}</AppText>
        <AppText style={[styles.time, { color: colors.muted }]}>
          {formatTimeLabel(message.sentAt)}
        </AppText>
      </View>

      <AppText style={styles.subject}>{message.subject}</AppText>

      <AppText
        numberOfLines={2}
        style={[styles.preview, { color: colors.muted }]}
      >
        {message.preview}
      </AppText>
    </Card>
  )
}

const styles = StyleSheet.create({
  card: {
    marginBottom: 8,
  },
  unread: {
    borderWidth: 1.2,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  sender: {
    fontSize: 14,
    fontWeight: '600',
  },
  time: {
    fontSize: 12,
  },
  subject: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 2,
  },
  preview: {
    fontSize: 13,
  },
})
