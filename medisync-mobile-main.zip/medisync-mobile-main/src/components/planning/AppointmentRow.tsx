/**
 * AppointmentRow Component
 *
 * Display a single appointment with time, patient name, and status.
 * Redesigned with MediSync design system.
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  Card,
  Text,
  Badge,
  Row,
  Avatar,
  spacing,
  useTheme,
} from '../../ui';
import type { Appointment } from '../../features/appointments/types';

// =============================================================================
// TYPES
// =============================================================================

interface AppointmentRowProps {
  appointment: Appointment;
  onPress?: () => void;
  onLongPress?: () => void;
  compact?: boolean;
}

// =============================================================================
// HELPERS
// =============================================================================

function formatTime(iso: string): string {
  if (!iso) return '';
  const timePart = iso.split('T')[1] ?? '';
  const [hh, mm] = timePart.split(':');
  if (!hh || !mm) return '';
  return `${hh}:${mm}`;
}

type AppointmentStatus = 'upcoming' | 'ongoing' | 'completed';

function getAppointmentStatus(startDate: string, endDate: string): AppointmentStatus {
  const now = new Date();
  const start = startDate ? new Date(startDate) : now;
  const end = endDate ? new Date(endDate) : now;

  if (end < now) return 'completed';
  if (start <= now && end >= now) return 'ongoing';
  return 'upcoming';
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function AppointmentRow({
  appointment,
  onPress,
  onLongPress,
  compact = false,
}: AppointmentRowProps) {
  const { colors } = useTheme();

  const timeStart = formatTime(appointment.startDate);
  const timeEnd = formatTime(appointment.endDate);
  const timeRange = `${timeStart} - ${timeEnd}`;

  const status = getAppointmentStatus(appointment.startDate, appointment.endDate);
  const patientName = appointment.patientName ?? `Patient #${appointment.patientId}`;

  // Status badge configuration
  const statusConfig = {
    upcoming: { label: 'À venir', variant: 'primary' as const },
    ongoing: { label: 'En cours', variant: 'warning' as const },
    completed: { label: 'Terminé', variant: 'success' as const },
  };

  const { label: statusLabel, variant: statusVariant } = statusConfig[status];

  return (
    <Card
      variant="outlined"
      padding={compact ? 'sm' : 'md'}
      onPress={onPress}
      onLongPress={onLongPress}
      style={styles.card}
      accessibilityLabel={`Rendez-vous avec ${patientName} de ${timeStart} à ${timeEnd}, ${statusLabel}`}
    >
      <Row gap="md" align="center">
        {/* Time indicator */}
        <View
          style={[
            styles.timeContainer,
            { backgroundColor: colors.primaryMuted },
          ]}
        >
          <Ionicons
            name="time-outline"
            size={14}
            color={colors.primary}
            style={styles.timeIcon}
          />
          <Text variant="labelSmall" style={{ color: colors.primary }}>
            {timeStart}
          </Text>
        </View>

        {/* Content */}
        <View style={styles.content}>
          <Row justify="space-between" align="flex-start">
            <View style={styles.patientInfo}>
              <Text variant="label" numberOfLines={1}>
                {patientName}
              </Text>
              <Text variant="caption" color="tertiary" style={styles.timeRange}>
                {timeRange}
              </Text>
            </View>

            <Badge
              label={statusLabel}
              variant={statusVariant}
              size="sm"
            />
          </Row>
        </View>
      </Row>
    </Card>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing.sm,
  },
  timeContainer: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 56,
  },
  timeIcon: {
    marginBottom: spacing.xxs,
  },
  content: {
    flex: 1,
  },
  patientInfo: {
    flex: 1,
    marginRight: spacing.sm,
  },
  timeRange: {
    marginTop: spacing.xxs,
  },
});
