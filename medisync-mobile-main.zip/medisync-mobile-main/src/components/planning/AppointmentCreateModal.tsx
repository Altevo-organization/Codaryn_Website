/**
 * AppointmentCreateModal
 *
 * Modern modal for creating appointments with patient selector.
 * Features:
 * - Patient dropdown with search functionality
 * - Date picker
 * - Time range selector (start/end)
 * - Form validation
 * - Clean medical UI design
 */

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
  Modal,
  View,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';

import {
  Text,
  Button,
  Input,
  Card,
  spacing,
  radius,
  shadows,
  useTheme,
} from '../../ui';
import { usePatientsQuery } from '../../features/patients/hooks';
import type { Patient } from '../../features/patients/types';
import type { CreateAppointmentDto } from '../../features/appointments/api';

// =============================================================================
// TYPES
// =============================================================================

interface AppointmentCreateModalProps {
  visible: boolean;
  date: string; // "YYYY-MM-DD"
  onClose: () => void;
  onSubmit: (dto: CreateAppointmentDto) => void;
  onNavigateToCreatePatient?: () => void;
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function AppointmentCreateModal({
  visible,
  date,
  onClose,
  onSubmit,
  onNavigateToCreatePatient,
}: AppointmentCreateModalProps) {
  const { colors } = useTheme();

  // Form state
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date(date));
  const [startTime, setStartTime] = useState<Date>(() => {
    const d = new Date();
    d.setHours(9, 0, 0, 0);
    return d;
  });
  const [endTime, setEndTime] = useState<Date>(() => {
    const d = new Date();
    d.setHours(9, 30, 0, 0);
    return d;
  });

  // Patient search state
  const [patientSearch, setPatientSearch] = useState('');
  const [showPatientDropdown, setShowPatientDropdown] = useState(false);

  // Date/Time picker state
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);

  // Fetch patients
  const { data: patients = [], isLoading: patientsLoading } = usePatientsQuery({
    limit: 100,
  });

  // Filter patients based on search
  const filteredPatients = useMemo(() => {
    if (!patientSearch.trim()) return patients;
    const search = patientSearch.toLowerCase();
    return patients.filter(
      (p) =>
        p.firstName.toLowerCase().includes(search) ||
        p.lastName.toLowerCase().includes(search)
    );
  }, [patients, patientSearch]);

  // Reset form when modal opens with new date
  useEffect(() => {
    if (visible) {
      setSelectedDate(new Date(date + 'T00:00:00'));
      setSelectedPatient(null);
      setPatientSearch('');
      const now = new Date();
      const defaultStart = new Date();
      defaultStart.setHours(now.getHours() + 1, 0, 0, 0);
      setStartTime(defaultStart);
      const defaultEnd = new Date(defaultStart);
      defaultEnd.setMinutes(defaultEnd.getMinutes() + 30);
      setEndTime(defaultEnd);
    }
  }, [visible, date]);

  // Validation
  const isValid = useMemo(() => {
    if (!selectedPatient) return false;
    if (endTime <= startTime) return false;
    return true;
  }, [selectedPatient, startTime, endTime]);

  const timeError = useMemo(() => {
    if (endTime <= startTime) {
      return "L'heure de fin doit être après l'heure de début";
    }
    return null;
  }, [startTime, endTime]);

  // Handlers
  const handlePatientSelect = useCallback((patient: Patient) => {
    setSelectedPatient(patient);
    setPatientSearch(`${patient.firstName} ${patient.lastName}`);
    setShowPatientDropdown(false);
  }, []);

  const handleDateChange = useCallback(
    (_: any, selectedDateValue?: Date) => {
      if (Platform.OS === 'android') {
        setShowDatePicker(false);
      }
      if (selectedDateValue) {
        setSelectedDate(selectedDateValue);
      }
    },
    []
  );

  const handleStartTimeChange = useCallback(
    (_: any, selectedTime?: Date) => {
      if (Platform.OS === 'android') {
        setShowStartPicker(false);
      }
      if (selectedTime) {
        setStartTime(selectedTime);
        // Auto-adjust end time if it's before start
        if (selectedTime >= endTime) {
          const newEnd = new Date(selectedTime);
          newEnd.setMinutes(newEnd.getMinutes() + 30);
          setEndTime(newEnd);
        }
      }
    },
    [endTime]
  );

  const handleEndTimeChange = useCallback(
    (_: any, selectedTime?: Date) => {
      if (Platform.OS === 'android') {
        setShowEndPicker(false);
      }
      if (selectedTime) {
        setEndTime(selectedTime);
      }
    },
    []
  );

  const handleSubmit = useCallback(() => {
    if (!selectedPatient || !isValid) return;

    const dateStr = selectedDate.toISOString().split('T')[0];
    const startHours = startTime.getHours().toString().padStart(2, '0');
    const startMins = startTime.getMinutes().toString().padStart(2, '0');
    const endHours = endTime.getHours().toString().padStart(2, '0');
    const endMins = endTime.getMinutes().toString().padStart(2, '0');

    const startDateISO = new Date(
      `${dateStr}T${startHours}:${startMins}:00`
    ).toISOString();
    const endDateISO = new Date(
      `${dateStr}T${endHours}:${endMins}:00`
    ).toISOString();

    onSubmit({
      patientId: selectedPatient.id,
      startDate: startDateISO,
      endDate: endDateISO,
    });
  }, [selectedPatient, selectedDate, startTime, endTime, isValid, onSubmit]);

  const handleClose = useCallback(() => {
    setShowPatientDropdown(false);
    setShowDatePicker(false);
    setShowStartPicker(false);
    setShowEndPicker(false);
    onClose();
  }, [onClose]);

  // Format helpers
  const formatDate = (d: Date): string => {
    return d.toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const formatTime = (d: Date): string => {
    return d.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={handleClose}
    >
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Pressable style={styles.backdrop} onPress={handleClose} />

        <View
          style={[
            styles.container,
            {
              backgroundColor: colors.surface,
              ...shadows.lg,
            },
          ]}
        >
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerContent}>
              <View
                style={[
                  styles.headerIcon,
                  { backgroundColor: colors.primaryMuted },
                ]}
              >
                <Ionicons
                  name="calendar-outline"
                  size={24}
                  color={colors.primary}
                />
              </View>
              <View style={styles.headerText}>
                <Text variant="h4">Nouveau rendez-vous</Text>
                <Text variant="caption" color="secondary">
                  Planifiez une visite patient
                </Text>
              </View>
            </View>
            <TouchableOpacity
              onPress={handleClose}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              style={[styles.closeButton, { backgroundColor: colors.backgroundTertiary }]}
            >
              <Ionicons name="close" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>

          <ScrollView
            style={styles.content}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {/* Patient Selector */}
            <View style={styles.field}>
              <Text variant="label" style={styles.fieldLabel}>
                Patient <Text style={{ color: colors.danger }}>*</Text>
              </Text>

              <TouchableOpacity
                style={[
                  styles.selector,
                  {
                    borderColor: showPatientDropdown
                      ? colors.primary
                      : colors.border,
                    backgroundColor: colors.surface,
                  },
                ]}
                onPress={() => setShowPatientDropdown(!showPatientDropdown)}
                activeOpacity={0.7}
              >
                <View style={styles.selectorContent}>
                  {selectedPatient ? (
                    <View style={styles.selectedPatient}>
                      <View
                        style={[
                          styles.patientAvatar,
                          { backgroundColor: colors.primaryMuted },
                        ]}
                      >
                        <Text
                          variant="labelSmall"
                          style={{ color: colors.primary }}
                        >
                          {selectedPatient.firstName[0]}
                          {selectedPatient.lastName[0]}
                        </Text>
                      </View>
                      <Text variant="body" numberOfLines={1}>
                        {selectedPatient.firstName} {selectedPatient.lastName}
                      </Text>
                    </View>
                  ) : (
                    <Text variant="body" color="tertiary">
                      Sélectionner un patient...
                    </Text>
                  )}
                </View>
                <Ionicons
                  name={showPatientDropdown ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  color={colors.textSecondary}
                />
              </TouchableOpacity>

              {/* Patient Dropdown */}
              {showPatientDropdown && (
                <View
                  style={[
                    styles.dropdown,
                    {
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      ...shadows.md,
                    },
                  ]}
                >
                  {/* Search Input */}
                  <View style={styles.searchContainer}>
                    <Ionicons
                      name="search"
                      size={18}
                      color={colors.textTertiary}
                      style={styles.searchIcon}
                    />
                    <Input
                      placeholder="Rechercher un patient..."
                      value={patientSearch}
                      onChangeText={setPatientSearch}
                      containerStyle={styles.searchInput}
                      inputStyle={styles.searchInputField}
                    />
                  </View>

                  {/* Patient List */}
                  <ScrollView
                    style={styles.patientList}
                    nestedScrollEnabled={true}
                    showsVerticalScrollIndicator={true}
                  >
                    {filteredPatients.length === 0 ? (
                      <View style={styles.emptyList}>
                        <Text variant="body" color="tertiary">
                          {patientsLoading
                            ? 'Chargement...'
                            : 'Aucun patient trouvé'}
                        </Text>
                      </View>
                    ) : (
                      filteredPatients.map((item) => (
                        <TouchableOpacity
                          key={item.id}
                          style={[
                            styles.patientItem,
                            selectedPatient?.id === item.id && {
                              backgroundColor: colors.primaryMuted,
                            },
                          ]}
                          onPress={() => handlePatientSelect(item)}
                        >
                          <View
                            style={[
                              styles.patientItemAvatar,
                              { backgroundColor: colors.backgroundTertiary },
                            ]}
                          >
                            <Text
                              variant="labelSmall"
                              color="secondary"
                            >
                              {item.firstName[0]}
                              {item.lastName[0]}
                            </Text>
                          </View>
                          <View style={styles.patientItemInfo}>
                            <Text variant="label" numberOfLines={1}>
                              {item.firstName} {item.lastName}
                            </Text>
                            <Text variant="caption" color="tertiary">
                              {item.age} ans
                            </Text>
                          </View>
                          {selectedPatient?.id === item.id && (
                            <Ionicons
                              name="checkmark-circle"
                              size={20}
                              color={colors.primary}
                            />
                          )}
                        </TouchableOpacity>
                      ))
                    )}
                  </ScrollView>

                  {/* Create New Patient Link */}
                  {onNavigateToCreatePatient && (
                    <TouchableOpacity
                      style={[
                        styles.createPatientLink,
                        { borderTopColor: colors.border },
                      ]}
                      onPress={() => {
                        setShowPatientDropdown(false);
                        onNavigateToCreatePatient();
                      }}
                    >
                      <Ionicons
                        name="add-circle-outline"
                        size={18}
                        color={colors.primary}
                      />
                      <Text
                        variant="labelSmall"
                        style={{ color: colors.primary, marginLeft: spacing.xs }}
                      >
                        Créer un nouveau patient
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              )}
            </View>

            {/* Date Selector */}
            <View style={styles.field}>
              <Text variant="label" style={styles.fieldLabel}>
                Date
              </Text>
              <TouchableOpacity
                style={[
                  styles.selector,
                  {
                    borderColor: colors.border,
                    backgroundColor: colors.surface,
                  },
                ]}
                onPress={() => setShowDatePicker(true)}
                activeOpacity={0.7}
              >
                <View style={styles.selectorContent}>
                  <Ionicons
                    name="calendar-outline"
                    size={20}
                    color={colors.primary}
                    style={styles.selectorIcon}
                  />
                  <Text variant="body" style={{ textTransform: 'capitalize' }}>
                    {formatDate(selectedDate)}
                  </Text>
                </View>
                <Ionicons
                  name="chevron-forward"
                  size={18}
                  color={colors.textTertiary}
                />
              </TouchableOpacity>

              {showDatePicker && (
                <DateTimePicker
                  value={selectedDate}
                  mode="date"
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  onChange={handleDateChange}
                  locale="fr-FR"
                />
              )}
            </View>

            {/* Time Range */}
            <View style={styles.field}>
              <Text variant="label" style={styles.fieldLabel}>
                Horaire
              </Text>

              <View style={styles.timeRow}>
                {/* Start Time */}
                <View style={styles.timeField}>
                  <Text variant="caption" color="secondary" style={styles.timeLabel}>
                    De
                  </Text>
                  <TouchableOpacity
                    style={[
                      styles.timeSelector,
                      {
                        borderColor: colors.border,
                        backgroundColor: colors.surface,
                      },
                    ]}
                    onPress={() => setShowStartPicker(true)}
                    activeOpacity={0.7}
                  >
                    <Ionicons
                      name="time-outline"
                      size={18}
                      color={colors.primary}
                    />
                    <Text variant="label" style={styles.timeText}>
                      {formatTime(startTime)}
                    </Text>
                  </TouchableOpacity>
                </View>

                {/* Arrow */}
                <View style={styles.timeArrow}>
                  <Ionicons
                    name="arrow-forward"
                    size={20}
                    color={colors.textTertiary}
                  />
                </View>

                {/* End Time */}
                <View style={styles.timeField}>
                  <Text variant="caption" color="secondary" style={styles.timeLabel}>
                    À
                  </Text>
                  <TouchableOpacity
                    style={[
                      styles.timeSelector,
                      {
                        borderColor: timeError ? colors.danger : colors.border,
                        backgroundColor: colors.surface,
                      },
                    ]}
                    onPress={() => setShowEndPicker(true)}
                    activeOpacity={0.7}
                  >
                    <Ionicons
                      name="time-outline"
                      size={18}
                      color={timeError ? colors.danger : colors.primary}
                    />
                    <Text
                      variant="label"
                      style={[
                        styles.timeText,
                        timeError ? { color: colors.danger } : undefined,
                      ]}
                    >
                      {formatTime(endTime)}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              {timeError && (
                <Text
                  variant="caption"
                  style={{ color: colors.danger, marginTop: spacing.xs }}
                >
                  {timeError}
                </Text>
              )}

              {showStartPicker && (
                <DateTimePicker
                  value={startTime}
                  mode="time"
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  onChange={handleStartTimeChange}
                  is24Hour={true}
                  minuteInterval={5}
                />
              )}

              {showEndPicker && (
                <DateTimePicker
                  value={endTime}
                  mode="time"
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  onChange={handleEndTimeChange}
                  is24Hour={true}
                  minuteInterval={5}
                />
              )}
            </View>

            {/* Summary */}
            {selectedPatient && isValid && (
              <View
                style={[
                  styles.summary,
                  { backgroundColor: colors.primaryMuted },
                ]}
              >
                <Ionicons
                  name="checkmark-circle"
                  size={20}
                  color={colors.primary}
                />
                <Text variant="bodySmall" style={{ marginLeft: spacing.sm, flex: 1 }}>
                  Rendez-vous avec{' '}
                  <Text variant="label">
                    {selectedPatient.firstName} {selectedPatient.lastName}
                  </Text>{' '}
                  le{' '}
                  <Text variant="label">
                    {selectedDate.toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                    })}
                  </Text>{' '}
                  de{' '}
                  <Text variant="label">{formatTime(startTime)}</Text> à{' '}
                  <Text variant="label">{formatTime(endTime)}</Text>
                </Text>
              </View>
            )}
          </ScrollView>

          {/* Actions */}
          <View
            style={[styles.actions, { borderTopColor: colors.border }]}
          >
            <Button
              label="Annuler"
              variant="outline"
              onPress={handleClose}
              style={styles.cancelButton}
            />
            <Button
              label="Enregistrer le rendez-vous"
              onPress={handleSubmit}
              disabled={!isValid}
              style={styles.submitButton}
              iconLeft={
                <Ionicons
                  name="checkmark"
                  size={18}
                  color={isValid ? '#fff' : colors.textTertiary}
                />
              }
            />
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  container: {
    width: '92%',
    maxWidth: 440,
    maxHeight: '90%',
    borderRadius: radius.xl,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    marginLeft: spacing.md,
    flex: 1,
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    paddingHorizontal: spacing.lg,
    maxHeight: 400,
  },
  field: {
    marginBottom: spacing.lg,
  },
  fieldLabel: {
    marginBottom: spacing.sm,
  },
  selector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    minHeight: 52,
  },
  selectorContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  selectorIcon: {
    marginRight: spacing.sm,
  },
  selectedPatient: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  patientAvatar: {
    width: 32,
    height: 32,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  dropdown: {
    marginTop: spacing.xs,
    borderRadius: radius.md,
    borderWidth: 1,
    maxHeight: 280,
    overflow: 'hidden',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  searchIcon: {
    marginRight: spacing.sm,
  },
  searchInput: {
    flex: 1,
    marginBottom: 0,
  },
  searchInputField: {
    paddingVertical: spacing.xs,
    fontSize: 14,
  },
  patientList: {
    maxHeight: 180,
  },
  patientItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  patientItemAvatar: {
    width: 36,
    height: 36,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  patientItemInfo: {
    flex: 1,
  },
  emptyList: {
    padding: spacing.lg,
    alignItems: 'center',
  },
  createPatientLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.md,
    borderTopWidth: 1,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  timeField: {
    flex: 1,
  },
  timeLabel: {
    marginBottom: spacing.xs,
  },
  timeSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
  },
  timeText: {
    marginLeft: spacing.sm,
  },
  timeArrow: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
  },
  summary: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    borderRadius: radius.md,
    marginBottom: spacing.md,
  },
  actions: {
    flexDirection: 'row',
    padding: spacing.lg,
    borderTopWidth: 1,
    gap: spacing.sm,
  },
  cancelButton: {
    flex: 1,
  },
  submitButton: {
    flex: 2,
  },
});
