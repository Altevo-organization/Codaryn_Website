/**
 * DaySection Component
 *
 * Groups appointments by day with a date header.
 * Redesigned with MediSync design system.
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Stack, Divider, spacing, useTheme } from '../../ui';
import type {
  AppointmentsByDate,
  Appointment,
} from '../../features/appointments/types';
import AppointmentRow from './AppointmentRow';

// =============================================================================
// TYPES
// =============================================================================

interface DaySectionProps {
  section: AppointmentsByDate;
  onAppointmentPress?: (appointment: Appointment) => void;
  onAppointmentLongPress?: (appointment: Appointment) => void;
}

// =============================================================================
// HELPERS
// =============================================================================

function formatDateLabel(dateStr: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  if (date.getTime() === today.getTime()) {
    return "Aujourd'hui";
  }
  if (date.getTime() === tomorrow.getTime()) {
    return 'Demain';
  }

  return date.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });
}

function formatShortDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-');
  return `${d}/${m}/${y}`;
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function DaySection({
  section,
  onAppointmentPress,
  onAppointmentLongPress,
}: DaySectionProps) {
  const { colors } = useTheme();

  const appointmentCount = section.appointments.length;
  const dateLabel = formatDateLabel(section.date);

  return (
    <View style={styles.container}>
      {/* Date header */}
      <View style={styles.header}>
        <Text variant="h4" style={styles.dateLabel}>
          {dateLabel}
        </Text>
        <Text variant="caption" color="tertiary">
          {appointmentCount} rendez-vous
        </Text>
      </View>

      {/* Appointments list */}
      <Stack gap="none">
        {section.appointments.map((appt) => (
          <AppointmentRow
            key={appt.id}
            appointment={appt}
            onPress={
              onAppointmentPress
                ? () => onAppointmentPress(appt)
                : undefined
            }
            onLongPress={
              onAppointmentLongPress
                ? () => onAppointmentLongPress(appt)
                : undefined
            }
          />
        ))}
      </Stack>
    </View>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing.xl,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    marginBottom: spacing.md,
  },
  dateLabel: {
    textTransform: 'capitalize',
  },
});
