// src/components/planning/UpcomingAppointmentsList.tsx
import React from 'react'
import { View, StyleSheet, FlatList } from 'react-native'
import AppText from '../ui/AppText'
import Card from '../ui/Card'
import { useTheme } from '../../theme/ThemeProvider'
import type { Appointment } from '../../features/appointments/types'

interface UpcomingAppointmentsListProps {
  appointments: Appointment[]
}

function formatTimeRange(startDate: string, endDate: string) {
  const startTime = startDate.split('T')[1] ?? ''
  const endTime = endDate.split('T')[1] ?? ''

  const [sh, sm] = startTime.split(':')
  const [eh, em] = endTime.split(':')

  if (!sh || !sm || !eh || !em) return ''

  return `${sh}:${sm} - ${eh}:${em}`
}

export default function UpcomingAppointmentsList({
  appointments,
}: UpcomingAppointmentsListProps) {
  const { colors } = useTheme()

  if (appointments.length === 0) {
    return (
      <View style={styles.container}>
        <AppText style={{ color: colors.muted, fontSize: 13 }}>
          Aucun rendez-vous à venir.
        </AppText>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <AppText style={[styles.title, { color: colors.text }]}>
        Prochains rendez-vous
      </AppText>

      <FlatList
        data={appointments}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <AppText style={styles.patientName}>
              {item.patientName ?? `Patient #${item.patientId}`}
            </AppText>
            <AppText style={{ fontSize: 13, color: colors.muted }}>
              {item.startDate.split('T')[0]} • {formatTimeRange(item.startDate, item.endDate)}
            </AppText>
          </Card>
        )}
        scrollEnabled={false}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginTop: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  card: {
    marginBottom: 8,
  },
  patientName: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
})
