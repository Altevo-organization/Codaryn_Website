/**
 * DayTourModal
 *
 * Full-screen modal displaying all appointments for a selected day.
 * Features:
 * - Chronological list of appointments
 * - Clean timeline visualization
 * - Patient details with quick access
 * - Empty state handling
 */

import React, { useMemo } from 'react';
import {
  Modal,
  View,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  Text,
  Card,
  Badge,
  EmptyState,
  spacing,
  radius,
  shadows,
  useTheme,
} from '../../ui';
import type { Appointment } from '../../features/appointments/types';

// =============================================================================
// TYPES
// =============================================================================

interface DayTourModalProps {
  visible: boolean;
  date: string; // "YYYY-MM-DD"
  appointments: Appointment[];
  onClose: () => void;
  onAppointmentPress?: (appointment: Appointment) => void;
  onAppointmentLongPress?: (appointment: Appointment) => void;
}

type AppointmentStatus = 'upcoming' | 'ongoing' | 'completed';

// =============================================================================
// HELPERS
// =============================================================================

function formatTime(iso: string): string {
  if (!iso) return '';
  const timePart = iso.split('T')[1] ?? '';
  const [hh, mm] = timePart.split(':');
  if (!hh || !mm) return '';
  return `${hh}:${mm}`;
}

function getAppointmentStatus(startDate: string, endDate: string): AppointmentStatus {
  const now = new Date();
  const start = startDate ? new Date(startDate) : now;
  const end = endDate ? new Date(endDate) : now;

  if (end < now) return 'completed';
  if (start <= now && end >= now) return 'ongoing';
  return 'upcoming';
}

function formatDateHeader(dateStr: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  if (date.getTime() === today.getTime()) {
    return "Aujourd'hui";
  }
  if (date.getTime() === tomorrow.getTime()) {
    return 'Demain';
  }

  return date.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function DayTourModal({
  visible,
  date,
  appointments,
  onClose,
  onAppointmentPress,
  onAppointmentLongPress,
}: DayTourModalProps) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  // Sort appointments chronologically
  const sortedAppointments = useMemo(() => {
    return [...appointments].sort(
      (a, b) =>
        new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
    );
  }, [appointments]);

  // Calculate tour stats
  const stats = useMemo(() => {
    const total = sortedAppointments.length;
    const completed = sortedAppointments.filter(
      (a) => getAppointmentStatus(a.startDate, a.endDate) === 'completed'
    ).length;
    const remaining = total - completed;

    // Calculate total time
    let totalMinutes = 0;
    sortedAppointments.forEach((appt) => {
      const start = new Date(appt.startDate);
      const end = new Date(appt.endDate);
      totalMinutes += (end.getTime() - start.getTime()) / (1000 * 60);
    });
    const hours = Math.floor(totalMinutes / 60);
    const minutes = Math.round(totalMinutes % 60);

    return { total, completed, remaining, hours, minutes };
  }, [sortedAppointments]);

  const renderAppointment = ({
    item,
    index,
  }: {
    item: Appointment;
    index: number;
  }) => {
    const status = getAppointmentStatus(item.startDate, item.endDate);
    const timeStart = formatTime(item.startDate);
    const timeEnd = formatTime(item.endDate);
    const patientName = item.patientName ?? `Patient #${item.patientId}`;
    const isLast = index === sortedAppointments.length - 1;

    const statusConfig = {
      upcoming: {
        label: 'À venir',
        variant: 'primary' as const,
        iconColor: colors.primary,
        lineColor: colors.primary,
      },
      ongoing: {
        label: 'En cours',
        variant: 'warning' as const,
        iconColor: colors.warning,
        lineColor: colors.warning,
      },
      completed: {
        label: 'Terminé',
        variant: 'success' as const,
        iconColor: colors.success,
        lineColor: colors.textTertiary,
      },
    };

    const config = statusConfig[status];

    return (
      <View style={styles.appointmentRow}>
        {/* Timeline */}
        <View style={styles.timeline}>
          <View
            style={[
              styles.timelineDot,
              {
                backgroundColor: config.iconColor,
                borderColor: colors.surface,
              },
            ]}
          >
            {status === 'completed' && (
              <Ionicons name="checkmark" size={10} color="#fff" />
            )}
            {status === 'ongoing' && (
              <View
                style={[styles.ongoingDot, { backgroundColor: '#fff' }]}
              />
            )}
          </View>
          {!isLast && (
            <View
              style={[
                styles.timelineLine,
                { backgroundColor: config.lineColor },
              ]}
            />
          )}
        </View>

        {/* Content */}
        <Card
          variant="outlined"
          padding="md"
          onPress={() => onAppointmentPress?.(item)}
          onLongPress={() => onAppointmentLongPress?.(item)}
          style={styles.appointmentCard}
        >
          {/* Time Badge */}
          <View style={styles.appointmentHeader}>
            <View
              style={[
                styles.timeBadge,
                { backgroundColor: colors.primaryMuted },
              ]}
            >
              <Ionicons
                name="time-outline"
                size={14}
                color={colors.primary}
              />
              <Text
                variant="labelSmall"
                style={{ color: colors.primary, marginLeft: spacing.xxs }}
              >
                {timeStart} - {timeEnd}
              </Text>
            </View>
            <Badge
              label={config.label}
              variant={config.variant}
              size="sm"
            />
          </View>

          {/* Patient Info */}
          <View style={styles.patientRow}>
            <View
              style={[
                styles.patientAvatar,
                { backgroundColor: colors.backgroundTertiary },
              ]}
            >
              <Ionicons
                name="person"
                size={18}
                color={colors.textSecondary}
              />
            </View>
            <View style={styles.patientInfo}>
              <Text variant="label" numberOfLines={1}>
                {patientName}
              </Text>
              <Text variant="caption" color="tertiary">
                Visite #{index + 1}
              </Text>
            </View>
            <Ionicons
              name="chevron-forward"
              size={18}
              color={colors.textTertiary}
            />
          </View>
        </Card>
      </View>
    );
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.background,
            paddingTop: insets.top,
          },
        ]}
      >
        {/* Header */}
        <View
          style={[
            styles.header,
            { backgroundColor: colors.surface, borderBottomColor: colors.border },
          ]}
        >
          <View style={styles.headerContent}>
            <View
              style={[
                styles.headerIcon,
                { backgroundColor: colors.primaryMuted },
              ]}
            >
              <Ionicons name="map-outline" size={24} color={colors.primary} />
            </View>
            <View style={styles.headerText}>
              <Text variant="h4">Tournée du jour</Text>
              <Text
                variant="bodySmall"
                color="secondary"
                style={{ textTransform: 'capitalize' }}
              >
                {formatDateHeader(date)}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            onPress={onClose}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={[
              styles.closeButton,
              { backgroundColor: colors.backgroundTertiary },
            ]}
          >
            <Ionicons name="close" size={22} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        {/* Stats Bar */}
        {sortedAppointments.length > 0 && (
          <View
            style={[
              styles.statsBar,
              { backgroundColor: colors.surface, borderBottomColor: colors.border },
            ]}
          >
            <View style={styles.stat}>
              <Text variant="h4" style={{ color: colors.primary }}>
                {stats.total}
              </Text>
              <Text variant="caption" color="secondary">
                visite{stats.total > 1 ? 's' : ''}
              </Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <View style={styles.stat}>
              <Text variant="h4" style={{ color: colors.success }}>
                {stats.completed}
              </Text>
              <Text variant="caption" color="secondary">
                terminée{stats.completed > 1 ? 's' : ''}
              </Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <View style={styles.stat}>
              <Text variant="h4">{stats.remaining}</Text>
              <Text variant="caption" color="secondary">
                restante{stats.remaining > 1 ? 's' : ''}
              </Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <View style={styles.stat}>
              <Text variant="h4">
                {stats.hours > 0 ? `${stats.hours}h` : ''}
                {stats.minutes > 0 ? `${stats.minutes}m` : stats.hours === 0 ? '0m' : ''}
              </Text>
              <Text variant="caption" color="secondary">
                durée totale
              </Text>
            </View>
          </View>
        )}

        {/* Appointments List */}
        {sortedAppointments.length === 0 ? (
          <View style={styles.emptyContainer}>
            <EmptyState
              icon="calendar-clear-outline"
              title="Aucun rendez-vous"
              description="Aucune visite n'est prévue pour cette journée. Créez un rendez-vous pour commencer."
            />
          </View>
        ) : (
          <FlatList
            data={sortedAppointments}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderAppointment}
            contentContainerStyle={[
              styles.listContent,
              { paddingBottom: insets.bottom + spacing.lg },
            ]}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </Modal>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    marginLeft: spacing.md,
    flex: 1,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: 1,
  },
  stat: {
    alignItems: 'center',
    flex: 1,
  },
  statDivider: {
    width: 1,
    height: 32,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  appointmentRow: {
    flexDirection: 'row',
    marginBottom: spacing.md,
  },
  timeline: {
    width: 32,
    alignItems: 'center',
  },
  timelineDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    zIndex: 1,
  },
  ongoingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  timelineLine: {
    width: 2,
    flex: 1,
    marginTop: -2,
  },
  appointmentCard: {
    flex: 1,
    marginLeft: spacing.sm,
  },
  appointmentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  timeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.sm,
  },
  patientRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  patientAvatar: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  patientInfo: {
    flex: 1,
  },
});
