/**
 * MonthCalendar Component
 *
 * Calendar view with marked dates and selection.
 * Uses react-native-calendars with MediSync theme.
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Calendar, DateObject } from 'react-native-calendars';
import { useTheme, radius, spacing } from '../../ui';

// =============================================================================
// TYPES
// =============================================================================

type MarkedDates = Record<
  string,
  {
    marked?: boolean;
    selected?: boolean;
    selectedColor?: string;
    dotColor?: string;
  }
>;

interface MonthCalendarProps {
  /** Current month to display (YYYY-MM-DD) */
  current: string;
  /** Currently selected date (YYYY-MM-DD) */
  selectedDate: string;
  /** Dates with appointments */
  markedDates: MarkedDates;
  /** Called when a day is pressed */
  onDayPress: (dateString: string) => void;
  /** Called when month changes */
  onMonthChange?: (year: number, month: number) => void;
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function MonthCalendar({
  current,
  selectedDate,
  markedDates,
  onDayPress,
  onMonthChange,
}: MonthCalendarProps) {
  const { colors, isDark } = useTheme();

  // Merge marked dates with selected date styling
  const mergedMarked: MarkedDates = {
    ...markedDates,
    [selectedDate]: {
      ...(markedDates[selectedDate] ?? {}),
      selected: true,
      selectedColor: colors.primary,
    },
  };

  // Add dot color for marked dates
  Object.keys(mergedMarked).forEach((key) => {
    if (mergedMarked[key].marked && !mergedMarked[key].dotColor) {
      mergedMarked[key].dotColor = colors.primary;
    }
  });

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
        },
      ]}
    >
      <Calendar
        current={current}
        onDayPress={(day: DateObject) => onDayPress(day.dateString)}
        onMonthChange={(month: DateObject) =>
          onMonthChange?.(month.year, month.month)
        }
        markedDates={mergedMarked}
        firstDay={1}
        enableSwipeMonths={true}
        theme={{
          // Background colors
          backgroundColor: 'transparent',
          calendarBackground: 'transparent',

          // Text colors
          textSectionTitleColor: colors.textSecondary,
          monthTextColor: colors.text,
          dayTextColor: colors.text,
          textDisabledColor: colors.textTertiary,

          // Today
          todayTextColor: colors.primary,
          todayBackgroundColor: colors.primaryMuted,

          // Selected day
          selectedDayBackgroundColor: colors.primary,
          selectedDayTextColor: '#FFFFFF',

          // Arrows
          arrowColor: colors.primary,

          // Dots
          dotColor: colors.primary,
          selectedDotColor: '#FFFFFF',

          // Font styles
          textDayFontSize: 14,
          textDayFontWeight: '500' as const,
          textMonthFontSize: 16,
          textMonthFontWeight: '600' as const,
          textDayHeaderFontSize: 12,
          textDayHeaderFontWeight: '500' as const,

          // Indicator (loading)
          indicatorColor: colors.primary,

          // Week row style
          'stylesheet.calendar.header': {
            week: {
              marginTop: spacing.sm,
              flexDirection: 'row',
              justifyContent: 'space-around',
            },
          },
        }}
        style={styles.calendar}
      />
    </View>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    borderRadius: radius.lg,
    borderWidth: 1,
    overflow: 'hidden',
  },
  calendar: {
    paddingBottom: spacing.sm,
  },
});
