// src/components/files/DocumentsEmptyState.tsx
import React from 'react'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'

interface Props {
  isFolder?: boolean
  folderName?: string
  onImport: () => void
  onCreateFolder?: () => void
}

export default function DocumentsEmptyState({
  isFolder = false,
  folderName,
  onImport,
  onCreateFolder,
}: Props) {
  const { colors, radius, shadows } = useTheme()

  return (
    <View style={styles.container}>
      <View
        style={[
          styles.iconContainer,
          { backgroundColor: colors.primaryMuted },
        ]}
      >
        <Ionicons
          name={isFolder ? 'folder-open-outline' : 'documents-outline'}
          size={56}
          color={colors.primary}
        />
      </View>

      <AppText style={[styles.title, { color: colors.text }]}>
        {isFolder ? 'Dossier vide' : 'Aucun document'}
      </AppText>

      <AppText style={[styles.subtitle, { color: colors.textSecondary }]}>
        {isFolder
          ? `"${folderName}" ne contient aucun élément`
          : 'Importez vos premiers documents pour ce patient'}
      </AppText>

      <View style={styles.actions}>
        <TouchableOpacity
          onPress={onImport}
          style={[
            styles.primaryButton,
            { backgroundColor: colors.primary, borderRadius: radius.md },
          ]}
          activeOpacity={0.8}
        >
          <Ionicons name="cloud-upload-outline" size={20} color={colors.textInverse} />
          <AppText style={[styles.primaryButtonText, { color: colors.textInverse }]}>
            Importer
          </AppText>
        </TouchableOpacity>

        {onCreateFolder && (
          <TouchableOpacity
            onPress={onCreateFolder}
            style={[
              styles.secondaryButton,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderRadius: radius.md,
              },
              shadows.sm,
            ]}
            activeOpacity={0.8}
          >
            <Ionicons name="folder-outline" size={20} color={colors.primary} />
            <AppText style={[styles.secondaryButtonText, { color: colors.primary }]}>
              Nouveau dossier
            </AppText>
          </TouchableOpacity>
        )}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingBottom: 80,
  },
  iconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    maxWidth: 260,
  },
  actions: {
    marginTop: 32,
    gap: 12,
    width: '100%',
    maxWidth: 240,
  },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  primaryButtonText: {
    fontSize: 15,
    fontWeight: '600',
  },
  secondaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
    borderWidth: 1,
  },
  secondaryButtonText: {
    fontSize: 15,
    fontWeight: '500',
  },
})
