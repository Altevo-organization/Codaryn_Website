// src/components/files/Breadcrumb.tsx
import React from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { FolderItem } from '../../features/files/types'

interface BreadcrumbItem {
  id: string | null // null for root
  name: string
}

interface Props {
  items: BreadcrumbItem[]
  onNavigate: (folderId: string | null) => void
}

export default function Breadcrumb({ items, onNavigate }: Props) {
  const { colors, radius } = useTheme()

  if (items.length <= 1) {
    return null
  }

  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {items.map((item, index) => {
          const isLast = index === items.length - 1

          return (
            <View key={item.id ?? 'root'} style={styles.itemRow}>
              {index > 0 && (
                <Ionicons
                  name="chevron-forward"
                  size={14}
                  color={colors.textTertiary}
                  style={styles.chevron}
                />
              )}
              <TouchableOpacity
                onPress={() => !isLast && onNavigate(item.id)}
                disabled={isLast}
                style={[
                  styles.crumb,
                  {
                    backgroundColor: isLast ? colors.primaryMuted : 'transparent',
                    borderRadius: radius.sm,
                  },
                ]}
                activeOpacity={0.7}
              >
                {index === 0 && (
                  <Ionicons
                    name="folder-outline"
                    size={14}
                    color={isLast ? colors.primary : colors.textSecondary}
                    style={styles.folderIcon}
                  />
                )}
                <AppText
                  style={[
                    styles.crumbText,
                    {
                      color: isLast ? colors.primary : colors.textSecondary,
                      fontWeight: isLast ? '600' : '400',
                    },
                  ]}
                  numberOfLines={1}
                >
                  {item.name}
                </AppText>
              </TouchableOpacity>
            </View>
          )
        })}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
  },
  scrollContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  chevron: {
    marginHorizontal: 4,
  },
  crumb: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  folderIcon: {
    marginRight: 4,
  },
  crumbText: {
    fontSize: 13,
    maxWidth: 120,
  },
})
