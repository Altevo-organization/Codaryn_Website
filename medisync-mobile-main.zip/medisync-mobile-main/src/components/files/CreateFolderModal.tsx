// src/components/files/CreateFolderModal.tsx
import React, { useState, useEffect, useRef } from 'react'
import {
  View,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'

interface Props {
  visible: boolean
  onClose: () => void
  onConfirm: (name: string) => void
  parentFolderName?: string
}

export default function CreateFolderModal({
  visible,
  onClose,
  onConfirm,
  parentFolderName,
}: Props) {
  const { colors, radius, shadows } = useTheme()
  const [name, setName] = useState('')
  const inputRef = useRef<TextInput>(null)

  useEffect(() => {
    if (visible) {
      setName('')
      setTimeout(() => {
        inputRef.current?.focus()
      }, 100)
    }
  }, [visible])

  const handleConfirm = () => {
    const trimmed = name.trim()
    if (trimmed.length > 0) {
      onConfirm(trimmed)
      onClose()
    }
  }

  const isValid = name.trim().length > 0

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Pressable style={styles.overlayPressable} onPress={onClose}>
          <Pressable
            style={[
              styles.container,
              {
                backgroundColor: colors.surface,
                borderRadius: radius.xl,
              },
              shadows.lg,
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            {/* Icon */}
            <View
              style={[
                styles.iconContainer,
                { backgroundColor: colors.primaryMuted },
              ]}
            >
              <Ionicons
                name="folder-open"
                size={32}
                color={colors.primary}
              />
            </View>

            {/* Title */}
            <AppText style={[styles.title, { color: colors.text }]}>
              Nouveau dossier
            </AppText>

            {parentFolderName && (
              <AppText
                style={[styles.subtitle, { color: colors.textSecondary }]}
              >
                dans "{parentFolderName}"
              </AppText>
            )}

            {/* Input */}
            <View
              style={[
                styles.inputContainer,
                {
                  backgroundColor: colors.backgroundTertiary,
                  borderColor: colors.border,
                  borderRadius: radius.md,
                },
              ]}
            >
              <TextInput
                ref={inputRef}
                value={name}
                onChangeText={setName}
                placeholder="Nom du dossier"
                placeholderTextColor={colors.textTertiary}
                style={[styles.input, { color: colors.text }]}
                autoCapitalize="sentences"
                autoCorrect={false}
                returnKeyType="done"
                onSubmitEditing={handleConfirm}
              />
              {name.length > 0 && (
                <TouchableOpacity
                  onPress={() => setName('')}
                  hitSlop={10}
                  style={styles.clearButton}
                >
                  <Ionicons
                    name="close-circle"
                    size={18}
                    color={colors.textTertiary}
                  />
                </TouchableOpacity>
              )}
            </View>

            {/* Buttons */}
            <View style={styles.buttons}>
              <TouchableOpacity
                onPress={onClose}
                style={[
                  styles.button,
                  styles.cancelButton,
                  {
                    backgroundColor: colors.backgroundTertiary,
                    borderRadius: radius.md,
                  },
                ]}
                activeOpacity={0.7}
              >
                <AppText
                  style={[styles.buttonText, { color: colors.textSecondary }]}
                >
                  Annuler
                </AppText>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleConfirm}
                disabled={!isValid}
                style={[
                  styles.button,
                  styles.confirmButton,
                  {
                    backgroundColor: isValid
                      ? colors.primary
                      : colors.primaryMuted,
                    borderRadius: radius.md,
                  },
                ]}
                activeOpacity={0.7}
              >
                <AppText
                  style={[
                    styles.buttonText,
                    {
                      color: isValid
                        ? colors.textInverse
                        : colors.textTertiary,
                      fontWeight: '600',
                    },
                  ]}
                >
                  Créer
                </AppText>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  )
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlayPressable: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  container: {
    width: '100%',
    maxWidth: 320,
    padding: 24,
    alignItems: 'center',
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    marginBottom: 8,
  },
  inputContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    marginTop: 16,
    marginBottom: 20,
    paddingHorizontal: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 12,
  },
  clearButton: {
    padding: 4,
  },
  buttons: {
    flexDirection: 'row',
    width: '100%',
    gap: 12,
  },
  button: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {},
  confirmButton: {},
  buttonText: {
    fontSize: 15,
    fontWeight: '500',
  },
})
