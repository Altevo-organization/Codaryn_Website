// src/components/files/FileListItem.tsx
import React from 'react'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { FileItem } from '../../features/files/types'

interface Props {
  file: FileItem
  onOpen: () => void
  onDelete: () => void
}

function formatSize(size: number): string {
  if (size > 1024 * 1024) {
    return `${(size / (1024 * 1024)).toFixed(1)} Mo`
  }
  if (size > 1024) {
    return `${(size / 1024).toFixed(1)} Ko`
  }
  return `${size} o`
}

export default function FileListItem({ file, onOpen, onDelete }: Props) {
  const { colors } = useTheme()

  const iconName =
    file.type === 'PDF'
      ? 'document-text-outline'
      : file.type === 'IMAGE'
        ? 'image-outline'
        : 'document-outline'

  return (
    <TouchableOpacity onPress={onOpen} activeOpacity={0.8} style={{ marginBottom: 10 }}>
      <View
        style={[
          styles.card,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <View style={styles.left}>
          <View
            style={[
              styles.iconWrapper,
              { backgroundColor: colors.primary + '22' },
            ]}
          >
            <Ionicons name={iconName} size={20} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <AppText
              style={[styles.name, { color: colors.text }]}
              numberOfLines={1}
            >
              {file.name}
            </AppText>
            <AppText style={[styles.meta, { color: colors.muted }]}>
              {file.type} • {formatSize(file.size)}
            </AppText>
          </View>
        </View>

        <View style={styles.actions}>
          <TouchableOpacity onPress={onDelete} hitSlop={10}>
            <Ionicons name="trash-outline" size={20} color={colors.danger} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    alignItems: 'center',
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 10,
  },
  iconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 999,
    justifyContent: 'center',
    alignItems: 'center',
  },
  name: {
    fontSize: 14,
    fontWeight: '600',
  },
  meta: {
    fontSize: 12,
  },
  actions: {
    marginLeft: 8,
  },
})
