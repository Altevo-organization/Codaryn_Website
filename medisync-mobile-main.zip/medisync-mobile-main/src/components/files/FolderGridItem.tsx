// src/components/files/FolderGridItem.tsx
import React from 'react'
import {
  View,
  StyleSheet,
  Pressable,
  Dimensions,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { FolderItem } from '../../features/files/types'

const { width: SCREEN_WIDTH } = Dimensions.get('window')
const NUM_COLUMNS = SCREEN_WIDTH > 400 ? 4 : 3
const GRID_GAP = 12
const ITEM_WIDTH = (SCREEN_WIDTH - 32 - GRID_GAP * (NUM_COLUMNS - 1)) / NUM_COLUMNS

interface Props {
  folder: FolderItem
  onPress: () => void
  onLongPress: () => void
  isDropTarget?: boolean
}

export default function FolderGridItem({
  folder,
  onPress,
  onLongPress,
  isDropTarget = false,
}: Props) {
  const { colors, shadows, radius } = useTheme()

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={400}
      style={({ pressed }) => [
        styles.container,
        { width: ITEM_WIDTH },
        pressed && styles.pressed,
      ]}
    >
      <View
        style={[
          styles.card,
          {
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
            borderWidth: isDropTarget ? 2 : 0,
            borderColor: isDropTarget ? colors.primary : 'transparent',
          },
          shadows.sm,
        ]}
      >
        {/* Folder icon area */}
        <View
          style={[
            styles.iconArea,
            { backgroundColor: colors.primaryMuted },
          ]}
        >
          <Ionicons
            name="folder"
            size={40}
            color={colors.primary}
          />
        </View>

        {/* Info area */}
        <View style={styles.infoArea}>
          <AppText
            style={[styles.folderName, { color: colors.text }]}
            numberOfLines={2}
          >
            {folder.name}
          </AppText>
          {folder.itemCount !== undefined && (
            <AppText
              style={[styles.itemCount, { color: colors.textTertiary }]}
            >
              {folder.itemCount} élément{folder.itemCount !== 1 ? 's' : ''}
            </AppText>
          )}
        </View>
      </View>
    </Pressable>
  )
}

export { ITEM_WIDTH, NUM_COLUMNS, GRID_GAP }

const styles = StyleSheet.create({
  container: {
    marginBottom: GRID_GAP,
  },
  pressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
  card: {
    overflow: 'hidden',
  },
  iconArea: {
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoArea: {
    padding: 10,
    minHeight: 56,
  },
  folderName: {
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
    marginBottom: 4,
  },
  itemCount: {
    fontSize: 10,
    fontWeight: '400',
  },
})
