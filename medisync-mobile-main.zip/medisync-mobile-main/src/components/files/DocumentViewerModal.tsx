// src/components/files/DocumentViewerModal.tsx
import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  Modal,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ActivityIndicator,
  Linking,
  Platform,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { FileItem } from '../../features/files/types'
import { buildDownloadUrl } from '../../features/files/api'

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window')

interface Props {
  visible: boolean
  onClose: () => void
  file: FileItem | null
}

export default function DocumentViewerModal({ visible, onClose, file }: Props) {
  const { colors, radius } = useTheme()
  const [imageLoading, setImageLoading] = useState(true)
  const [imageError, setImageError] = useState(false)
  const [scale, setScale] = useState(1)

  if (!file) return null

  const fileUrl = buildDownloadUrl(file.id)
  const isImage = file.type === 'IMAGE'
  const isPdf = file.type === 'PDF'

  const handleOpenExternal = () => {
    Linking.openURL(fileUrl).catch((err) => {
      console.error('[DocumentViewer] Failed to open URL', err)
    })
  }

  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev + 0.5, 3))
  }

  const handleZoomOut = () => {
    setScale((prev) => Math.max(prev - 0.5, 0.5))
  }

  const handleResetZoom = () => {
    setScale(1)
  }

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        {/* Header */}
        <View
          style={[
            styles.header,
            {
              backgroundColor: colors.surface,
              borderBottomColor: colors.border,
            },
          ]}
        >
          <TouchableOpacity
            onPress={onClose}
            style={styles.closeButton}
            hitSlop={10}
          >
            <Ionicons name="close" size={24} color={colors.text} />
          </TouchableOpacity>

          <View style={styles.titleContainer}>
            <AppText
              style={[styles.title, { color: colors.text }]}
              numberOfLines={1}
            >
              {file.name}
            </AppText>
            <AppText style={[styles.subtitle, { color: colors.textSecondary }]}>
              {file.type}
            </AppText>
          </View>

          <TouchableOpacity
            onPress={handleOpenExternal}
            style={styles.actionButton}
            hitSlop={10}
          >
            <Ionicons
              name="open-outline"
              size={22}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        {/* Content */}
        <View style={styles.content}>
          {isImage ? (
            <>
              {/* Zoom controls */}
              <View
                style={[
                  styles.zoomControls,
                  {
                    backgroundColor: colors.surface,
                    borderRadius: radius.lg,
                  },
                ]}
              >
                <TouchableOpacity
                  onPress={handleZoomOut}
                  style={styles.zoomButton}
                  disabled={scale <= 0.5}
                >
                  <Ionicons
                    name="remove"
                    size={20}
                    color={scale <= 0.5 ? colors.textTertiary : colors.text}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleResetZoom}
                  style={styles.zoomResetButton}
                >
                  <AppText
                    style={[styles.zoomText, { color: colors.textSecondary }]}
                  >
                    {Math.round(scale * 100)}%
                  </AppText>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleZoomIn}
                  style={styles.zoomButton}
                  disabled={scale >= 3}
                >
                  <Ionicons
                    name="add"
                    size={20}
                    color={scale >= 3 ? colors.textTertiary : colors.text}
                  />
                </TouchableOpacity>
              </View>

              <ScrollView
                style={styles.imageScrollView}
                contentContainerStyle={styles.imageScrollContent}
                maximumZoomScale={3}
                minimumZoomScale={0.5}
                showsHorizontalScrollIndicator={false}
                showsVerticalScrollIndicator={false}
                centerContent
              >
                {imageLoading && !imageError && (
                  <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={colors.primary} />
                  </View>
                )}
                {imageError ? (
                  <View style={styles.errorContainer}>
                    <Ionicons
                      name="image-outline"
                      size={64}
                      color={colors.textTertiary}
                    />
                    <AppText
                      style={[
                        styles.errorText,
                        { color: colors.textSecondary },
                      ]}
                    >
                      Impossible de charger l'image
                    </AppText>
                    <TouchableOpacity
                      onPress={handleOpenExternal}
                      style={[
                        styles.openExternalButton,
                        { backgroundColor: colors.primary },
                      ]}
                    >
                      <AppText
                        style={[
                          styles.openExternalText,
                          { color: colors.textInverse },
                        ]}
                      >
                        Ouvrir en externe
                      </AppText>
                    </TouchableOpacity>
                  </View>
                ) : (
                  <Image
                    source={{ uri: fileUrl }}
                    style={[
                      styles.image,
                      {
                        width: SCREEN_WIDTH * scale,
                        height: SCREEN_HEIGHT * 0.7 * scale,
                      },
                    ]}
                    resizeMode="contain"
                    onLoadStart={() => setImageLoading(true)}
                    onLoadEnd={() => setImageLoading(false)}
                    onError={() => {
                      setImageLoading(false)
                      setImageError(true)
                    }}
                  />
                )}
              </ScrollView>
            </>
          ) : isPdf ? (
            <View style={styles.pdfContainer}>
              <View
                style={[
                  styles.pdfPlaceholder,
                  {
                    backgroundColor: colors.surface,
                    borderRadius: radius.xl,
                  },
                ]}
              >
                <Ionicons
                  name="document-text"
                  size={80}
                  color={colors.danger}
                />
                <AppText
                  style={[styles.pdfTitle, { color: colors.text }]}
                  numberOfLines={2}
                >
                  {file.name}
                </AppText>
                <AppText
                  style={[styles.pdfSubtitle, { color: colors.textSecondary }]}
                >
                  Document PDF
                </AppText>

                <TouchableOpacity
                  onPress={handleOpenExternal}
                  style={[
                    styles.openPdfButton,
                    { backgroundColor: colors.primary },
                  ]}
                >
                  <Ionicons
                    name="open-outline"
                    size={20}
                    color={colors.textInverse}
                  />
                  <AppText
                    style={[
                      styles.openPdfText,
                      { color: colors.textInverse },
                    ]}
                  >
                    Ouvrir le PDF
                  </AppText>
                </TouchableOpacity>

                <AppText
                  style={[styles.pdfHint, { color: colors.textTertiary }]}
                >
                  Le PDF s'ouvrira dans votre lecteur par défaut
                </AppText>
              </View>
            </View>
          ) : (
            <View style={styles.unsupportedContainer}>
              <Ionicons
                name="document-outline"
                size={80}
                color={colors.textTertiary}
              />
              <AppText
                style={[styles.unsupportedTitle, { color: colors.text }]}
              >
                {file.name}
              </AppText>
              <AppText
                style={[
                  styles.unsupportedSubtitle,
                  { color: colors.textSecondary },
                ]}
              >
                Aperçu non disponible pour ce type de fichier
              </AppText>
              <TouchableOpacity
                onPress={handleOpenExternal}
                style={[
                  styles.openExternalButton,
                  { backgroundColor: colors.primary },
                ]}
              >
                <AppText
                  style={[
                    styles.openExternalText,
                    { color: colors.textInverse },
                  ]}
                >
                  Ouvrir avec une autre app
                </AppText>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    </Modal>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 56 : 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    maxWidth: 200,
  },
  subtitle: {
    fontSize: 12,
    marginTop: 2,
  },
  actionButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  zoomControls: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 10,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  zoomButton: {
    padding: 8,
  },
  zoomResetButton: {
    paddingHorizontal: 8,
  },
  zoomText: {
    fontSize: 12,
    fontWeight: '500',
    minWidth: 40,
    textAlign: 'center',
  },
  imageScrollView: {
    flex: 1,
  },
  imageScrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    backgroundColor: 'transparent',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 15,
    marginTop: 12,
    textAlign: 'center',
  },
  pdfContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  pdfPlaceholder: {
    width: '100%',
    maxWidth: 300,
    padding: 32,
    alignItems: 'center',
  },
  pdfTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 16,
    textAlign: 'center',
    maxWidth: 250,
  },
  pdfSubtitle: {
    fontSize: 13,
    marginTop: 4,
  },
  openPdfButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    marginTop: 24,
    gap: 8,
  },
  openPdfText: {
    fontSize: 15,
    fontWeight: '600',
  },
  pdfHint: {
    fontSize: 11,
    marginTop: 12,
    textAlign: 'center',
  },
  unsupportedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  unsupportedTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 16,
    textAlign: 'center',
  },
  unsupportedSubtitle: {
    fontSize: 13,
    marginTop: 4,
    textAlign: 'center',
  },
  openExternalButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    marginTop: 24,
  },
  openExternalText: {
    fontSize: 15,
    fontWeight: '600',
  },
})
