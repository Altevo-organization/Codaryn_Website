// src/components/files/MoveToFolderModal.tsx
import React from 'react'
import {
  View,
  StyleSheet,
  Modal,
  TouchableOpacity,
  FlatList,
  Pressable,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { FolderItem } from '../../features/files/types'

interface Props {
  visible: boolean
  onClose: () => void
  folders: FolderItem[]
  currentFolderId: string | null
  onSelectFolder: (folderId: string | null) => void
  itemName: string
}

export default function MoveToFolderModal({
  visible,
  onClose,
  folders,
  currentFolderId,
  onSelectFolder,
  itemName,
}: Props) {
  const { colors, radius, shadows } = useTheme()

  const availableFolders = folders.filter((f) => f.id !== currentFolderId)

  const renderFolderItem = ({ item }: { item: FolderItem | { id: null; name: string } }) => {
    const isRoot = item.id === null

    return (
      <TouchableOpacity
        onPress={() => {
          onSelectFolder(item.id)
          onClose()
        }}
        style={[
          styles.folderItem,
          { borderBottomColor: colors.border },
        ]}
        activeOpacity={0.7}
      >
        <View
          style={[
            styles.folderIcon,
            { backgroundColor: colors.primaryMuted },
          ]}
        >
          <Ionicons
            name={isRoot ? 'home' : 'folder'}
            size={20}
            color={colors.primary}
          />
        </View>
        <View style={styles.folderInfo}>
          <AppText
            style={[styles.folderName, { color: colors.text }]}
            numberOfLines={1}
          >
            {item.name}
          </AppText>
          {!isRoot && 'itemCount' in item && item.itemCount !== undefined && (
            <AppText
              style={[styles.folderCount, { color: colors.textTertiary }]}
            >
              {item.itemCount} élément{item.itemCount !== 1 ? 's' : ''}
            </AppText>
          )}
        </View>
        <Ionicons
          name="chevron-forward"
          size={18}
          color={colors.textTertiary}
        />
      </TouchableOpacity>
    )
  }

  const dataWithRoot = [
    { id: null, name: 'Documents (racine)' } as const,
    ...availableFolders,
  ]

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable
          style={[
            styles.container,
            {
              backgroundColor: colors.surface,
              borderTopLeftRadius: radius.xxl,
              borderTopRightRadius: radius.xxl,
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <View style={[styles.header, { borderBottomColor: colors.border }]}>
            <View style={styles.headerLeft}>
              <TouchableOpacity onPress={onClose} hitSlop={10}>
                <AppText style={[styles.cancelText, { color: colors.primary }]}>
                  Annuler
                </AppText>
              </TouchableOpacity>
            </View>
            <View style={styles.headerCenter}>
              <AppText style={[styles.title, { color: colors.text }]}>
                Déplacer vers
              </AppText>
              <AppText
                style={[styles.subtitle, { color: colors.textSecondary }]}
                numberOfLines={1}
              >
                {itemName}
              </AppText>
            </View>
            <View style={styles.headerRight} />
          </View>

          {/* Folder list */}
          {availableFolders.length === 0 && currentFolderId !== null ? (
            <View style={styles.emptyState}>
              <Ionicons
                name="folder-open-outline"
                size={48}
                color={colors.textTertiary}
              />
              <AppText
                style={[styles.emptyText, { color: colors.textSecondary }]}
              >
                Déplacer vers la racine uniquement
              </AppText>
            </View>
          ) : null}

          <FlatList
            data={currentFolderId !== null ? dataWithRoot : availableFolders}
            keyExtractor={(item) => item.id ?? 'root'}
            renderItem={renderFolderItem}
            contentContainerStyle={styles.list}
            showsVerticalScrollIndicator={false}
          />
        </Pressable>
      </Pressable>
    </Modal>
  )
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    maxHeight: '70%',
    minHeight: 300,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  headerLeft: {
    flex: 1,
    alignItems: 'flex-start',
  },
  headerCenter: {
    flex: 2,
    alignItems: 'center',
  },
  headerRight: {
    flex: 1,
  },
  cancelText: {
    fontSize: 16,
    fontWeight: '500',
  },
  title: {
    fontSize: 17,
    fontWeight: '600',
  },
  subtitle: {
    fontSize: 12,
    marginTop: 2,
    maxWidth: 150,
  },
  list: {
    paddingVertical: 8,
  },
  folderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  folderIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  folderInfo: {
    flex: 1,
  },
  folderName: {
    fontSize: 15,
    fontWeight: '500',
  },
  folderCount: {
    fontSize: 12,
    marginTop: 2,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 14,
    marginTop: 12,
    textAlign: 'center',
  },
})
