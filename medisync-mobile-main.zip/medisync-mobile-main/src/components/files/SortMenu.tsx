// src/components/files/SortMenu.tsx
import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Pressable,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { SortOption } from '../../features/files/types'
import { sortOptions } from '../../features/files/types'

interface Props {
  value: SortOption
  onChange: (option: SortOption) => void
}

export default function SortMenu({ value, onChange }: Props) {
  const { colors, radius, shadows } = useTheme()
  const [visible, setVisible] = useState(false)

  const currentLabel = sortOptions[value].label

  const handleSelect = (option: SortOption) => {
    onChange(option)
    setVisible(false)
  }

  return (
    <>
      <TouchableOpacity
        onPress={() => setVisible(true)}
        style={[
          styles.trigger,
          {
            backgroundColor: colors.surface,
            borderColor: colors.border,
            borderRadius: radius.md,
          },
        ]}
        activeOpacity={0.7}
      >
        <Ionicons
          name="swap-vertical"
          size={16}
          color={colors.textSecondary}
        />
        <AppText
          style={[styles.triggerText, { color: colors.textSecondary }]}
          numberOfLines={1}
        >
          {currentLabel}
        </AppText>
        <Ionicons
          name="chevron-down"
          size={14}
          color={colors.textTertiary}
        />
      </TouchableOpacity>

      <Modal
        visible={visible}
        transparent
        animationType="fade"
        onRequestClose={() => setVisible(false)}
      >
        <Pressable
          style={styles.overlay}
          onPress={() => setVisible(false)}
        >
          <View
            style={[
              styles.menu,
              {
                backgroundColor: colors.surface,
                borderRadius: radius.lg,
              },
              shadows.lg,
            ]}
          >
            <AppText
              style={[styles.menuTitle, { color: colors.textSecondary }]}
            >
              Trier par
            </AppText>

            {(Object.keys(sortOptions) as SortOption[]).map((option) => {
              const isSelected = option === value
              return (
                <TouchableOpacity
                  key={option}
                  onPress={() => handleSelect(option)}
                  style={[
                    styles.menuItem,
                    isSelected && {
                      backgroundColor: colors.primaryMuted,
                    },
                  ]}
                  activeOpacity={0.7}
                >
                  <AppText
                    style={[
                      styles.menuItemText,
                      {
                        color: isSelected ? colors.primary : colors.text,
                        fontWeight: isSelected ? '600' : '400',
                      },
                    ]}
                  >
                    {sortOptions[option].label}
                  </AppText>
                  {isSelected && (
                    <Ionicons
                      name="checkmark"
                      size={18}
                      color={colors.primary}
                    />
                  )}
                </TouchableOpacity>
              )
            })}
          </View>
        </Pressable>
      </Modal>
    </>
  )
}

const styles = StyleSheet.create({
  trigger: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    gap: 6,
  },
  triggerText: {
    fontSize: 13,
    fontWeight: '500',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  menu: {
    width: '100%',
    maxWidth: 280,
    padding: 8,
  },
  menuTitle: {
    fontSize: 12,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 8,
  },
  menuItemText: {
    fontSize: 15,
  },
})
