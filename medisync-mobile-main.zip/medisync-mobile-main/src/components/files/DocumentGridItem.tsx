// src/components/files/DocumentGridItem.tsx
import React, { useCallback } from 'react'
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Pressable,
  Dimensions,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { FileItem } from '../../features/files/types'

const { width: SCREEN_WIDTH } = Dimensions.get('window')
const NUM_COLUMNS = SCREEN_WIDTH > 400 ? 4 : 3
const GRID_GAP = 12
const ITEM_WIDTH = (SCREEN_WIDTH - 32 - GRID_GAP * (NUM_COLUMNS - 1)) / NUM_COLUMNS

interface Props {
  file: FileItem
  onPress: () => void
  onLongPress: () => void
}

function formatDate(dateString: string): string {
  const date = new Date(dateString)
  const day = date.getDate()
  const months = ['jan.', 'fév.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.']
  const month = months[date.getMonth()]
  const year = date.getFullYear()
  return `${day} ${month} ${year}`
}

function getFileIcon(type: string): keyof typeof Ionicons.glyphMap {
  switch (type) {
    case 'PDF':
      return 'document-text'
    case 'IMAGE':
      return 'image'
    default:
      return 'document'
  }
}

function getFileIconColor(type: string, colors: any): string {
  switch (type) {
    case 'PDF':
      return colors.danger
    case 'IMAGE':
      return colors.primary
    default:
      return colors.textSecondary
  }
}

export default function DocumentGridItem({ file, onPress, onLongPress }: Props) {
  const { colors, shadows, radius } = useTheme()

  const iconName = getFileIcon(file.type)
  const iconColor = getFileIconColor(file.type, colors)

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={400}
      style={({ pressed }) => [
        styles.container,
        { width: ITEM_WIDTH },
        pressed && styles.pressed,
      ]}
    >
      <View
        style={[
          styles.card,
          {
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
          },
          shadows.sm,
        ]}
      >
        {/* Thumbnail / Icon area */}
        <View
          style={[
            styles.thumbnailArea,
            { backgroundColor: colors.backgroundTertiary },
          ]}
        >
          <View
            style={[
              styles.iconCircle,
              { backgroundColor: iconColor + '18' },
            ]}
          >
            <Ionicons name={iconName} size={28} color={iconColor} />
          </View>

          {/* File type badge */}
          <View
            style={[
              styles.typeBadge,
              { backgroundColor: colors.surface },
            ]}
          >
            <AppText
              style={[
                styles.typeBadgeText,
                { color: colors.textSecondary },
              ]}
            >
              {file.type}
            </AppText>
          </View>
        </View>

        {/* Info area */}
        <View style={styles.infoArea}>
          <AppText
            style={[styles.fileName, { color: colors.text }]}
            numberOfLines={2}
          >
            {file.name}
          </AppText>
          <AppText
            style={[styles.fileDate, { color: colors.textTertiary }]}
          >
            {formatDate(file.createdAt)}
          </AppText>
        </View>
      </View>
    </Pressable>
  )
}

export { ITEM_WIDTH, NUM_COLUMNS, GRID_GAP }

const styles = StyleSheet.create({
  container: {
    marginBottom: GRID_GAP,
  },
  pressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
  card: {
    overflow: 'hidden',
  },
  thumbnailArea: {
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  iconCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center',
    alignItems: 'center',
  },
  typeBadge: {
    position: 'absolute',
    top: 6,
    right: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  typeBadgeText: {
    fontSize: 9,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  infoArea: {
    padding: 10,
    minHeight: 56,
  },
  fileName: {
    fontSize: 12,
    fontWeight: '500',
    lineHeight: 16,
    marginBottom: 4,
  },
  fileDate: {
    fontSize: 10,
    fontWeight: '400',
  },
})
