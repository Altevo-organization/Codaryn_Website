import React from 'react'
import { View, StyleSheet } from 'react-native'
import AppText from '../ui/AppText'
import AppButton from '../ui/AppButton'
import { useTheme } from '../../theme/ThemeProvider'

interface ErrorStateProps {
  message?: string
  onRetry?: () => void
}

export default function ErrorState({ message, onRetry }: ErrorStateProps) {
  const { colors } = useTheme()

  return (
    <View style={styles.container}>
      {message ? (
        <AppText style={{ color: colors.muted, marginBottom: 12 }}>{message}</AppText>
      ) : null}
      {onRetry ? <AppButton label="Réessayer" onPress={onRetry} /> : null}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
})
