// src/components/feedback/Toast.tsx
import React from 'react'
import { View, StyleSheet, Animated } from 'react-native'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import { Ionicons } from '@expo/vector-icons'

interface ToastProps {
  visible: boolean
  message: string
  type?: 'success' | 'error'
}

export default function Toast({ visible, message, type = 'success' }: ToastProps) {
  const { colors } = useTheme()

  if (!visible) return null

  const bg =
    type === 'success'
      ? colors.success ?? '#16a34a'
      : colors.danger ?? '#dc2626'

  return (
    <View pointerEvents="none" style={styles.container}>
      <View style={[styles.toast, { backgroundColor: bg }]}>
        <Ionicons
          name={type === 'success' ? 'checkmark-circle-outline' : 'alert-circle-outline'}
          size={18}
          color="#fff"
          style={{ marginRight: 6 }}
        />
        <AppText style={styles.text}>{message}</AppText>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 24,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    elevation: 4,
  },
  text: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '600',
  },
})
