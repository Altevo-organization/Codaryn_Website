import React from 'react'
import { View, ActivityIndicator, StyleSheet } from 'react-native'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'

interface LoadingStateProps {
  message?: string
}

export default function LoadingState({ message }: LoadingStateProps) {
  const { colors } = useTheme()

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={colors.primary} />
      {message ? (
        <AppText style={[styles.message, { color: colors.muted }]}>{message}</AppText>
      ) : null}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  message: {
    marginTop: 8,
  },
})
