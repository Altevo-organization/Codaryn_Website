import React from 'react'
import { View, ActivityIndicator, StyleSheet } from 'react-native'
import { useUiStore } from '../../stores/uiStore'
import { useTheme } from '../../theme/ThemeProvider'

export default function GlobalLoadingOverlay() {
  const { isGlobalLoading } = useUiStore()
  const { colors } = useTheme()

  if (!isGlobalLoading) return null

  return (
    <View style={styles.overlay}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  )
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.35)',
    zIndex: 999,
  },
})
