// src/components/chat/MessageBubble.tsx
import React from 'react'
import { View, StyleSheet } from 'react-native'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'
import type { ChatMessage } from '../../features/chat/types'

interface MessageBubbleProps {
  message: ChatMessage
  isOwnMessage: boolean
}

function formatMessageTime(dateStr: string): string {
  const date = new Date(dateStr)
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  return `${hours}:${minutes}`
}

function getStatusIcon(status: string): string {
  switch (status) {
    case 'sent':
      return '✓'
    case 'delivered':
      return '✓✓'
    case 'read':
      return '✓✓'
    default:
      return ''
  }
}

export default function MessageBubble({ message, isOwnMessage }: MessageBubbleProps) {
  const { colors } = useTheme()

  const bubbleStyle = isOwnMessage
    ? [styles.bubble, styles.ownBubble, { backgroundColor: colors.primary }]
    : [styles.bubble, styles.otherBubble, { backgroundColor: colors.card, borderColor: colors.border }]

  const textColor = isOwnMessage ? '#FFFFFF' : colors.text
  const timeColor = isOwnMessage ? 'rgba(255,255,255,0.7)' : colors.muted
  const statusColor = message.status === 'read' ? '#60A5FA' : 'rgba(255,255,255,0.7)'

  return (
    <View style={[styles.container, isOwnMessage && styles.ownContainer]}>
      <View style={bubbleStyle}>
        <AppText style={[styles.content, { color: textColor }]}>
          {message.content}
        </AppText>

        <View style={styles.metaRow}>
          <AppText style={[styles.time, { color: timeColor }]}>
            {formatMessageTime(message.createdAt)}
          </AppText>

          {isOwnMessage && (
            <AppText style={[styles.status, { color: statusColor }]}>
              {getStatusIcon(message.status)}
            </AppText>
          )}
        </View>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 4,
    marginHorizontal: 16,
    flexDirection: 'row',
  },
  ownContainer: {
    justifyContent: 'flex-end',
  },
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
  },
  ownBubble: {
    borderBottomRightRadius: 4,
  },
  otherBubble: {
    borderBottomLeftRadius: 4,
    borderWidth: 1,
  },
  content: {
    fontSize: 15,
    lineHeight: 20,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 4,
  },
  time: {
    fontSize: 11,
  },
  status: {
    fontSize: 11,
    marginLeft: 4,
  },
})
