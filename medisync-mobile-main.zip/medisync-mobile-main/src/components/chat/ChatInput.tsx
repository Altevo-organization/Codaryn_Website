// src/components/chat/ChatInput.tsx
import React, { useState, useCallback, useRef } from 'react'
import {
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from 'react-native'
import AppText from '../ui/AppText'
import { useTheme } from '../../theme/ThemeProvider'

interface ChatInputProps {
  onSend: (content: string) => void
  onTypingStart?: () => void
  onTypingStop?: () => void
  isSending?: boolean
  placeholder?: string
}

export default function ChatInput({
  onSend,
  onTypingStart,
  onTypingStop,
  isSending = false,
  placeholder = 'Votre message...',
}: ChatInputProps) {
  const { colors } = useTheme()
  const [text, setText] = useState('')
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const isTypingRef = useRef(false)

  const handleChangeText = useCallback(
    (value: string) => {
      setText(value)

      // Handle typing indicator
      if (value.length > 0 && !isTypingRef.current) {
        isTypingRef.current = true
        onTypingStart?.()
      }

      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current)
      }

      // Set new timeout to stop typing
      if (value.length > 0) {
        typingTimeoutRef.current = setTimeout(() => {
          isTypingRef.current = false
          onTypingStop?.()
        }, 2000)
      } else {
        isTypingRef.current = false
        onTypingStop?.()
      }
    },
    [onTypingStart, onTypingStop]
  )

  const handleSend = useCallback(() => {
    const trimmed = text.trim()
    if (!trimmed || isSending) return

    // Stop typing indicator
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current)
    }
    isTypingRef.current = false
    onTypingStop?.()

    onSend(trimmed)
    setText('')
  }, [text, isSending, onSend, onTypingStop])

  const canSend = text.trim().length > 0 && !isSending

  return (
    <View style={[styles.container, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: colors.background,
            color: colors.text,
            borderColor: colors.border,
          },
        ]}
        value={text}
        onChangeText={handleChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        multiline
        maxLength={5000}
        editable={!isSending}
      />

      <TouchableOpacity
        style={[
          styles.sendButton,
          { backgroundColor: canSend ? colors.primary : colors.muted },
        ]}
        onPress={handleSend}
        disabled={!canSend}
        activeOpacity={0.7}
      >
        {isSending ? (
          <ActivityIndicator size="small" color="#FFFFFF" />
        ) : (
          <AppText style={styles.sendButtonText}>↑</AppText>
        )}
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderTopWidth: 1,
  },
  input: {
    flex: 1,
    minHeight: 40,
    maxHeight: 120,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    borderWidth: 1,
    marginRight: 8,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '700',
  },
})
