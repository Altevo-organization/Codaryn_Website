/**
 * ConversationRow Component
 *
 * Displays a single conversation in the list with avatar, name, preview, and unread badge.
 * Redesigned with MediSync design system.
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import {
  Card,
  Avatar,
  Text,
  Row,
  spacing,
  useTheme,
} from '../../ui';
import type { Conversation } from '../../features/chat/types';

// =============================================================================
// TYPES
// =============================================================================

interface ConversationRowProps {
  conversation: Conversation;
  onPress?: () => void;
}

// =============================================================================
// HELPERS
// =============================================================================

function formatTimeLabel(dateStr: string | null): string {
  if (!dateStr) return '';

  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  } else if (diffDays === 1) {
    return 'Hier';
  } else if (diffDays < 7) {
    const days = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
    return days[date.getDay()];
  } else {
    return `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}`;
  }
}

function getParticipantName(conversation: Conversation): string {
  const { firstName, lastName } = conversation.participant;
  return `${firstName} ${lastName}`.trim() || 'Utilisateur';
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function ConversationRow({ conversation, onPress }: ConversationRowProps) {
  const { colors } = useTheme();
  const hasUnread = conversation.unreadCount > 0;
  const participantName = getParticipantName(conversation);

  return (
    <Card
      variant="outlined"
      padding="md"
      onPress={onPress}
      style={[styles.card, hasUnread && { borderColor: colors.primary }]}
    >
      <Row gap="md" align="center">
        {/* Avatar */}
        <Avatar
          name={participantName}
          size="md"
          showStatus
          isOnline={false}
        />

        {/* Content */}
        <View style={styles.content}>
          {/* Header row: name + time */}
          <Row justify="space-between" align="center" style={styles.headerRow}>
            <Text
              variant="label"
              numberOfLines={1}
              style={[styles.name, hasUnread && styles.unreadName]}
            >
              {participantName}
            </Text>
            <Text variant="caption" color="tertiary">
              {formatTimeLabel(conversation.lastMessageAt)}
            </Text>
          </Row>

          {/* Preview row: message + badge */}
          <Row align="center" style={styles.previewRow}>
            <Text
              variant="bodySmall"
              color={hasUnread ? 'primary' : 'secondary'}
              numberOfLines={1}
              style={[styles.preview, hasUnread && styles.unreadPreview]}
            >
              {conversation.lastMessage?.content || 'Aucun message'}
            </Text>

            {hasUnread && (
              <View
                style={[styles.badge, { backgroundColor: colors.primary }]}
              >
                <Text
                  variant="caption"
                  style={styles.badgeText}
                >
                  {conversation.unreadCount > 99
                    ? '99+'
                    : conversation.unreadCount}
                </Text>
              </View>
            )}
          </Row>
        </View>
      </Row>
    </Card>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing.sm,
  },
  content: {
    flex: 1,
  },
  headerRow: {
    marginBottom: spacing.xxs,
  },
  name: {
    flex: 1,
    marginRight: spacing.sm,
  },
  unreadName: {
    fontWeight: '700',
  },
  previewRow: {
    marginTop: spacing.xxs,
  },
  preview: {
    flex: 1,
  },
  unreadPreview: {
    fontWeight: '500',
  },
  badge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.xs,
    marginLeft: spacing.sm,
  },
  badgeText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 11,
  },
});
