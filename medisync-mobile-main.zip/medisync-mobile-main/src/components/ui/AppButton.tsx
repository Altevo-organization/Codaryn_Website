import React from 'react'
import { TouchableOpacity, Text, StyleSheet, ViewStyle } from 'react-native'
import { useTheme } from '../../theme/ThemeProvider'

interface AppButtonProps {
  label: string
  onPress: () => void
  style?: ViewStyle
  disabled?: boolean
}

export default function AppButton({ label, onPress, style, disabled }: AppButtonProps) {
  const { colors } = useTheme()

  return (
    <TouchableOpacity
      style={[
        styles.btn,
        {
          backgroundColor: colors.primary,
          opacity: disabled ? 0.5 : 1,
        },
        style,
      ]}
      onPress={onPress}
      disabled={disabled}
    >
      <Text style={[styles.label, { color: colors.text }]}>{label}</Text>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  btn: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  label: {
    fontWeight: '600',
  },
})
