import React from 'react'
import { Text, TextProps, StyleSheet } from 'react-native'
import { useTheme } from '../../theme/ThemeProvider'

export default function AppText(props: TextProps) {
  const { colors } = useTheme()

  return <Text {...props} style={[styles.text, { color: colors.text }, props.style]} />
}

const styles = StyleSheet.create({
  text: {},
})
