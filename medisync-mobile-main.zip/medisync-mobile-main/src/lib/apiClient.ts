// src/lib/apiClient.ts
import axios from 'axios'
import { useAuthStore } from '../stores/authStore'

const baseURL = process.env.EXPO_PUBLIC_API_URL

// 🔍 Log clair au démarrage pour vérifier l'URL utilisée
// Tu le verras dans la console Metro (terminal Expo)
console.log('[API] baseURL =', baseURL)

if (!baseURL) {
  console.warn(
    '[API] EXPO_PUBLIC_API_URL est undefined. Les requêtes utiliseront des URLs relatives (probablement vers le dev server Expo, pas ton backend).'
  )
}

export const api = axios.create({
  baseURL: baseURL || undefined,
  timeout: 10000,
})

// Interceptor pour ajouter automatiquement le token d'authentification
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().accessToken
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Interceptor pour gérer les erreurs 401 (token expiré)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token invalide ou expiré - déconnecter l'utilisateur
      const { clearAuth } = useAuthStore.getState()
      clearAuth()
    }
    return Promise.reject(error)
  }
)
