/**
 * Biometric Authentication Service
 *
 * Handles Face ID, Touch ID, and fingerprint authentication
 */

import * as LocalAuthentication from 'expo-local-authentication'
import * as SecureStore from 'expo-secure-store'
import { Alert, Platform } from 'react-native'

// Keys for secure storage
const BIOMETRIC_ENABLED_KEY = 'biometric_auth_enabled'

export interface BiometricCapabilities {
  isAvailable: boolean
  biometricType: 'face' | 'fingerprint' | 'iris' | 'none'
  enrolledLevel: LocalAuthentication.SecurityLevel
}

/**
 * Check if biometric authentication is available on this device
 */
export async function checkBiometricAvailability(): Promise<BiometricCapabilities> {
  try {
    const hasHardware = await LocalAuthentication.hasHardwareAsync()
    const isEnrolled = await LocalAuthentication.isEnrolledAsync()
    const supportedTypes =
      await LocalAuthentication.supportedAuthenticationTypesAsync()
    const enrolledLevel =
      await LocalAuthentication.getEnrolledLevelAsync()

    if (!hasHardware || !isEnrolled) {
      return {
        isAvailable: false,
        biometricType: 'none',
        enrolledLevel: LocalAuthentication.SecurityLevel.NONE,
      }
    }

    // Determine biometric type
    let biometricType: 'face' | 'fingerprint' | 'iris' | 'none' = 'none'
    if (
      supportedTypes.includes(
        LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION
      )
    ) {
      biometricType = 'face'
    } else if (
      supportedTypes.includes(
        LocalAuthentication.AuthenticationType.FINGERPRINT
      )
    ) {
      biometricType = 'fingerprint'
    } else if (
      supportedTypes.includes(LocalAuthentication.AuthenticationType.IRIS)
    ) {
      biometricType = 'iris'
    }

    return {
      isAvailable: true,
      biometricType,
      enrolledLevel,
    }
  } catch (error) {
    console.error('Error checking biometric availability:', error)
    return {
      isAvailable: false,
      biometricType: 'none',
      enrolledLevel: LocalAuthentication.SecurityLevel.NONE,
    }
  }
}

/**
 * Get a user-friendly name for the biometric type
 */
export function getBiometricTypeName(
  type: 'face' | 'fingerprint' | 'iris' | 'none'
): string {
  switch (type) {
    case 'face':
      return Platform.OS === 'ios' ? 'Face ID' : 'Reconnaissance faciale'
    case 'fingerprint':
      return Platform.OS === 'ios' ? 'Touch ID' : 'Empreinte digitale'
    case 'iris':
      return 'Reconnaissance iris'
    default:
      return 'Biométrie'
  }
}

/**
 * Authenticate using biometrics
 */
export async function authenticateWithBiometrics(
  promptMessage?: string
): Promise<boolean> {
  try {
    const { isAvailable } = await checkBiometricAvailability()
    if (!isAvailable) {
      return false
    }

    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: promptMessage || 'Authentifiez-vous pour continuer',
      cancelLabel: 'Annuler',
      disableDeviceFallback: false, // Allow PIN/password fallback
      fallbackLabel: 'Utiliser le code',
    })

    return result.success
  } catch (error) {
    console.error('Biometric authentication error:', error)
    return false
  }
}

/**
 * Enable biometric authentication for the app
 * Requires user to authenticate first to confirm
 */
export async function enableBiometricAuth(): Promise<boolean> {
  try {
    const capabilities = await checkBiometricAvailability()

    if (!capabilities.isAvailable) {
      Alert.alert(
        'Non disponible',
        'L\'authentification biométrique n\'est pas disponible sur cet appareil. Veuillez configurer Face ID ou Touch ID dans les paramètres de votre appareil.'
      )
      return false
    }

    const biometricName = getBiometricTypeName(capabilities.biometricType)

    // Authenticate to confirm
    const success = await authenticateWithBiometrics(
      `Authentifiez-vous avec ${biometricName} pour activer cette fonctionnalité`
    )

    if (success) {
      await SecureStore.setItemAsync(BIOMETRIC_ENABLED_KEY, 'true')
      return true
    }

    return false
  } catch (error) {
    console.error('Error enabling biometric auth:', error)
    Alert.alert('Erreur', 'Impossible d\'activer l\'authentification biométrique')
    return false
  }
}

/**
 * Disable biometric authentication for the app
 */
export async function disableBiometricAuth(): Promise<boolean> {
  try {
    await SecureStore.deleteItemAsync(BIOMETRIC_ENABLED_KEY)
    return true
  } catch (error) {
    console.error('Error disabling biometric auth:', error)
    return false
  }
}

/**
 * Check if biometric auth is enabled for the app
 */
export async function isBiometricAuthEnabled(): Promise<boolean> {
  try {
    const value = await SecureStore.getItemAsync(BIOMETRIC_ENABLED_KEY)
    return value === 'true'
  } catch (error) {
    console.error('Error checking biometric auth status:', error)
    return false
  }
}

/**
 * Perform biometric authentication if enabled
 * Returns true if auth succeeded or biometrics is disabled
 */
export async function requireBiometricAuthIfEnabled(): Promise<boolean> {
  try {
    const isEnabled = await isBiometricAuthEnabled()
    if (!isEnabled) {
      return true // No auth required
    }

    const capabilities = await checkBiometricAvailability()
    if (!capabilities.isAvailable) {
      // Biometrics no longer available, disable the feature
      await disableBiometricAuth()
      return true
    }

    return await authenticateWithBiometrics('Authentifiez-vous pour accéder à MediSync')
  } catch (error) {
    console.error('Error in biometric auth check:', error)
    return false
  }
}

export default {
  checkBiometricAvailability,
  getBiometricTypeName,
  authenticateWithBiometrics,
  enableBiometricAuth,
  disableBiometricAuth,
  isBiometricAuthEnabled,
  requireBiometricAuthIfEnabled,
}
