/**
 * Haptics Service
 *
 * Provides haptic feedback throughout the app
 * Respects user preferences for haptic feedback
 */

import * as Haptics from 'expo-haptics'
import { Platform } from 'react-native'
import { usePreferencesStore } from '../stores/preferencesStore'

// Types for different haptic feedback styles
export type HapticFeedbackType =
  | 'light'
  | 'medium'
  | 'heavy'
  | 'success'
  | 'warning'
  | 'error'
  | 'selection'

/**
 * Trigger haptic feedback
 * Automatically checks user preference before triggering
 */
export async function triggerHaptic(type: HapticFeedbackType = 'light'): Promise<void> {
  // Check if haptics are enabled in preferences
  const hapticsEnabled = usePreferencesStore.getState().hapticsEnabled

  if (!hapticsEnabled) {
    return
  }

  // Android doesn't support all haptic types
  if (Platform.OS === 'android' && !['light', 'medium', 'heavy'].includes(type)) {
    // Fallback to notification for feedback types on Android
    try {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    } catch (error) {
      // Haptics may not be supported
      console.debug('Haptics not supported:', error)
    }
    return
  }

  try {
    switch (type) {
      case 'light':
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
        break
      case 'medium':
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
        break
      case 'heavy':
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy)
        break
      case 'success':
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
        break
      case 'warning':
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)
        break
      case 'error':
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)
        break
      case 'selection':
        await Haptics.selectionAsync()
        break
      default:
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    }
  } catch (error) {
    // Haptics may not be supported on all devices/simulators
    console.debug('Haptics error:', error)
  }
}

/**
 * Trigger light tap feedback
 * Use for: button taps, selection changes
 */
export async function tapFeedback(): Promise<void> {
  await triggerHaptic('light')
}

/**
 * Trigger selection feedback
 * Use for: picker changes, slider adjustments
 */
export async function selectionFeedback(): Promise<void> {
  await triggerHaptic('selection')
}

/**
 * Trigger success feedback
 * Use for: successful form submissions, completions
 */
export async function successFeedback(): Promise<void> {
  await triggerHaptic('success')
}

/**
 * Trigger warning feedback
 * Use for: warnings, confirmations needed
 */
export async function warningFeedback(): Promise<void> {
  await triggerHaptic('warning')
}

/**
 * Trigger error feedback
 * Use for: errors, failed operations
 */
export async function errorFeedback(): Promise<void> {
  await triggerHaptic('error')
}

/**
 * Trigger heavy impact feedback
 * Use for: important actions, destructive operations
 */
export async function heavyFeedback(): Promise<void> {
  await triggerHaptic('heavy')
}

/**
 * React hook for using haptics in components
 */
export function useHaptics() {
  const hapticsEnabled = usePreferencesStore((s) => s.hapticsEnabled)

  return {
    hapticsEnabled,
    tap: tapFeedback,
    selection: selectionFeedback,
    success: successFeedback,
    warning: warningFeedback,
    error: errorFeedback,
    heavy: heavyFeedback,
    trigger: triggerHaptic,
  }
}

export default {
  triggerHaptic,
  tapFeedback,
  selectionFeedback,
  successFeedback,
  warningFeedback,
  errorFeedback,
  heavyFeedback,
  useHaptics,
}
