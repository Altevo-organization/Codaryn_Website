/**
 * Legacy Theme Provider
 *
 * Re-exports the new ThemeProvider from src/ui for backward compatibility.
 * Existing code using `import { useTheme } from '../../theme/ThemeProvider'`
 * will continue to work.
 *
 * NOTE: New code should import from '../../ui' directly.
 */

export {
  ThemeProvider,
  useTheme,
  useColors,
  useIsDarkMode,
  useThemedStyles,
} from '../ui/ThemeProvider';

export type { ThemeName, ThemeContextValue } from '../ui/ThemeProvider';
