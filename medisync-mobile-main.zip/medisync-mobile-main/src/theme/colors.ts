export type Colors = {
  background: string;
  text: string;
  primary: string;
  muted: string;
  card: string;
  border: string;
  danger: string;
  success: string;
};

export const lightColors: Colors = {
  background: '#F9FAFB',
  text: '#0F172A',
  primary: '#e00404ff',
  muted: '#6B7280',
  card: '#FFFFFF',
  border: '#E5E7EB',
  danger: '#EF4444',
  success: '#22C55E',
};

export const darkColors: Colors = {
  background: '#0B1020',
  text: '#F9FAFB',
  primary: '#6366F1',
  muted: '#9CA3AF',
  card: '#151A2C',
  border: '#1F2937',
  danger: '#F87171',
  success: '#22C55E',
};
