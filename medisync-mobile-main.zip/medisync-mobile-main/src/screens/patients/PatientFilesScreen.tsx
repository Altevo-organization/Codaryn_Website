// src/screens/patients/PatientFilesScreen.tsx
import React, { useState, useCallback, useMemo } from 'react'
import {
  View,
  StyleSheet,
  FlatList,
  RefreshControl,
  Alert,
  TouchableOpacity,
  Dimensions,
  ActionSheetIOS,
  Platform,
} from 'react-native'
import { useRoute, useNavigation } from '@react-navigation/native'
import type { RouteProp } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { Ionicons } from '@expo/vector-icons'
import * as DocumentPicker from 'expo-document-picker'

import Screen from '../../components/layout/Screen'
import AppText from '../../components/ui/AppText'
import LoadingState from '../../components/feedback/LoadingState'
import ErrorState from '../../components/feedback/ErrorState'
import Toast from '../../components/feedback/Toast'
import { useTheme } from '../../theme/ThemeProvider'
import type { DossierStackParamList } from '../../navigation/types'

import {
  usePatientFilesQuery,
  useUploadFileMutation,
  useDeleteFileMutation,
} from '../../features/files/hooks'
import { useFoldersStore } from '../../features/files/foldersStore'
import { useFileAssignmentsStore } from '../../features/files/fileAssignmentsStore'
import type { FileItem, FolderItem, SortOption, UploadFileInput } from '../../features/files/types'
import { sortOptions } from '../../features/files/types'

import DocumentGridItem, { NUM_COLUMNS, GRID_GAP } from '../../components/files/DocumentGridItem'
import FolderGridItem from '../../components/files/FolderGridItem'
import Breadcrumb from '../../components/files/Breadcrumb'
import SortMenu from '../../components/files/SortMenu'
import DocumentsEmptyState from '../../components/files/DocumentsEmptyState'
import CreateFolderModal from '../../components/files/CreateFolderModal'
import MoveToFolderModal from '../../components/files/MoveToFolderModal'
import DocumentViewerModal from '../../components/files/DocumentViewerModal'

const { width: SCREEN_WIDTH } = Dimensions.get('window')

type Route = RouteProp<DossierStackParamList, 'PatientFiles'>
type Nav = NativeStackNavigationProp<DossierStackParamList, 'PatientFiles'>

type GridItem =
  | { type: 'folder'; data: FolderItem }
  | { type: 'file'; data: FileItem }

export default function PatientFilesScreen() {
  const route = useRoute<Route>()
  const navigation = useNavigation<Nav>()
  const { colors, radius, shadows } = useTheme()
  const patientId = route.params.patientId

  // State
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null)
  const [sortOption, setSortOption] = useState<SortOption>('date-desc')
  const [createFolderVisible, setCreateFolderVisible] = useState(false)
  const [moveModalVisible, setMoveModalVisible] = useState(false)
  const [selectedItem, setSelectedItem] = useState<{ type: 'file' | 'folder'; id: string | number } | null>(null)
  const [viewerFile, setViewerFile] = useState<FileItem | null>(null)
  const [toast, setToast] = useState<{
    visible: boolean
    message: string
    type: 'success' | 'error'
  }>({ visible: false, message: '', type: 'success' })

  // Data fetching
  const { data: allFiles, isLoading, error, refetch, isRefetching } = usePatientFilesQuery(
    patientId,
    { limit: 200, sortOrder: 'DESC', sortBy: 'createdAt' }
  )

  const { mutate: uploadFile, isPending: isUploading } = useUploadFileMutation(patientId)
  const { mutate: deleteFile, isPending: isDeleting } = useDeleteFileMutation(patientId)

  // Folder store
  const foldersStore = useFoldersStore()
  const fileAssignments = useFileAssignmentsStore()

  const folders = useMemo(
    () => foldersStore.getFoldersByParent(patientId, currentFolderId),
    [foldersStore, patientId, currentFolderId]
  )

  const allFolders = useMemo(
    () => foldersStore.getFoldersByPatient(patientId),
    [foldersStore, patientId]
  )

  const breadcrumbPath = useMemo(
    () => foldersStore.getBreadcrumbPath(patientId, currentFolderId),
    [foldersStore, patientId, currentFolderId]
  )

  const currentFolder = useMemo(
    () => currentFolderId ? foldersStore.getFolderById(patientId, currentFolderId) : null,
    [foldersStore, patientId, currentFolderId]
  )

  // Filter files by current folder
  const filesInFolder = useMemo(() => {
    if (!allFiles) return []
    return allFiles.filter((file) => {
      const assignment = fileAssignments.getAssignment(file.id)
      return assignment === currentFolderId
    })
  }, [allFiles, fileAssignments, currentFolderId])

  // Sort files
  const sortedFiles = useMemo(() => {
    const sorted = [...filesInFolder]
    const { config } = sortOptions[sortOption]

    sorted.sort((a, b) => {
      let comparison = 0
      if (config.sortBy === 'name') {
        comparison = a.name.localeCompare(b.name)
      } else {
        comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      }
      return config.sortOrder === 'ASC' ? comparison : -comparison
    })

    return sorted
  }, [filesInFolder, sortOption])

  // Combine folders and files for grid
  const gridItems: GridItem[] = useMemo(() => {
    const folderItems: GridItem[] = folders.map((f) => ({ type: 'folder', data: f }))
    const fileItems: GridItem[] = sortedFiles.map((f) => ({ type: 'file', data: f }))
    return [...folderItems, ...fileItems]
  }, [folders, sortedFiles])

  // Helpers
  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ visible: true, message, type })
    setTimeout(() => setToast((t) => ({ ...t, visible: false })), 2500)
  }, [])

  // Handlers
  const handlePickDocument = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*', '*/*'],
        copyToCacheDirectory: true,
      })

      if (res.canceled) return

      const doc = res.assets[0]
      const input: Omit<UploadFileInput, 'patientId'> = {
        uri: doc.uri,
        name: doc.name ?? 'document',
        mimeType: doc.mimeType ?? null,
        size: doc.size ?? null,
        description: undefined,
      }

      uploadFile(input, {
        onSuccess: (newFile) => {
          // Assign to current folder
          if (currentFolderId) {
            fileAssignments.assignFile(newFile.id, currentFolderId)
          }
          showToast('Document importé', 'success')
        },
        onError: (err: any) => {
          console.error('[UploadFile] error', err)
          const msg = err instanceof Error ? err.message : "Impossible d'importer le document."
          Alert.alert('Erreur', msg)
          showToast("Erreur lors de l'import", 'error')
        },
      })
    } catch (e) {
      console.error('[DocumentPicker] error', e)
    }
  }

  const handleCreateFolder = (name: string) => {
    foldersStore.createFolder(patientId, name, currentFolderId)
    showToast('Dossier créé', 'success')
  }

  const handleDeleteFile = (fileId: number) => {
    Alert.alert('Supprimer le document', 'Cette action est irréversible.', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: () => {
          deleteFile(fileId, {
            onSuccess: () => {
              fileAssignments.removeAssignment(fileId)
              showToast('Document supprimé', 'success')
            },
            onError: () => {
              showToast('Erreur lors de la suppression', 'error')
            },
          })
        },
      },
    ])
  }

  const handleDeleteFolder = (folderId: string) => {
    const folder = foldersStore.getFolderById(patientId, folderId)
    Alert.alert(
      'Supprimer le dossier',
      `Supprimer "${folder?.name}" et déplacer son contenu à la racine ?`,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: () => {
            // Move files to root first
            fileAssignments.moveFilesToRoot(folderId)
            foldersStore.deleteFolder(patientId, folderId)
            showToast('Dossier supprimé', 'success')
          },
        },
      ]
    )
  }

  const handleMoveItem = (targetFolderId: string | null) => {
    if (!selectedItem) return

    if (selectedItem.type === 'file') {
      fileAssignments.assignFile(selectedItem.id as number, targetFolderId)
      showToast('Document déplacé', 'success')
    } else {
      foldersStore.moveFolder(patientId, selectedItem.id as string, targetFolderId)
      showToast('Dossier déplacé', 'success')
    }
    setSelectedItem(null)
  }

  const showItemActions = (item: GridItem) => {
    const isFile = item.type === 'file'
    const itemName = isFile ? (item.data as FileItem).name : (item.data as FolderItem).name
    const itemId = isFile ? (item.data as FileItem).id : (item.data as FolderItem).id

    const actions = [
      { label: 'Déplacer vers...', action: () => {
        setSelectedItem({ type: item.type, id: itemId })
        setMoveModalVisible(true)
      }},
      { label: 'Supprimer', action: () => {
        if (isFile) {
          handleDeleteFile(itemId as number)
        } else {
          handleDeleteFolder(itemId as string)
        }
      }, destructive: true },
    ]

    if (Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          title: itemName,
          options: ['Annuler', ...actions.map((a) => a.label)],
          destructiveButtonIndex: actions.findIndex((a) => a.destructive) + 1,
          cancelButtonIndex: 0,
        },
        (index) => {
          if (index > 0) {
            actions[index - 1].action()
          }
        }
      )
    } else {
      Alert.alert(itemName, undefined, [
        { text: 'Annuler', style: 'cancel' },
        ...actions.map((a) => ({
          text: a.label,
          style: a.destructive ? ('destructive' as const) : ('default' as const),
          onPress: a.action,
        })),
      ])
    }
  }

  const handleFolderPress = (folder: FolderItem) => {
    setCurrentFolderId(folder.id)
  }

  const handleFilePress = (file: FileItem) => {
    setViewerFile(file)
  }

  const handleBreadcrumbNavigate = (folderId: string | null) => {
    setCurrentFolderId(folderId)
  }

  // Render
  const renderGridItem = ({ item }: { item: GridItem }) => {
    if (item.type === 'folder') {
      const folder = item.data as FolderItem
      const itemCount = foldersStore.getItemCount(patientId, folder.id, allFiles ?? [])

      return (
        <FolderGridItem
          folder={{ ...folder, itemCount }}
          onPress={() => handleFolderPress(folder)}
          onLongPress={() => showItemActions(item)}
        />
      )
    }

    const file = item.data as FileItem
    return (
      <DocumentGridItem
        file={file}
        onPress={() => handleFilePress(file)}
        onLongPress={() => showItemActions(item)}
      />
    )
  }

  // Loading state
  if (isLoading) {
    return (
      <Screen>
        <LoadingState message="Chargement des documents..." />
      </Screen>
    )
  }

  // Error state
  if (error) {
    return (
      <Screen>
        <ErrorState message="Impossible de charger les documents." onRetry={refetch} />
      </Screen>
    )
  }

  const isEmpty = gridItems.length === 0

  return (
    <Screen>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={styles.backButton}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <Ionicons name="chevron-back" size={24} color={colors.primary} />
            </TouchableOpacity>

            <View style={styles.titleContainer}>
              <AppText style={[styles.title, { color: colors.text }]}>Documents</AppText>
              <AppText style={[styles.subtitle, { color: colors.textSecondary }]} numberOfLines={1}>
                Dossier patient
              </AppText>
            </View>

            <View style={styles.headerActions}>
              <TouchableOpacity
                onPress={() => setCreateFolderVisible(true)}
                style={[
                  styles.headerActionButton,
                  { backgroundColor: colors.surface, borderColor: colors.border },
                ]}
                activeOpacity={0.7}
              >
                <Ionicons name="folder-outline" size={18} color={colors.primary} />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handlePickDocument}
                disabled={isUploading}
                style={[
                  styles.importButton,
                  { backgroundColor: colors.primary, opacity: isUploading ? 0.6 : 1 },
                ]}
                activeOpacity={0.8}
              >
                <Ionicons name="add" size={20} color={colors.textInverse} />
                <AppText style={[styles.importButtonText, { color: colors.textInverse }]}>
                  {isUploading ? 'Import...' : 'Importer'}
                </AppText>
              </TouchableOpacity>
            </View>
          </View>

          {/* Breadcrumb */}
          <Breadcrumb items={breadcrumbPath} onNavigate={handleBreadcrumbNavigate} />

          {/* Toolbar */}
          {!isEmpty && (
            <View style={styles.toolbar}>
              <SortMenu value={sortOption} onChange={setSortOption} />
              <AppText style={[styles.itemCount, { color: colors.textSecondary }]}>
                {gridItems.length} élément{gridItems.length !== 1 ? 's' : ''}
              </AppText>
            </View>
          )}
        </View>

        {/* Content */}
        {isEmpty ? (
          <DocumentsEmptyState
            isFolder={currentFolderId !== null}
            folderName={currentFolder?.name}
            onImport={handlePickDocument}
            onCreateFolder={() => setCreateFolderVisible(true)}
          />
        ) : (
          <FlatList
            data={gridItems}
            keyExtractor={(item) =>
              item.type === 'folder'
                ? `folder-${(item.data as FolderItem).id}`
                : `file-${(item.data as FileItem).id}`
            }
            renderItem={renderGridItem}
            numColumns={NUM_COLUMNS}
            columnWrapperStyle={styles.gridRow}
            contentContainerStyle={styles.gridContent}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                colors={[colors.primary]}
                tintColor={colors.primary}
                refreshing={isRefetching || isDeleting}
                onRefresh={refetch}
              />
            }
          />
        )}

        {/* Modals */}
        <CreateFolderModal
          visible={createFolderVisible}
          onClose={() => setCreateFolderVisible(false)}
          onConfirm={handleCreateFolder}
          parentFolderName={currentFolder?.name}
        />

        <MoveToFolderModal
          visible={moveModalVisible}
          onClose={() => {
            setMoveModalVisible(false)
            setSelectedItem(null)
          }}
          folders={allFolders.filter((f) => {
            // Exclude current folder and selected item (if folder)
            if (selectedItem?.type === 'folder' && f.id === selectedItem.id) return false
            return true
          })}
          currentFolderId={currentFolderId}
          onSelectFolder={handleMoveItem}
          itemName={
            selectedItem?.type === 'file'
              ? allFiles?.find((f) => f.id === selectedItem.id)?.name ?? ''
              : allFolders.find((f) => f.id === selectedItem?.id)?.name ?? ''
          }
        />

        <DocumentViewerModal
          visible={viewerFile !== null}
          onClose={() => setViewerFile(null)}
          file={viewerFile}
        />

        <Toast visible={toast.visible} message={toast.message} type={toast.type} />
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingBottom: 8,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  backButton: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: -8,
  },
  titleContainer: {
    flex: 1,
    marginLeft: 4,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
  },
  subtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerActionButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  importButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    gap: 4,
  },
  importButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 12,
  },
  itemCount: {
    fontSize: 13,
  },
  gridContent: {
    paddingBottom: 32,
  },
  gridRow: {
    justifyContent: 'flex-start',
    gap: GRID_GAP,
  },
})
