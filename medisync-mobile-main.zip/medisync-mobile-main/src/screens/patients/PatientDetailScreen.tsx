// src/screens/patients/PatientDetailScreen.tsx
import React, { useState } from 'react'
import { StyleSheet, View, Alert } from 'react-native'
import Screen from '../../components/layout/Screen'
import LoadingState from '../../components/feedback/LoadingState'
import ErrorState from '../../components/feedback/ErrorState'
import { useRoute, useNavigation } from '@react-navigation/native'
import type { RouteProp } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'
import type { DossierStackParamList } from '../../navigation/types'
import {
  usePatientQuery,
  useCreatePatientMutation,
  useUpdatePatientMutation,
} from '../../features/patients/hooks'
import PatientForm from '../../components/patients/PatientForm'
import Toast from '../../components/feedback/Toast'
import type {
  CreatePatientPayload,
  UpdatePatientPayload,
} from '../../features/patients/api'
import { exportPatientPdf } from '../../utils/patientPdfExport'

type Route = RouteProp<DossierStackParamList, 'PatientDetail'>
type Nav = NativeStackNavigationProp<DossierStackParamList, 'PatientDetail'>

export default function PatientDetailScreen() {
  const route = useRoute<Route>()
  const navigation = useNavigation<Nav>()
  const patientId = route.params?.patientId

  const isEditMode = !!patientId

  const { data: patient, isLoading, error, refetch } = usePatientQuery(patientId)

  const { mutate: createPatient, isPending: isCreating } =
    useCreatePatientMutation()
  const { mutate: updatePatient, isPending: isUpdating } =
    useUpdatePatientMutation(patientId ?? 0)

  const [showSavedToast, setShowSavedToast] = useState(false)
  const [isExporting, setIsExporting] = useState(false)

  const handleCreate = (payload: CreatePatientPayload) => {
    createPatient(payload, {
      onSuccess: () => {
        navigation.goBack()
      },
      onError: (err: any) => {
        console.error('[CreatePatient] error', err)
        Alert.alert(
          'Erreur',
          err instanceof Error ? err.message : "Impossible de créer le patient.",
        )
      },
    })
  }

  const handleAutoSave = (payload: UpdatePatientPayload) => {
    if (!patientId) return
    updatePatient(payload, {
      onSuccess: () => {
        setShowSavedToast(true)
        setTimeout(() => setShowSavedToast(false), 2000)
      },
      onError: (err: any) => {
        console.error('[UpdatePatient] error', err)
        // pas d'alert agressive en auto-save, on reste discret
      },
    })
  }

  const handleExportPdf = async () => {
    if (!patient) return
    setIsExporting(true)
    try {
      const result = await exportPatientPdf(patient)
      if (!result.success && result.error) {
        Alert.alert('Erreur', result.error)
      }
    } catch (err) {
      console.error('[ExportPdf] error', err)
      Alert.alert('Erreur', "Impossible d'exporter le dossier patient.")
    } finally {
      setIsExporting(false)
    }
  }

  if (isEditMode) {
    if (isLoading) {
      return (
        <Screen>
          <LoadingState message="Chargement du dossier patient..." />
        </Screen>
      )
    }

    if (error || !patient) {
      return (
        <Screen>
          <ErrorState
            message="Impossible de charger le dossier du patient."
            onRetry={refetch}
          />
        </Screen>
      )
    }
  }

  return (
    <Screen>
      <View style={styles.container}>
        <PatientForm
          mode={isEditMode ? 'edit' : 'create'}
          initialPatient={isEditMode ? patient : undefined}
          onCreate={handleCreate}
          onAutoSave={handleAutoSave}
          submitting={isCreating || isUpdating}
          onOpenFiles={
            isEditMode && patientId
              ? () => navigation.navigate('PatientFiles', { patientId })
              : undefined
          }
          onExportPDF={isEditMode && patient ? handleExportPdf : undefined}
          exporting={isExporting}
        />
        <Toast visible={showSavedToast} message="Informations modifiées" />
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
})
