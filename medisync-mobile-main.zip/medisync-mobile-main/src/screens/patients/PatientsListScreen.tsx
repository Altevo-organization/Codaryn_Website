/**
 * PatientsListScreen
 *
 * List of patients with search functionality.
 * Redesigned with MediSync design system.
 */

import React, { useState, useCallback } from 'react';
import { FlatList, RefreshControl, Alert, View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  ScreenContainer,
  Row,
  Text,
  Button,
  Input,
  EmptyState,
  SkeletonListItem,
  Stack,
  spacing,
  useTheme,
} from '../../ui';
import PatientListItem from '../../components/patients/PatientListItem';
import {
  usePatientsQuery,
  useDeletePatientMutation,
} from '../../features/patients/hooks';
import type { Patient } from '../../features/patients/types';
import type { DossierStackParamList } from '../../navigation/types';

// =============================================================================
// TYPES
// =============================================================================

type Nav = NativeStackNavigationProp<DossierStackParamList, 'Patients'>;

// =============================================================================
// COMPONENT
// =============================================================================

export default function PatientsListScreen() {
  const { colors } = useTheme();
  const navigation = useNavigation<Nav>();
  const [search, setSearch] = useState('');

  // Data fetching
  const {
    data: patients,
    isLoading,
    error,
    refetch,
    isRefetching,
  } = usePatientsQuery({
    limit: 50,
    sortBy: 'createdAt',
    sortOrder: 'DESC',
    search: search.trim() || undefined,
  });

  const { mutate: deletePatient, isPending: isDeleting } =
    useDeletePatientMutation();

  // Handlers
  const handlePressPatient = useCallback(
    (patient: Patient) => {
      navigation.navigate('PatientDetail', { patientId: patient.id });
    },
    [navigation]
  );

  const handleDeletePatient = useCallback(
    (patient: Patient) => {
      Alert.alert(
        'Supprimer le patient',
        `Voulez-vous vraiment supprimer le dossier de ${patient.firstName} ${patient.lastName} ?`,
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Supprimer',
            style: 'destructive',
            onPress: () =>
              deletePatient(patient.id, {
                onSuccess: () => refetch(),
              }),
          },
        ]
      );
    },
    [deletePatient, refetch]
  );

  const handleCreatePatient = useCallback(() => {
    navigation.navigate('PatientDetail', {});
  }, [navigation]);

  const handleSearch = useCallback(() => {
    refetch();
  }, [refetch]);

  // Render list item
  const renderPatient = useCallback(
    ({ item }: { item: Patient }) => (
      <PatientListItem
        patient={item}
        onPress={() => handlePressPatient(item)}
        onLongPress={() => handleDeletePatient(item)}
      />
    ),
    [handlePressPatient, handleDeletePatient]
  );

  // Loading skeleton
  if (isLoading) {
    return (
      <ScreenContainer>
        <Row justify="space-between" align="center" style={styles.header}>
          <Text variant="h2">Patients</Text>
          <Button
            label="Nouveau"
            onPress={handleCreatePatient}
            size="sm"
            iconLeft={<Ionicons name="add" size={18} color="#fff" />}
          />
        </Row>
        <Stack gap="sm" style={styles.skeletonList}>
          {[1, 2, 3, 4, 5].map((i) => (
            <SkeletonListItem key={i} />
          ))}
        </Stack>
      </ScreenContainer>
    );
  }

  // Error state
  if (error) {
    return (
      <ScreenContainer centerContent>
        <EmptyState
          icon="alert-circle-outline"
          title="Erreur de chargement"
          description="Impossible de charger la liste des patients. Vérifiez votre connexion."
          actionLabel="Réessayer"
          onAction={refetch}
        />
      </ScreenContainer>
    );
  }

  const patientList = patients ?? [];

  return (
    <ScreenContainer noPadding>
      {/* Header */}
      <View style={styles.headerContainer}>
        <Row justify="space-between" align="center" style={styles.header}>
          <Text variant="h2">Patients</Text>
          <Button
            label="Nouveau"
            onPress={handleCreatePatient}
            size="sm"
            iconLeft={<Ionicons name="add" size={18} color="#fff" />}
          />
        </Row>

        {/* Search input */}
        <Input
          placeholder="Rechercher un patient..."
          value={search}
          onChangeText={setSearch}
          onSubmitEditing={handleSearch}
          returnKeyType="search"
          autoCapitalize="none"
          autoCorrect={false}
          iconLeft={
            <Ionicons
              name="search-outline"
              size={20}
              color={colors.textTertiary}
            />
          }
          iconRight={
            search.length > 0 ? (
              <Ionicons
                name="close-circle"
                size={20}
                color={colors.textTertiary}
              />
            ) : undefined
          }
          onPressIconRight={() => setSearch('')}
          containerStyle={styles.searchContainer}
        />
      </View>

      {/* Patient list */}
      {patientList.length === 0 ? (
        <EmptyState
          icon="people-outline"
          title="Aucun patient"
          description={
            search
              ? 'Aucun patient ne correspond à votre recherche.'
              : 'Commencez par ajouter votre premier patient.'
          }
          actionLabel={search ? 'Effacer la recherche' : 'Ajouter un patient'}
          onAction={search ? () => setSearch('') : handleCreatePatient}
        />
      ) : (
        <FlatList
          data={patientList}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderPatient}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              colors={[colors.primary]}
              tintColor={colors.primary}
              refreshing={isRefetching || isDeleting}
              onRefresh={refetch}
            />
          }
          removeClippedSubviews={true}
          maxToRenderPerBatch={10}
          windowSize={10}
          initialNumToRender={10}
        />
      )}
    </ScreenContainer>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  headerContainer: {
    paddingHorizontal: spacing.lg,
  },
  header: {
    marginBottom: spacing.md,
    paddingTop: spacing.sm,
  },
  searchContainer: {
    marginBottom: spacing.md,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  skeletonList: {
    paddingTop: spacing.md,
  },
});
