// src/screens/chat/ChatScreen.tsx
import React, { useCallback, useRef, useEffect } from 'react'
import {
  View,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { useRoute, useNavigation } from '@react-navigation/native'
import type { RouteProp } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'
import Screen from '../../components/layout/Screen'
import AppText from '../../components/ui/AppText'
import LoadingState from '../../components/feedback/LoadingState'
import ErrorState from '../../components/feedback/ErrorState'
import { MessageBubble, ChatInput, TypingIndicator } from '../../components/chat'
import { useTheme } from '../../theme/ThemeProvider'
import { useAuthStore } from '../../stores/authStore'
import {
  useMessagesQuery,
  useSendMessageMutation,
  useMarkConversationReadMutation,
  useTypingIndicator,
  useConversationSubscription,
} from '../../features/chat/hooks'
import type { ChatMessage } from '../../features/chat/types'
import type { ChatStackParamList } from '../../navigation/types'

type ChatScreenRouteProp = RouteProp<ChatStackParamList, 'ChatScreen'>
type Nav = NativeStackNavigationProp<ChatStackParamList, 'ChatScreen'>

export default function ChatScreen() {
  const route = useRoute<ChatScreenRouteProp>()
  const navigation = useNavigation<Nav>()
  const { colors } = useTheme()
  const { conversationId, participantName, participantId } = route.params

  const currentUserId = useAuthStore((state) => state.user?.id)
  const flatListRef = useRef<FlatList<ChatMessage>>(null)

  // Queries and mutations
  const { data, isLoading, error, refetch } = useMessagesQuery(conversationId)
  const sendMessageMutation = useSendMessageMutation(conversationId)
  const markReadMutation = useMarkConversationReadMutation()

  // Real-time features
  useConversationSubscription(conversationId)
  const { typingUsers, sendTypingStart, sendTypingStop } = useTypingIndicator(conversationId)

  // Set navigation header title
  useEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerTitle: participantName || 'Chat',
      headerBackTitle: 'Retour',
    })
  }, [navigation, participantName])

  // Mark conversation as read when opened
  useEffect(() => {
    markReadMutation.mutate(conversationId)
  }, [conversationId])

  // Scroll to bottom on new messages
  useEffect(() => {
    if (data && data.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true })
      }, 100)
    }
  }, [data?.length])

  const handleSend = useCallback(
    (content: string) => {
      sendMessageMutation.mutate({
        receiverId: participantId,
        content,
      })
    },
    [sendMessageMutation, participantId]
  )

  const renderMessage = useCallback(
    ({ item }: { item: ChatMessage }) => (
      <MessageBubble
        message={item}
        isOwnMessage={item.senderId === currentUserId}
      />
    ),
    [currentUserId]
  )

  const isOtherTyping = typingUsers.length > 0 && !typingUsers.includes(currentUserId ?? 0)

  if (isLoading) {
    return (
      <Screen>
        <LoadingState message="Chargement des messages..." />
      </Screen>
    )
  }

  if (error) {
    return (
      <Screen>
        <ErrorState
          message="Impossible de charger les messages."
          onRetry={refetch}
        />
      </Screen>
    )
  }

  const messages = data ?? []

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <View style={styles.messagesContainer}>
        {messages.length === 0 ? (
          <View style={styles.emptyContainer}>
            <AppText style={[styles.emptyText, { color: colors.muted }]}>
              Commencez la conversation avec {participantName}
            </AppText>
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderMessage}
            contentContainerStyle={styles.listContent}
            onContentSizeChange={() =>
              flatListRef.current?.scrollToEnd({ animated: false })
            }
          />
        )}

        <TypingIndicator isVisible={isOtherTyping} />
      </View>

      <ChatInput
        onSend={handleSend}
        onTypingStart={sendTypingStart}
        onTypingStop={sendTypingStop}
        isSending={sendMessageMutation.isPending}
        placeholder="Votre message..."
      />
    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  messagesContainer: {
    flex: 1,
  },
  listContent: {
    paddingVertical: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  emptyText: {
    fontSize: 15,
    textAlign: 'center',
  },
})
