/**
 * ConversationsListScreen
 *
 * List of chat conversations.
 * Redesigned with MediSync design system.
 */

import React, { useCallback } from 'react';
import { FlatList, RefreshControl, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  ScreenContainer,
  Text,
  EmptyState,
  SkeletonListItem,
  Stack,
  spacing,
  useTheme,
} from '../../ui';
import { ConversationRow } from '../../components/chat';
import {
  useConversationsQuery,
  useChatSocket,
} from '../../features/chat/hooks';
import type { Conversation } from '../../features/chat/types';
import type { ChatStackParamList } from '../../navigation/types';

// =============================================================================
// TYPES
// =============================================================================

type Nav = NativeStackNavigationProp<ChatStackParamList, 'ConversationsList'>;

// =============================================================================
// COMPONENT
// =============================================================================

export default function ConversationsListScreen() {
  const { colors } = useTheme();
  const navigation = useNavigation<Nav>();
  const { data, isLoading, error, refetch, isRefetching } =
    useConversationsQuery();

  // Initialize WebSocket connection
  useChatSocket();

  const conversations = data ?? [];

  const handlePressConversation = useCallback(
    (item: Conversation) => {
      navigation.navigate('ChatScreen', {
        conversationId: item.id,
        participantName:
          `${item.participant.firstName} ${item.participant.lastName}`.trim(),
        participantId: item.participant.id,
      });
    },
    [navigation]
  );

  const renderItem = useCallback(
    ({ item }: { item: Conversation }) => (
      <ConversationRow
        conversation={item}
      />
    ),
    []
  );

  // Loading state
  if (isLoading) {
    return (
      <ScreenContainer>
        <Text variant="h2" style={styles.title}>
          Messages
        </Text>
        <Stack gap="sm">
          {[1, 2, 3, 4, 5].map((i) => (
            <SkeletonListItem key={i} />
          ))}
        </Stack>
      </ScreenContainer>
    );
  }

  // Error state
  if (error) {
    return (
      <ScreenContainer centerContent>
        <EmptyState
          icon="chatbubbles-outline"
          title="Erreur de chargement"
          description="Impossible de charger les conversations. Vérifiez votre connexion."
          actionLabel="Réessayer"
          onAction={refetch}
        />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer noPadding>
      <Text variant="h2" style={styles.title}>
        Messages
      </Text>

      {conversations.length === 0 ? (
        <EmptyState
          icon="chatbubble-ellipses-outline"
          title="Aucune conversation"
          description="Vos conversations avec l'équipe médicale apparaîtront ici."
        />
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ConversationRow
              conversation={item}
              onPress={() => handlePressConversation(item)}
            />
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              colors={[colors.primary]}
              tintColor={colors.primary}
              refreshing={isRefetching}
              onRefresh={refetch}
            />
          }
          ItemSeparatorComponent={() => null}
        />
      )}
    </ScreenContainer>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  title: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
    paddingTop: spacing.sm,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxl,
  },
});
