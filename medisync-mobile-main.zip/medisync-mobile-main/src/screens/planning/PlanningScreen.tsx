/**
 * PlanningScreen
 *
 * Redesigned calendar view with improved UX for medical professionals.
 * Features:
 * - Clean header with current date and quick add button
 * - Monthly calendar with appointment markers
 * - "View Tour" button for each day with appointments
 * - Smart "Today" section showing current or next scheduled day
 * - Modern appointment creation modal
 */

import React, { useMemo, useState, useCallback } from 'react';
import {
  ScrollView,
  RefreshControl,
  StyleSheet,
  View,
  Alert,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

import {
  ScreenContainer,
  Row,
  Stack,
  Text,
  Button,
  Card,
  Badge,
  EmptyState,
  SkeletonCard,
  Divider,
  spacing,
  radius,
  useTheme,
} from '../../ui';
import MonthCalendar from '../../components/planning/MonthCalendar';
import AppointmentCreateModal from '../../components/planning/AppointmentCreateModal';
import DayTourModal from '../../components/planning/DayTourModal';
import {
  useAppointmentsQuery,
  useCreateAppointmentMutation,
  useDeleteAppointmentMutation,
} from '../../features/appointments/hooks';
import type { Appointment } from '../../features/appointments/types';

// =============================================================================
// HELPERS
// =============================================================================

function formatTime(iso: string): string {
  if (!iso) return '';
  const timePart = iso.split('T')[1] ?? '';
  const [hh, mm] = timePart.split(':');
  if (!hh || !mm) return '';
  return `${hh}:${mm}`;
}

function formatDateDisplay(dateStr: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  return date.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });
}

function formatDateShort(dateStr: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  return date.toLocaleDateString('fr-FR', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
}

function getRelativeDateLabel(dateStr: string): string | null {
  const date = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  if (date.getTime() === today.getTime()) {
    return "Aujourd'hui";
  }
  if (date.getTime() === tomorrow.getTime()) {
    return 'Demain';
  }
  return null;
}

type AppointmentStatus = 'upcoming' | 'ongoing' | 'completed';

function getAppointmentStatus(
  startDate: string,
  endDate: string
): AppointmentStatus {
  const now = new Date();
  const start = startDate ? new Date(startDate) : now;
  const end = endDate ? new Date(endDate) : now;

  if (end < now) return 'completed';
  if (start <= now && end >= now) return 'ongoing';
  return 'upcoming';
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function PlanningScreen() {
  const { colors } = useTheme();
  const navigation = useNavigation();

  const today = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(today);
  const [currentMonth, setCurrentMonth] = useState<string>(today);
  const [isCreateModalVisible, setCreateModalVisible] = useState(false);
  const [isTourModalVisible, setTourModalVisible] = useState(false);
  const [tourDate, setTourDate] = useState<string>(today);

  // Data fetching
  const {
    data: sections,
    isLoading,
    error,
    refetch,
    isRefetching,
  } = useAppointmentsQuery({
    sortBy: 'startDate',
    sortOrder: 'ASC',
    limit: 200,
  });

  const { mutate: createAppointment, isPending: isCreating } =
    useCreateAppointmentMutation();
  const { mutate: deleteAppointment, isPending: isDeleting } =
    useDeleteAppointmentMutation();

  // Computed data
  const flatAppointments: Appointment[] = useMemo(
    () => (sections ?? []).flatMap((s) => s.appointments),
    [sections]
  );

  // Appointments for selected date
  const selectedDateAppointments = useMemo(() => {
    return flatAppointments
      .filter((a) => a.startDate.split('T')[0] === selectedDate)
      .sort(
        (a, b) =>
          new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
      );
  }, [flatAppointments, selectedDate]);

  // Today's appointments
  const todayAppointments = useMemo(() => {
    return flatAppointments
      .filter((a) => a.startDate.split('T')[0] === today)
      .sort(
        (a, b) =>
          new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
      );
  }, [flatAppointments, today]);

  // Next scheduled day (if no appointments today)
  const nextScheduledDay = useMemo(() => {
    if (todayAppointments.length > 0) return null;

    const todayDate = new Date(today);
    const futureSections = (sections ?? [])
      .filter((s) => new Date(s.date) > todayDate)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    if (futureSections.length === 0) return null;

    const nextSection = futureSections[0];
    return {
      date: nextSection.date,
      appointments: nextSection.appointments.sort(
        (a, b) =>
          new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
      ),
    };
  }, [sections, today, todayAppointments]);

  // Marked dates for calendar
  const markedDates = useMemo(() => {
    const marks: Record<
      string,
      { marked?: boolean; dotColor?: string; appointmentCount?: number }
    > = {};
    flatAppointments.forEach((appt) => {
      const dateKey = appt.startDate.split('T')[0];
      if (!marks[dateKey]) {
        marks[dateKey] = { marked: true, appointmentCount: 0 };
      }
      marks[dateKey].appointmentCount =
        (marks[dateKey].appointmentCount ?? 0) + 1;
    });
    return marks;
  }, [flatAppointments]);

  // Get current date display
  const currentDateDisplay = useMemo(() => {
    const now = new Date();
    return now.toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  }, []);

  // Handlers
  const handleDayPress = useCallback((dateString: string) => {
    setSelectedDate(dateString);
  }, []);

  const handleMonthChange = useCallback((year: number, month: number) => {
    const mm = month.toString().padStart(2, '0');
    setCurrentMonth(`${year}-${mm}-01`);
  }, []);

  const handleCreate = useCallback(
    (dto: { patientId: number; startDate: string; endDate: string }) => {
      createAppointment(dto, {
        onSuccess: () => {
          setCreateModalVisible(false);
          refetch();
        },
      });
    },
    [createAppointment, refetch]
  );

  const handleAppointmentLongPress = useCallback(
    (appointment: Appointment) => {
      Alert.alert(
        'Supprimer le rendez-vous',
        `Voulez-vous vraiment supprimer le rendez-vous de ${
          appointment.patientName ?? `patient #${appointment.patientId}`
        } ?`,
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Supprimer',
            style: 'destructive',
            onPress: () =>
              deleteAppointment(appointment.id, {
                onSuccess: () => refetch(),
              }),
          },
        ]
      );
    },
    [deleteAppointment, refetch]
  );

  const handleViewTour = useCallback((date: string) => {
    setTourDate(date);
    setTourModalVisible(true);
  }, []);

  const handleNavigateToCreatePatient = useCallback(() => {
    setCreateModalVisible(false);
    // Navigate to patient creation screen
    (navigation as any).navigate('Dossier', {
      screen: 'PatientDetail',
      params: { patientId: undefined },
    });
  }, [navigation]);

  // Loading state
  if (isLoading) {
    return (
      <ScreenContainer>
        <View style={styles.header}>
          <Text variant="h2">Calendrier</Text>
          <Text variant="bodySmall" color="secondary" style={{ marginTop: spacing.xxs }}>
            Chargement...
          </Text>
        </View>
        <SkeletonCard height={320} style={styles.calendarSkeleton} />
        <Stack gap="sm" style={styles.appointmentsSkeleton}>
          <SkeletonCard height={80} />
          <SkeletonCard height={80} />
        </Stack>
      </ScreenContainer>
    );
  }

  // Error state
  if (error) {
    return (
      <ScreenContainer centerContent>
        <EmptyState
          icon="calendar-outline"
          title="Erreur de chargement"
          description="Impossible de charger le planning. Vérifiez votre connexion."
          actionLabel="Réessayer"
          onAction={refetch}
        />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer noPadding>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface }]}>
        <View style={styles.headerLeft}>
          <Text variant="h2">Calendrier</Text>
          <Text
            variant="bodySmall"
            color="secondary"
            style={{ textTransform: 'capitalize', marginTop: spacing.xxs }}
          >
            {currentDateDisplay}
          </Text>
        </View>
        <Button
          label="+ Rendez-vous"
          onPress={() => setCreateModalVisible(true)}
          size="sm"
        />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            colors={[colors.primary]}
            tintColor={colors.primary}
            refreshing={isRefetching || isCreating || isDeleting}
            onRefresh={refetch}
          />
        }
      >
        {/* Calendar */}
        <View style={styles.calendarContainer}>
          <MonthCalendar
            current={currentMonth}
            selectedDate={selectedDate}
            markedDates={markedDates}
            onDayPress={handleDayPress}
            onMonthChange={handleMonthChange}
          />
        </View>

        {/* Selected Date Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View>
              <Text variant="h4" style={{ textTransform: 'capitalize' }}>
                {getRelativeDateLabel(selectedDate) ??
                  formatDateDisplay(selectedDate)}
              </Text>
              <Text variant="caption" color="secondary">
                {selectedDateAppointments.length} rendez-vous
              </Text>
            </View>
            {selectedDateAppointments.length > 0 && (
              <Button
                label="Voir la tournée"
                variant="outline"
                size="sm"
                onPress={() => handleViewTour(selectedDate)}
                iconRight={
                  <Ionicons
                    name="arrow-forward"
                    size={16}
                    color={colors.primary}
                  />
                }
              />
            )}
          </View>

          {/* Selected Date Appointments */}
          {selectedDateAppointments.length === 0 ? (
            <Card
              variant="filled"
              padding="lg"
              style={[
                styles.emptyCard,
                { backgroundColor: colors.backgroundTertiary },
              ]}
            >
              <Ionicons
                name="calendar-clear-outline"
                size={32}
                color={colors.textTertiary}
              />
              <Text
                variant="body"
                color="secondary"
                style={{ marginTop: spacing.sm, textAlign: 'center' }}
              >
                Aucun rendez-vous ce jour
              </Text>
              <Button
                label="Planifier une visite"
                variant="outline"
                size="sm"
                onPress={() => setCreateModalVisible(true)}
                style={{ marginTop: spacing.md }}
              />
            </Card>
          ) : (
            <Stack gap="sm">
              {selectedDateAppointments.map((appt) => (
                <AppointmentCard
                  key={appt.id}
                  appointment={appt}
                  onLongPress={() => handleAppointmentLongPress(appt)}
                  colors={colors}
                />
              ))}
            </Stack>
          )}
        </View>

        {/* Today Section (or Next Scheduled Day) */}
        <View style={styles.section}>
          <Divider spacing="md" />

          {todayAppointments.length > 0 ? (
            <>
              <View style={styles.sectionHeader}>
                <View style={styles.sectionTitleRow}>
                  <View
                    style={[
                      styles.todayBadge,
                      { backgroundColor: colors.primaryMuted },
                    ]}
                  >
                    <Ionicons
                      name="today-outline"
                      size={16}
                      color={colors.primary}
                    />
                  </View>
                  <View>
                    <Text variant="h4">Aujourd'hui</Text>
                    <Text variant="caption" color="secondary">
                      {todayAppointments.length} visite
                      {todayAppointments.length > 1 ? 's' : ''} prévue
                      {todayAppointments.length > 1 ? 's' : ''}
                    </Text>
                  </View>
                </View>
                <Button
                  label="Ma tournée"
                  variant="primary"
                  size="sm"
                  onPress={() => handleViewTour(today)}
                  iconLeft={
                    <Ionicons name="map-outline" size={16} color="#fff" />
                  }
                />
              </View>

              <Stack gap="xs">
                {todayAppointments.slice(0, 3).map((appt, index) => (
                  <TodayAppointmentRow
                    key={appt.id}
                    appointment={appt}
                    index={index + 1}
                    colors={colors}
                  />
                ))}
                {todayAppointments.length > 3 && (
                  <TouchableOpacity
                    onPress={() => handleViewTour(today)}
                    style={[
                      styles.moreButton,
                      { backgroundColor: colors.backgroundTertiary },
                    ]}
                  >
                    <Text variant="labelSmall" color="secondary">
                      + {todayAppointments.length - 3} autre
                      {todayAppointments.length - 3 > 1 ? 's' : ''}
                    </Text>
                    <Ionicons
                      name="chevron-forward"
                      size={14}
                      color={colors.textSecondary}
                    />
                  </TouchableOpacity>
                )}
              </Stack>
            </>
          ) : nextScheduledDay ? (
            <>
              <View style={styles.sectionHeader}>
                <View style={styles.sectionTitleRow}>
                  <View
                    style={[
                      styles.todayBadge,
                      { backgroundColor: colors.warningMuted },
                    ]}
                  >
                    <Ionicons
                      name="calendar-outline"
                      size={16}
                      color={colors.warning}
                    />
                  </View>
                  <View>
                    <Text variant="body" color="secondary">
                      Prochain jour planifié
                    </Text>
                    <Text variant="h4" style={{ textTransform: 'capitalize' }}>
                      {getRelativeDateLabel(nextScheduledDay.date) ??
                        formatDateShort(nextScheduledDay.date)}
                    </Text>
                  </View>
                </View>
                <Button
                  label="Voir"
                  variant="outline"
                  size="sm"
                  onPress={() => handleViewTour(nextScheduledDay.date)}
                />
              </View>

              <Stack gap="xs">
                {nextScheduledDay.appointments.slice(0, 3).map((appt, index) => (
                  <TodayAppointmentRow
                    key={appt.id}
                    appointment={appt}
                    index={index + 1}
                    colors={colors}
                  />
                ))}
                {nextScheduledDay.appointments.length > 3 && (
                  <TouchableOpacity
                    onPress={() => handleViewTour(nextScheduledDay.date)}
                    style={[
                      styles.moreButton,
                      { backgroundColor: colors.backgroundTertiary },
                    ]}
                  >
                    <Text variant="labelSmall" color="secondary">
                      + {nextScheduledDay.appointments.length - 3} autre
                      {nextScheduledDay.appointments.length - 3 > 1 ? 's' : ''}
                    </Text>
                    <Ionicons
                      name="chevron-forward"
                      size={14}
                      color={colors.textSecondary}
                    />
                  </TouchableOpacity>
                )}
              </Stack>
            </>
          ) : (
            <Card
              variant="filled"
              padding="lg"
              style={[
                styles.emptyCard,
                { backgroundColor: colors.backgroundTertiary },
              ]}
            >
              <Ionicons
                name="checkmark-circle-outline"
                size={32}
                color={colors.success}
              />
              <Text
                variant="body"
                color="secondary"
                style={{ marginTop: spacing.sm, textAlign: 'center' }}
              >
                Aucun rendez-vous prévu
              </Text>
              <Text
                variant="caption"
                color="tertiary"
                style={{ marginTop: spacing.xs, textAlign: 'center' }}
              >
                Votre agenda est libre. Planifiez vos prochaines visites.
              </Text>
            </Card>
          )}
        </View>
      </ScrollView>

      {/* Create Appointment Modal */}
      <AppointmentCreateModal
        visible={isCreateModalVisible}
        date={selectedDate}
        onClose={() => setCreateModalVisible(false)}
        onSubmit={handleCreate}
        onNavigateToCreatePatient={handleNavigateToCreatePatient}
      />

      {/* Day Tour Modal */}
      <DayTourModal
        visible={isTourModalVisible}
        date={tourDate}
        appointments={flatAppointments.filter(
          (a) => a.startDate.split('T')[0] === tourDate
        )}
        onClose={() => setTourModalVisible(false)}
        onAppointmentLongPress={handleAppointmentLongPress}
      />
    </ScreenContainer>
  );
}

// =============================================================================
// SUB-COMPONENTS
// =============================================================================

interface AppointmentCardProps {
  appointment: Appointment;
  onLongPress: () => void;
  colors: ReturnType<typeof useTheme>['colors'];
}

function AppointmentCard({
  appointment,
  onLongPress,
  colors,
}: AppointmentCardProps) {
  const timeStart = formatTime(appointment.startDate);
  const timeEnd = formatTime(appointment.endDate);
  const patientName =
    appointment.patientName ?? `Patient #${appointment.patientId}`;
  const status = getAppointmentStatus(
    appointment.startDate,
    appointment.endDate
  );

  const statusConfig = {
    upcoming: { label: 'À venir', variant: 'primary' as const },
    ongoing: { label: 'En cours', variant: 'warning' as const },
    completed: { label: 'Terminé', variant: 'success' as const },
  };

  return (
    <Card variant="outlined" padding="md" onLongPress={onLongPress}>
      <Row gap="md" align="center">
        {/* Time Block */}
        <View
          style={[styles.timeBlock, { backgroundColor: colors.primaryMuted }]}
        >
          <Text
            variant="labelSmall"
            style={{ color: colors.primary, textAlign: 'center' }}
          >
            {timeStart}
          </Text>
          <Text
            variant="caption"
            color="tertiary"
            style={{ textAlign: 'center' }}
          >
            {timeEnd}
          </Text>
        </View>

        {/* Patient Info */}
        <View style={styles.appointmentContent}>
          <Text variant="label" numberOfLines={1}>
            {patientName}
          </Text>
          <Text variant="caption" color="tertiary">
            {timeStart} - {timeEnd}
          </Text>
        </View>

        {/* Status Badge */}
        <Badge
          label={statusConfig[status].label}
          variant={statusConfig[status].variant}
          size="sm"
        />
      </Row>
    </Card>
  );
}

interface TodayAppointmentRowProps {
  appointment: Appointment;
  index: number;
  colors: ReturnType<typeof useTheme>['colors'];
}

function TodayAppointmentRow({
  appointment,
  index,
  colors,
}: TodayAppointmentRowProps) {
  const timeStart = formatTime(appointment.startDate);
  const patientName =
    appointment.patientName ?? `Patient #${appointment.patientId}`;
  const status = getAppointmentStatus(
    appointment.startDate,
    appointment.endDate
  );

  const getStatusColor = () => {
    switch (status) {
      case 'completed':
        return colors.success;
      case 'ongoing':
        return colors.warning;
      default:
        return colors.primary;
    }
  };

  return (
    <View
      style={[styles.todayRow, { backgroundColor: colors.surface }]}
    >
      <View style={[styles.todayIndex, { backgroundColor: getStatusColor() }]}>
        {status === 'completed' ? (
          <Ionicons name="checkmark" size={12} color="#fff" />
        ) : (
          <Text variant="labelSmall" style={{ color: '#fff' }}>
            {index}
          </Text>
        )}
      </View>
      <Text variant="labelSmall" style={styles.todayTime}>
        {timeStart}
      </Text>
      <Text variant="body" numberOfLines={1} style={{ flex: 1 }}>
        {patientName}
      </Text>
    </View>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
  },
  headerLeft: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: spacing.xxxl,
  },
  calendarContainer: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  calendarSkeleton: {
    marginHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  appointmentsSkeleton: {
    paddingHorizontal: spacing.lg,
  },
  section: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  todayBadge: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyCard: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xl,
  },
  timeBlock: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.sm,
    minWidth: 54,
  },
  appointmentContent: {
    flex: 1,
  },
  todayRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.sm,
    gap: spacing.sm,
  },
  todayIndex: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  todayTime: {
    width: 50,
  },
  moreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    borderRadius: radius.sm,
    gap: spacing.xs,
  },
});
