import React from 'react'
import { View, StyleSheet, Switch } from 'react-native'
import Screen from '../../components/layout/Screen'
import AppText from '../../components/ui/AppText'
import SettingsRow from '../../components/settings/SettingsRow'
import { useTheme } from '../../theme/ThemeProvider'

export default function SettingsScreen() {
  const { themeName, toggleTheme, colors } = useTheme()

  const isDark = themeName === 'dark'

  return (
    <Screen>
      <AppText style={[styles.title, { color: colors.text }]}>
        Paramètres
      </AppText>

      <AppText style={[styles.sectionTitle, { color: colors.muted }]}>
        Apparence
      </AppText>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <SettingsRow
          label="Mode sombre"
          description="Active le thème sombre pour l'application"
          rightElement={
            <Switch
              value={isDark}
              onValueChange={toggleTheme}
              thumbColor={isDark ? colors.primary : '#f4f3f4'}
              trackColor={{ false: '#767577', true: colors.primary }}
            />
          }
        />
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 14,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 8,
  },
  card: {
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderWidth: 1,
  },
})
