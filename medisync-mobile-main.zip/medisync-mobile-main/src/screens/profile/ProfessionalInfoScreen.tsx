/**
 * ProfessionalInfoScreen - Edit professional information
 *
 * Allows user to update: rppsNumber, specialization, cabinetName, cabinetAddress
 */

import React, { useState, useEffect } from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Input,
  Button,
  Card,
  spacing,
  useTheme,
} from '../../ui'
import { useUserProfile, useUpdateProfile } from '../../features/user'
import type { UpdateProfessionalInfoDto } from '../../features/user'

// Common nurse specializations in France
const SPECIALIZATIONS = [
  'Soins généraux',
  'Pédiatrie',
  'Gériatrie',
  'Psychiatrie',
  'Oncologie',
  'Soins intensifs',
  'Bloc opératoire',
  'Urgences',
  'Dialyse',
  'Cardiologie',
  'Stomathérapie',
  'Plaies et cicatrisation',
  'Soins palliatifs',
  'Autre',
]

export default function ProfessionalInfoScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()
  const { data: profile, isLoading: isLoadingProfile } = useUserProfile()
  const updateProfile = useUpdateProfile()

  // Form state
  const [rppsNumber, setRppsNumber] = useState('')
  const [specialization, setSpecialization] = useState('')
  const [cabinetName, setCabinetName] = useState('')
  const [cabinetAddress, setCabinetAddress] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [showSpecialization, setShowSpecialization] = useState(false)

  // Initialize form with profile data
  useEffect(() => {
    if (profile) {
      setRppsNumber(profile.rppsNumber || '')
      setSpecialization(profile.specialization || '')
      setCabinetName(profile.cabinetName || '')
      setCabinetAddress(profile.cabinetAddress || '')
    }
  }, [profile])

  // Check if form has changes
  const hasChanges =
    profile &&
    (rppsNumber !== (profile.rppsNumber || '') ||
      specialization !== (profile.specialization || '') ||
      cabinetName !== (profile.cabinetName || '') ||
      cabinetAddress !== (profile.cabinetAddress || ''))

  // Validate RPPS number (11 digits)
  const validateRpps = (value: string): boolean => {
    if (!value) return true // Optional field
    return /^\d{11}$/.test(value)
  }

  // Validate form
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (rppsNumber && !validateRpps(rppsNumber)) {
      newErrors.rppsNumber = 'Le numéro RPPS doit contenir exactement 11 chiffres'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Handle save
  const handleSave = async () => {
    if (!validate()) return

    const data: UpdateProfessionalInfoDto = {
      rppsNumber: rppsNumber.trim() || undefined,
      specialization: specialization.trim() || undefined,
      cabinetName: cabinetName.trim() || undefined,
      cabinetAddress: cabinetAddress.trim() || undefined,
    }

    try {
      await updateProfile.mutateAsync(data)
      Alert.alert('Succès', 'Vos informations ont été mises à jour', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ])
    } catch (error) {
      Alert.alert(
        'Erreur',
        error instanceof Error
          ? error.message
          : 'Impossible de mettre à jour vos informations'
      )
    }
  }

  // Handle back with unsaved changes
  const handleBack = () => {
    if (hasChanges) {
      Alert.alert(
        'Modifications non sauvegardées',
        'Voulez-vous quitter sans sauvegarder ?',
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Quitter',
            style: 'destructive',
            onPress: () => navigation.goBack(),
          },
        ]
      )
    } else {
      navigation.goBack()
    }
  }

  // Handle specialization selection
  const handleSelectSpecialization = () => {
    Alert.alert(
      'Spécialité',
      'Choisissez votre spécialité',
      [
        ...SPECIALIZATIONS.map((spec) => ({
          text: spec,
          onPress: () => setSpecialization(spec),
        })),
        { text: 'Annuler', style: 'cancel' },
      ],
      { cancelable: true }
    )
  }

  if (isLoadingProfile) {
    return (
      <ScreenContainer>
        <View style={styles.loadingContainer}>
          <Text>Chargement...</Text>
        </View>
      </ScreenContainer>
    )
  }

  return (
    <ScreenContainer noPadding>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text variant="h3" style={styles.headerTitle}>
            Informations professionnelles
          </Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView
          style={styles.flex}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingBottom: insets.bottom + 100 },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Card variant="outlined" padding="lg">
            <Input
              label="Numéro RPPS"
              placeholder="12345678901"
              value={rppsNumber}
              onChangeText={setRppsNumber}
              error={errors.rppsNumber}
              keyboardType="numeric"
              maxLength={11}
              helper="Répertoire Partagé des Professionnels de Santé"
              containerStyle={styles.inputContainer}
            />

            {/* Specialization as a touchable input */}
            <View style={styles.inputContainer}>
              <Text
                variant="label"
                style={[styles.inputLabel, { color: colors.text }]}
              >
                Spécialité
              </Text>
              <TouchableOpacity
                style={[
                  styles.selectButton,
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.border,
                  },
                ]}
                onPress={handleSelectSpecialization}
              >
                <Text
                  style={{
                    color: specialization ? colors.text : colors.textTertiary,
                  }}
                >
                  {specialization || 'Sélectionnez votre spécialité'}
                </Text>
                <Ionicons
                  name="chevron-down"
                  size={20}
                  color={colors.textTertiary}
                />
              </TouchableOpacity>
            </View>

            <Input
              label="Nom du cabinet"
              placeholder="Cabinet infirmier..."
              value={cabinetName}
              onChangeText={setCabinetName}
              autoCapitalize="words"
              containerStyle={styles.inputContainer}
            />

            <Input
              label="Adresse du cabinet"
              placeholder="Adresse complète du cabinet"
              value={cabinetAddress}
              onChangeText={setCabinetAddress}
              multiline
              numberOfLines={3}
              containerStyle={styles.inputContainer}
            />
          </Card>

          {/* Info card about RPPS */}
          <Card
            variant="filled"
            padding="md"
            style={[styles.infoCard, { backgroundColor: colors.primaryMuted }]}
          >
            <View style={styles.infoCardContent}>
              <Ionicons
                name="information-circle"
                size={24}
                color={colors.primary}
              />
              <Text
                variant="bodySmall"
                style={[styles.infoText, { color: colors.text }]}
              >
                Le numéro RPPS est votre identifiant unique en tant que
                professionnel de santé. Il permet de certifier votre statut
                auprès des organismes de santé.
              </Text>
            </View>
          </Card>

          <View style={styles.buttonContainer}>
            <Button
              title="Enregistrer"
              onPress={handleSave}
              loading={updateProfile.isPending}
              disabled={!hasChanges || updateProfile.isPending}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  inputContainer: {
    marginBottom: spacing.md,
  },
  inputLabel: {
    marginBottom: spacing.xs,
  },
  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderWidth: 1,
    borderRadius: 8,
    minHeight: 48,
  },
  infoCard: {
    marginTop: spacing.md,
  },
  infoCardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  infoText: {
    flex: 1,
  },
  buttonContainer: {
    marginTop: spacing.lg,
  },
})
