/**
 * HelpCenterScreen - FAQ and help articles
 *
 * Static FAQ content with expandable sections
 */

import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Card,
  spacing,
  radius,
  useTheme,
} from '../../ui'

// FAQ data structure
interface FAQItem {
  question: string
  answer: string
}

interface FAQSection {
  title: string
  icon: keyof typeof Ionicons.glyphMap
  items: FAQItem[]
}

// Static FAQ content
const FAQ_SECTIONS: FAQSection[] = [
  {
    title: 'Prise en main',
    icon: 'rocket-outline',
    items: [
      {
        question: 'Comment créer mon compte ?',
        answer:
          'Pour créer votre compte MediSync, téléchargez l\'application depuis l\'App Store ou Google Play, puis appuyez sur "Créer un compte". Vous devrez fournir votre numéro RPPS pour vérifier votre statut de professionnel de santé.',
      },
      {
        question: 'Comment ajouter un patient ?',
        answer:
          'Accédez à l\'onglet "Dossier" depuis la barre de navigation, puis appuyez sur le bouton "+" en haut à droite. Remplissez les informations du patient et validez.',
      },
      {
        question: 'Comment planifier une visite ?',
        answer:
          'Dans l\'onglet "Planning", appuyez sur une date pour voir les créneaux disponibles. Sélectionnez un créneau et choisissez le patient concerné. Vous pouvez également ajouter des notes pour cette visite.',
      },
    ],
  },
  {
    title: 'Gestion des patients',
    icon: 'people-outline',
    items: [
      {
        question: 'Comment modifier les informations d\'un patient ?',
        answer:
          'Ouvrez le dossier du patient depuis l\'onglet "Dossier", puis appuyez sur le bouton "Modifier" en haut de l\'écran. Effectuez vos modifications et sauvegardez.',
      },
      {
        question: 'Comment ajouter des documents au dossier patient ?',
        answer:
          'Dans le dossier du patient, accédez à la section "Documents". Appuyez sur "Ajouter un document" pour scanner ou importer un fichier depuis votre appareil.',
      },
      {
        question: 'Comment partager un dossier avec un confrère ?',
        answer:
          'Cette fonctionnalité sera bientôt disponible. Elle permettra de partager de manière sécurisée les informations patient avec d\'autres professionnels de santé autorisés.',
      },
    ],
  },
  {
    title: 'Messagerie',
    icon: 'chatbubbles-outline',
    items: [
      {
        question: 'Comment contacter un autre professionnel ?',
        answer:
          'Accédez à l\'onglet "Messagerie" et appuyez sur l\'icône de nouvelle conversation. Recherchez le professionnel par son nom ou son numéro RPPS.',
      },
      {
        question: 'Les messages sont-ils sécurisés ?',
        answer:
          'Oui, tous les messages échangés sur MediSync sont chiffrés de bout en bout. Vos communications restent confidentielles et conformes aux exigences RGPD et HDS.',
      },
    ],
  },
  {
    title: 'Paramètres et compte',
    icon: 'settings-outline',
    items: [
      {
        question: 'Comment modifier mes disponibilités ?',
        answer:
          'Accédez à votre profil, puis "Disponibilités". Vous pouvez définir vos horaires de travail pour chaque jour de la semaine.',
      },
      {
        question: 'Comment activer les notifications ?',
        answer:
          'Dans votre profil, section "Notifications", activez les types de notifications souhaitées : rendez-vous, messages, rappels et mises à jour.',
      },
      {
        question: 'Comment supprimer mon compte ?',
        answer:
          'Pour supprimer votre compte, contactez le support via l\'application. Nous traiterons votre demande conformément aux réglementations en vigueur.',
      },
    ],
  },
]

// FAQ Item component
function FAQItemComponent({ item }: { item: FAQItem }) {
  const { colors } = useTheme()
  const [expanded, setExpanded] = useState(false)

  return (
    <TouchableOpacity
      style={[styles.faqItem, { borderBottomColor: colors.border }]}
      onPress={() => setExpanded(!expanded)}
      activeOpacity={0.7}
    >
      <View style={styles.faqQuestion}>
        <Text variant="body" style={styles.questionText}>
          {item.question}
        </Text>
        <Ionicons
          name={expanded ? 'chevron-up' : 'chevron-down'}
          size={20}
          color={colors.textSecondary}
        />
      </View>
      {expanded && (
        <Text variant="bodySmall" color="secondary" style={styles.answerText}>
          {item.answer}
        </Text>
      )}
    </TouchableOpacity>
  )
}

// FAQ Section component
function FAQSectionComponent({ section }: { section: FAQSection }) {
  const { colors } = useTheme()

  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <View
          style={[styles.iconContainer, { backgroundColor: colors.primaryMuted }]}
        >
          <Ionicons name={section.icon} size={20} color={colors.primary} />
        </View>
        <Text variant="h4">{section.title}</Text>
      </View>
      <Card variant="outlined" padding="none">
        {section.items.map((item, index) => (
          <FAQItemComponent key={index} item={item} />
        ))}
      </Card>
    </View>
  )
}

export default function HelpCenterScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()

  return (
    <ScreenContainer noPadding>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text variant="h3" style={styles.headerTitle}>
          Centre d'aide
        </Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        style={styles.flex}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Search hint */}
        <Card
          variant="filled"
          padding="md"
          style={[styles.searchHint, { backgroundColor: colors.primaryMuted }]}
        >
          <View style={styles.searchHintContent}>
            <Ionicons name="search" size={20} color={colors.primary} />
            <Text variant="bodySmall" style={{ flex: 1, color: colors.text }}>
              Parcourez nos questions fréquentes ci-dessous ou contactez notre
              support pour une assistance personnalisée.
            </Text>
          </View>
        </Card>

        {/* FAQ Sections */}
        {FAQ_SECTIONS.map((section, index) => (
          <FAQSectionComponent key={index} section={section} />
        ))}

        {/* Contact support CTA */}
        <Card variant="outlined" padding="lg" style={styles.ctaCard}>
          <Ionicons
            name="help-buoy-outline"
            size={32}
            color={colors.primary}
            style={styles.ctaIcon}
          />
          <Text variant="h4" style={styles.ctaTitle}>
            Besoin d'aide supplémentaire ?
          </Text>
          <Text
            variant="bodySmall"
            color="secondary"
            style={styles.ctaDescription}
          >
            Notre équipe support est disponible pour répondre à toutes vos
            questions.
          </Text>
          <TouchableOpacity
            style={[styles.ctaButton, { backgroundColor: colors.primary }]}
            onPress={() => {
              // Navigate to contact support
              // @ts-ignore - navigation type
              navigation.navigate('ContactSupport')
            }}
          >
            <Text variant="label" style={{ color: '#FFFFFF' }}>
              Contacter le support
            </Text>
          </TouchableOpacity>
        </Card>
      </ScrollView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  searchHint: {
    marginBottom: spacing.lg,
  },
  searchHintContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  faqItem: {
    padding: spacing.md,
    borderBottomWidth: 1,
  },
  faqQuestion: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  questionText: {
    flex: 1,
    paddingRight: spacing.sm,
  },
  answerText: {
    marginTop: spacing.sm,
    lineHeight: 22,
  },
  ctaCard: {
    alignItems: 'center',
    marginTop: spacing.md,
  },
  ctaIcon: {
    marginBottom: spacing.sm,
  },
  ctaTitle: {
    textAlign: 'center',
    marginBottom: spacing.xs,
  },
  ctaDescription: {
    textAlign: 'center',
    marginBottom: spacing.md,
  },
  ctaButton: {
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
  },
})
