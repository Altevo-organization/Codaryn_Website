/**
 * LegalScreen - Terms of use and Privacy policy
 *
 * Displays legal content based on the type parameter
 */

import React from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Card,
  spacing,
  useTheme,
} from '../../ui'
import type { ProfileStackParamList } from '../../navigation/types'

type LegalScreenRouteProp = RouteProp<ProfileStackParamList, 'Legal'>

// Terms of use content
const TERMS_OF_USE = `
**CONDITIONS GÉNÉRALES D'UTILISATION DE MEDISYNC**

*Dernière mise à jour : Janvier 2026*

---

**1. OBJET**

Les présentes conditions générales d'utilisation (CGU) ont pour objet de définir les modalités d'accès et d'utilisation de l'application MediSync, destinée aux professionnels de santé.

---

**2. ACCEPTATION DES CONDITIONS**

L'utilisation de l'application MediSync implique l'acceptation pleine et entière des présentes CGU. Si vous n'acceptez pas ces conditions, vous ne devez pas utiliser l'application.

---

**3. DESCRIPTION DU SERVICE**

MediSync est une application de gestion de cabinet pour les infirmiers libéraux permettant :
- La gestion des dossiers patients
- La planification des visites
- La messagerie sécurisée entre professionnels
- Le suivi des soins

---

**4. CONDITIONS D'ACCÈS**

L'accès à MediSync est réservé aux professionnels de santé disposant d'un numéro RPPS valide. Vous êtes responsable de la confidentialité de vos identifiants de connexion.

---

**5. OBLIGATIONS DE L'UTILISATEUR**

En utilisant MediSync, vous vous engagez à :
- Fournir des informations exactes et à jour
- Respecter la confidentialité des données patients
- Ne pas utiliser l'application à des fins illicites
- Signaler tout incident de sécurité

---

**6. PROPRIÉTÉ INTELLECTUELLE**

L'ensemble des éléments de l'application (design, textes, logos, etc.) sont la propriété exclusive de MediSync. Toute reproduction est interdite sans autorisation préalable.

---

**7. RESPONSABILITÉ**

MediSync s'efforce de maintenir l'application accessible 24h/24, mais ne peut garantir une disponibilité permanente. L'utilisateur reste seul responsable de ses actes professionnels.

---

**8. MODIFICATION DES CGU**

MediSync se réserve le droit de modifier les présentes CGU à tout moment. Les utilisateurs seront informés de toute modification.

---

**9. DROIT APPLICABLE**

Les présentes CGU sont régies par le droit français. Tout litige sera soumis aux tribunaux compétents de Paris.

---

Pour toute question, contactez-nous : legal@medisync.fr
`

// Privacy policy content
const PRIVACY_POLICY = `
**POLITIQUE DE CONFIDENTIALITÉ DE MEDISYNC**

*Dernière mise à jour : Janvier 2026*

---

**1. RESPONSABLE DU TRAITEMENT**

MediSync SAS
123 Avenue de la Santé
75000 Paris, France
Email : dpo@medisync.fr

---

**2. DONNÉES COLLECTÉES**

Nous collectons les données suivantes :

**Données d'identification :**
- Nom, prénom
- Adresse email
- Numéro de téléphone
- Numéro RPPS

**Données professionnelles :**
- Spécialité
- Cabinet d'exercice
- Disponibilités

**Données techniques :**
- Logs de connexion
- Données d'utilisation anonymisées (si consentement)

---

**3. FINALITÉS DU TRAITEMENT**

Vos données sont utilisées pour :
- Fournir les services de l'application
- Assurer la sécurité de votre compte
- Améliorer nos services (données anonymisées)
- Respecter nos obligations légales

---

**4. BASE LÉGALE**

- Exécution du contrat (fourniture du service)
- Intérêt légitime (sécurité, amélioration)
- Consentement (analytics, communications marketing)
- Obligation légale (conservation des données de santé)

---

**5. DURÉE DE CONSERVATION**

- Données de compte : durée de l'abonnement + 3 ans
- Données de santé : 20 ans (obligation légale)
- Logs de sécurité : 1 an
- Cookies : 13 mois maximum

---

**6. PARTAGE DES DONNÉES**

Vos données peuvent être partagées avec :
- Nos sous-traitants techniques (hébergeur HDS certifié)
- Les autorités compétentes sur demande légale
- D'autres professionnels de santé (avec votre accord)

---

**7. VOS DROITS**

Conformément au RGPD, vous disposez des droits suivants :
- Droit d'accès
- Droit de rectification
- Droit à l'effacement
- Droit à la limitation
- Droit à la portabilité
- Droit d'opposition

Pour exercer vos droits : dpo@medisync.fr

---

**8. SÉCURITÉ**

Nous mettons en œuvre des mesures de sécurité appropriées :
- Chiffrement des données en transit et au repos
- Authentification forte
- Hébergement HDS certifié
- Audits de sécurité réguliers

---

**9. COOKIES**

L'application utilise des cookies essentiels au fonctionnement. Les cookies analytiques sont soumis à votre consentement dans les paramètres.

---

**10. CONTACT**

Pour toute question relative à la protection de vos données :
- Email : dpo@medisync.fr
- Adresse : MediSync - DPO, 123 Avenue de la Santé, 75000 Paris

Vous pouvez également introduire une réclamation auprès de la CNIL.
`

export default function LegalScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()
  const route = useRoute<LegalScreenRouteProp>()

  // Get the type from route params (default to terms)
  const type = route.params?.type || 'terms'
  const isTerms = type === 'terms'

  const title = isTerms ? "Conditions d'utilisation" : 'Politique de confidentialité'
  const content = isTerms ? TERMS_OF_USE : PRIVACY_POLICY

  // Parse markdown-like content to render
  const renderContent = (text: string) => {
    const lines = text.trim().split('\n')
    return lines.map((line, index) => {
      const trimmedLine = line.trim()

      // Bold headers with **
      if (trimmedLine.startsWith('**') && trimmedLine.endsWith('**')) {
        const headerText = trimmedLine.slice(2, -2)
        return (
          <Text
            key={index}
            variant="body"
            style={[styles.header, { color: colors.text }]}
          >
            {headerText}
          </Text>
        )
      }

      // Italic with *
      if (trimmedLine.startsWith('*') && trimmedLine.endsWith('*') && !trimmedLine.startsWith('**')) {
        const italicText = trimmedLine.slice(1, -1)
        return (
          <Text
            key={index}
            variant="bodySmall"
            color="secondary"
            style={styles.italic}
          >
            {italicText}
          </Text>
        )
      }

      // Horizontal rule
      if (trimmedLine === '---') {
        return (
          <View
            key={index}
            style={[styles.hr, { backgroundColor: colors.border }]}
          />
        )
      }

      // List items
      if (trimmedLine.startsWith('- ')) {
        return (
          <View key={index} style={styles.listItem}>
            <Text variant="bodySmall" color="secondary">
              •
            </Text>
            <Text variant="bodySmall" color="secondary" style={styles.listText}>
              {trimmedLine.slice(2)}
            </Text>
          </View>
        )
      }

      // Empty line
      if (!trimmedLine) {
        return <View key={index} style={styles.spacer} />
      }

      // Regular paragraph
      return (
        <Text key={index} variant="bodySmall" color="secondary" style={styles.paragraph}>
          {trimmedLine}
        </Text>
      )
    })
  }

  return (
    <ScreenContainer noPadding>
      {/* Header */}
      <View style={[styles.headerBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text variant="h3" style={styles.headerTitle}>
          {title}
        </Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        style={styles.flex}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Card variant="outlined" padding="lg">
          {renderContent(content)}
        </Card>

        {/* Last updated info */}
        <View style={styles.footer}>
          <Ionicons
            name="time-outline"
            size={16}
            color={colors.textTertiary}
          />
          <Text variant="caption" color="tertiary">
            Dernière mise à jour : Janvier 2026
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    fontWeight: '600',
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },
  italic: {
    fontStyle: 'italic',
    marginBottom: spacing.sm,
  },
  hr: {
    height: 1,
    marginVertical: spacing.md,
  },
  listItem: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginLeft: spacing.md,
    marginBottom: spacing.xs,
  },
  listText: {
    flex: 1,
  },
  paragraph: {
    lineHeight: 22,
    marginBottom: spacing.xs,
  },
  spacer: {
    height: spacing.sm,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    marginTop: spacing.lg,
  },
})
