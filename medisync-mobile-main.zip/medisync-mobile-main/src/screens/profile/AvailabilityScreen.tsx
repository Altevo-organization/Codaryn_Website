/**
 * AvailabilityScreen - Edit work availability/schedule
 *
 * Allows user to set working hours for each day of the week
 */

import React, { useState, useEffect, useCallback } from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Button,
  Card,
  spacing,
  radius,
  useTheme,
} from '../../ui'
import { useUserProfile, useUpdateProfile } from '../../features/user'
import type {
  AvailabilitySchedule,
  DayOfWeek,
  TimeSlot,
} from '../../features/user'

// Days of week configuration
const DAYS_OF_WEEK: { key: DayOfWeek; label: string; shortLabel: string }[] = [
  { key: 'monday', label: 'Lundi', shortLabel: 'Lun' },
  { key: 'tuesday', label: 'Mardi', shortLabel: 'Mar' },
  { key: 'wednesday', label: 'Mercredi', shortLabel: 'Mer' },
  { key: 'thursday', label: 'Jeudi', shortLabel: 'Jeu' },
  { key: 'friday', label: 'Vendredi', shortLabel: 'Ven' },
  { key: 'saturday', label: 'Samedi', shortLabel: 'Sam' },
  { key: 'sunday', label: 'Dimanche', shortLabel: 'Dim' },
]

// Common time options
const TIME_OPTIONS = [
  '06:00',
  '06:30',
  '07:00',
  '07:30',
  '08:00',
  '08:30',
  '09:00',
  '09:30',
  '10:00',
  '10:30',
  '11:00',
  '11:30',
  '12:00',
  '12:30',
  '13:00',
  '13:30',
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
  '18:00',
  '18:30',
  '19:00',
  '19:30',
  '20:00',
  '20:30',
  '21:00',
]

// Default slot for new entries
const DEFAULT_SLOT: TimeSlot = { start: '08:00', end: '12:00' }

interface DayScheduleProps {
  day: DayOfWeek
  label: string
  slots: TimeSlot[]
  enabled: boolean
  onToggle: (enabled: boolean) => void
  onAddSlot: () => void
  onRemoveSlot: (index: number) => void
  onUpdateSlot: (index: number, slot: TimeSlot) => void
}

function DaySchedule({
  day,
  label,
  slots,
  enabled,
  onToggle,
  onAddSlot,
  onRemoveSlot,
  onUpdateSlot,
}: DayScheduleProps) {
  const { colors } = useTheme()

  const handleTimeSelect = (
    slotIndex: number,
    field: 'start' | 'end',
    currentValue: string
  ) => {
    Alert.alert(
      field === 'start' ? 'Heure de début' : 'Heure de fin',
      'Sélectionnez une heure',
      [
        ...TIME_OPTIONS.map((time) => ({
          text: time,
          onPress: () => {
            const slot = slots[slotIndex]
            onUpdateSlot(slotIndex, { ...slot, [field]: time })
          },
        })),
        { text: 'Annuler', style: 'cancel' },
      ],
      { cancelable: true }
    )
  }

  return (
    <Card variant="outlined" padding="md" style={styles.dayCard}>
      <View style={styles.dayHeader}>
        <Text variant="body" style={{ fontWeight: '600' }}>
          {label}
        </Text>
        <Switch
          value={enabled}
          onValueChange={onToggle}
          trackColor={{ false: colors.border, true: colors.primaryMuted }}
          thumbColor={enabled ? colors.primary : colors.surface}
        />
      </View>

      {enabled && (
        <View style={styles.slotsContainer}>
          {slots.map((slot, index) => (
            <View key={index} style={styles.slotRow}>
              <TouchableOpacity
                style={[styles.timeButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
                onPress={() => handleTimeSelect(index, 'start', slot.start)}
              >
                <Text variant="body">{slot.start}</Text>
              </TouchableOpacity>

              <Text variant="body" color="secondary">
                à
              </Text>

              <TouchableOpacity
                style={[styles.timeButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
                onPress={() => handleTimeSelect(index, 'end', slot.end)}
              >
                <Text variant="body">{slot.end}</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.removeButton}
                onPress={() => onRemoveSlot(index)}
              >
                <Ionicons name="close-circle" size={24} color={colors.danger} />
              </TouchableOpacity>
            </View>
          ))}

          <TouchableOpacity
            style={[styles.addSlotButton, { borderColor: colors.primary }]}
            onPress={onAddSlot}
          >
            <Ionicons name="add" size={20} color={colors.primary} />
            <Text variant="bodySmall" color="primary">
              Ajouter une plage
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </Card>
  )
}

export default function AvailabilityScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()
  const { data: profile, isLoading: isLoadingProfile } = useUserProfile()
  const updateProfile = useUpdateProfile()

  // Form state - availability for each day
  const [availability, setAvailability] = useState<AvailabilitySchedule>({})
  const [initialAvailability, setInitialAvailability] =
    useState<AvailabilitySchedule>({})

  // Initialize form with profile data
  useEffect(() => {
    if (profile) {
      const initial = profile.availability || {}
      setAvailability(initial)
      setInitialAvailability(initial)
    }
  }, [profile])

  // Check if form has changes
  const hasChanges =
    JSON.stringify(availability) !== JSON.stringify(initialAvailability)

  // Toggle day enabled/disabled
  const toggleDay = useCallback((day: DayOfWeek, enabled: boolean) => {
    setAvailability((prev) => {
      const newAvailability = { ...prev }
      if (enabled) {
        // Enable with default slot
        newAvailability[day] = [{ ...DEFAULT_SLOT }]
      } else {
        // Disable - remove slots
        delete newAvailability[day]
      }
      return newAvailability
    })
  }, [])

  // Add slot to a day
  const addSlot = useCallback((day: DayOfWeek) => {
    setAvailability((prev) => {
      const currentSlots = prev[day] || []
      // Get last slot end time to suggest next slot
      const lastSlot = currentSlots[currentSlots.length - 1]
      const newSlot: TimeSlot = lastSlot
        ? { start: lastSlot.end, end: '18:00' }
        : { ...DEFAULT_SLOT }

      return {
        ...prev,
        [day]: [...currentSlots, newSlot],
      }
    })
  }, [])

  // Remove slot from a day
  const removeSlot = useCallback((day: DayOfWeek, index: number) => {
    setAvailability((prev) => {
      const currentSlots = prev[day] || []
      const newSlots = currentSlots.filter((_, i) => i !== index)

      if (newSlots.length === 0) {
        const newAvailability = { ...prev }
        delete newAvailability[day]
        return newAvailability
      }

      return {
        ...prev,
        [day]: newSlots,
      }
    })
  }, [])

  // Update a specific slot
  const updateSlot = useCallback(
    (day: DayOfWeek, index: number, slot: TimeSlot) => {
      setAvailability((prev) => {
        const currentSlots = prev[day] || []
        const newSlots = [...currentSlots]
        newSlots[index] = slot
        return {
          ...prev,
          [day]: newSlots,
        }
      })
    },
    []
  )

  // Handle save
  const handleSave = async () => {
    try {
      await updateProfile.mutateAsync({ availability })
      Alert.alert('Succès', 'Vos disponibilités ont été mises à jour', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ])
    } catch (error) {
      Alert.alert(
        'Erreur',
        error instanceof Error
          ? error.message
          : 'Impossible de mettre à jour vos disponibilités'
      )
    }
  }

  // Handle back with unsaved changes
  const handleBack = () => {
    if (hasChanges) {
      Alert.alert(
        'Modifications non sauvegardées',
        'Voulez-vous quitter sans sauvegarder ?',
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Quitter',
            style: 'destructive',
            onPress: () => navigation.goBack(),
          },
        ]
      )
    } else {
      navigation.goBack()
    }
  }

  if (isLoadingProfile) {
    return (
      <ScreenContainer>
        <View style={styles.loadingContainer}>
          <Text>Chargement...</Text>
        </View>
      </ScreenContainer>
    )
  }

  return (
    <ScreenContainer noPadding>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text variant="h3" style={styles.headerTitle}>
          Disponibilités
        </Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        style={styles.flex}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Text variant="bodySmall" color="secondary" style={styles.description}>
          Définissez vos horaires de travail pour chaque jour de la semaine.
          Ces informations sont utilisées pour la planification des visites.
        </Text>

        {DAYS_OF_WEEK.map((day) => (
          <DaySchedule
            key={day.key}
            day={day.key}
            label={day.label}
            slots={availability[day.key] || []}
            enabled={Boolean(availability[day.key]?.length)}
            onToggle={(enabled) => toggleDay(day.key, enabled)}
            onAddSlot={() => addSlot(day.key)}
            onRemoveSlot={(index) => removeSlot(day.key, index)}
            onUpdateSlot={(index, slot) => updateSlot(day.key, index, slot)}
          />
        ))}

        <View style={styles.buttonContainer}>
          <Button
            title="Enregistrer"
            onPress={handleSave}
            loading={updateProfile.isPending}
            disabled={!hasChanges || updateProfile.isPending}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  description: {
    marginBottom: spacing.lg,
  },
  dayCard: {
    marginBottom: spacing.md,
  },
  dayHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  slotsContainer: {
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: '#E5E5E5',
  },
  slotRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  timeButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    minWidth: 80,
    alignItems: 'center',
  },
  removeButton: {
    padding: spacing.xs,
  },
  addSlotButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.sm,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderRadius: radius.md,
    marginTop: spacing.xs,
  },
  buttonContainer: {
    marginTop: spacing.lg,
  },
})
