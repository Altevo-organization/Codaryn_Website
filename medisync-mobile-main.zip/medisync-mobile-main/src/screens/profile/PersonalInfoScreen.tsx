/**
 * PersonalInfoScreen - Edit personal information
 *
 * Allows user to update: firstName, lastName, phone, address
 */

import React, { useState, useEffect } from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Input,
  Button,
  Card,
  spacing,
  useTheme,
} from '../../ui'
import { useUserProfile, useUpdateProfile } from '../../features/user'
import type { UpdatePersonalInfoDto } from '../../features/user'

export default function PersonalInfoScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()
  const { data: profile, isLoading: isLoadingProfile } = useUserProfile()
  const updateProfile = useUpdateProfile()

  // Form state
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Initialize form with profile data
  useEffect(() => {
    if (profile) {
      setFirstName(profile.firstName || '')
      setLastName(profile.lastName || '')
      setPhone(profile.phone || '')
      setAddress(profile.address || '')
    }
  }, [profile])

  // Check if form has changes
  const hasChanges =
    profile &&
    (firstName !== (profile.firstName || '') ||
      lastName !== (profile.lastName || '') ||
      phone !== (profile.phone || '') ||
      address !== (profile.address || ''))

  // Validate phone number format
  const validatePhone = (value: string): boolean => {
    if (!value) return true // Optional field
    // French phone format: 10 digits, may start with +33
    const phoneRegex = /^(\+33|0)[1-9](\d{2}){4}$/
    return phoneRegex.test(value.replace(/\s/g, ''))
  }

  // Validate form
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!firstName.trim()) {
      newErrors.firstName = 'Le prénom est requis'
    } else if (firstName.trim().length < 2) {
      newErrors.firstName = 'Le prénom doit contenir au moins 2 caractères'
    }

    if (!lastName.trim()) {
      newErrors.lastName = 'Le nom est requis'
    } else if (lastName.trim().length < 2) {
      newErrors.lastName = 'Le nom doit contenir au moins 2 caractères'
    }

    if (phone && !validatePhone(phone)) {
      newErrors.phone = 'Format de téléphone invalide'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Handle save
  const handleSave = async () => {
    if (!validate()) return

    const data: UpdatePersonalInfoDto = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      phone: phone.trim() || undefined,
      address: address.trim() || undefined,
    }

    try {
      await updateProfile.mutateAsync(data)
      Alert.alert('Succès', 'Vos informations ont été mises à jour', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ])
    } catch (error) {
      Alert.alert(
        'Erreur',
        error instanceof Error
          ? error.message
          : 'Impossible de mettre à jour vos informations'
      )
    }
  }

  // Handle back with unsaved changes
  const handleBack = () => {
    if (hasChanges) {
      Alert.alert(
        'Modifications non sauvegardées',
        'Voulez-vous quitter sans sauvegarder ?',
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Quitter',
            style: 'destructive',
            onPress: () => navigation.goBack(),
          },
        ]
      )
    } else {
      navigation.goBack()
    }
  }

  if (isLoadingProfile) {
    return (
      <ScreenContainer>
        <View style={styles.loadingContainer}>
          <Text>Chargement...</Text>
        </View>
      </ScreenContainer>
    )
  }

  return (
    <ScreenContainer noPadding>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text variant="h3" style={styles.headerTitle}>
            Informations personnelles
          </Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView
          style={styles.flex}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingBottom: insets.bottom + 100 },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Card variant="outlined" padding="lg">
            <Input
              label="Prénom"
              placeholder="Votre prénom"
              value={firstName}
              onChangeText={setFirstName}
              error={errors.firstName}
              required
              autoCapitalize="words"
              containerStyle={styles.inputContainer}
            />

            <Input
              label="Nom"
              placeholder="Votre nom"
              value={lastName}
              onChangeText={setLastName}
              error={errors.lastName}
              required
              autoCapitalize="words"
              containerStyle={styles.inputContainer}
            />

            <Input
              label="Téléphone"
              placeholder="06 12 34 56 78"
              value={phone}
              onChangeText={setPhone}
              error={errors.phone}
              keyboardType="phone-pad"
              containerStyle={styles.inputContainer}
            />

            <Input
              label="Adresse"
              placeholder="Votre adresse"
              value={address}
              onChangeText={setAddress}
              multiline
              numberOfLines={3}
              containerStyle={styles.inputContainer}
            />
          </Card>

          <View style={styles.buttonContainer}>
            <Button
              title="Enregistrer"
              onPress={handleSave}
              loading={updateProfile.isPending}
              disabled={!hasChanges || updateProfile.isPending}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  inputContainer: {
    marginBottom: spacing.md,
  },
  buttonContainer: {
    marginTop: spacing.lg,
  },
})
