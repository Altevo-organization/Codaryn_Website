/**
 * ProfileScreen - Modern Profile & Settings
 *
 * Complete user profile with all settings for a 2026 mobile app:
 * - User info header with avatar
 * - Account settings
 * - Appearance (theme)
 * - Notifications
 * - Privacy & Security
 * - About & Support
 * - Logout
 */

import React, { useCallback, useMemo, useEffect, useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  Switch,
  TouchableOpacity,
  Alert,
  Linking,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import * as Application from 'expo-application';

import {
  ScreenContainer,
  Text,
  Card,
  Avatar,
  Row,
  Divider,
  Badge,
  spacing,
  radius,
  useTheme,
} from '../../ui';
import { useAuthStore } from '../../stores/authStore';
import { usePreferencesStore } from '../../stores/preferencesStore';
import { useUpdatePreference, useUserProfile } from '../../features/user';
import {
  enableBiometricAuth,
  disableBiometricAuth,
  checkBiometricAvailability,
  getBiometricTypeName,
} from '../../services/biometrics';
import { tapFeedback } from '../../services/haptics';
import type { ProfileStackParamList } from '../../navigation/types';

type ProfileNavigationProp = NativeStackNavigationProp<ProfileStackParamList>;

// =============================================================================
// TYPES
// =============================================================================

interface SettingsItemProps {
  icon: keyof typeof Ionicons.glyphMap;
  iconColor?: string;
  label: string;
  description?: string;
  value?: string | React.ReactNode;
  onPress?: () => void;
  showChevron?: boolean;
  rightElement?: React.ReactNode;
  danger?: boolean;
}

interface SettingsSectionProps {
  title: string;
  children: React.ReactNode;
}

// =============================================================================
// SETTINGS ITEM COMPONENT
// =============================================================================

function SettingsItem({
  icon,
  iconColor,
  label,
  description,
  value,
  onPress,
  showChevron = true,
  rightElement,
  danger = false,
}: SettingsItemProps) {
  const { colors } = useTheme();
  const textColor = danger ? colors.danger : colors.text;
  const finalIconColor = iconColor || (danger ? colors.danger : colors.primary);

  const handlePress = useCallback(() => {
    tapFeedback();
    onPress?.();
  }, [onPress]);

  const content = (
    <Row align="center" gap="md" style={styles.settingsItemRow}>
      {/* Icon */}
      <View
        style={[
          styles.iconContainer,
          {
            backgroundColor: danger ? colors.dangerMuted : colors.primaryMuted,
          },
        ]}
      >
        <Ionicons name={icon} size={20} color={finalIconColor} />
      </View>

      {/* Label & Description */}
      <View style={styles.settingsItemContent}>
        <Text variant="body" style={{ color: textColor }} numberOfLines={1}>
          {label}
        </Text>
        {description && (
          <Text variant="caption" color="tertiary" numberOfLines={1}>
            {description}
          </Text>
        )}
      </View>

      {/* Right side */}
      {rightElement ? (
        rightElement
      ) : value ? (
        <Text variant="bodySmall" color="secondary">
          {value}
        </Text>
      ) : null}

      {/* Chevron */}
      {showChevron && onPress && (
        <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
      )}
    </Row>
  );

  if (onPress) {
    return (
      <TouchableOpacity
        onPress={handlePress}
        activeOpacity={0.7}
        style={styles.settingsItem}
      >
        {content}
      </TouchableOpacity>
    );
  }

  return <View style={styles.settingsItem}>{content}</View>;
}

// =============================================================================
// SETTINGS SECTION COMPONENT
// =============================================================================

function SettingsSection({ title, children }: SettingsSectionProps) {
  return (
    <View style={styles.section}>
      {title ? (
        <Text variant="label" color="secondary" style={styles.sectionTitle}>
          {title}
        </Text>
      ) : null}
      <Card variant="outlined" padding="none">
        {children}
      </Card>
    </View>
  );
}

// =============================================================================
// PROFILE HEADER COMPONENT
// =============================================================================

function ProfileHeader({
  onEditPress,
}: {
  onEditPress: () => void;
}) {
  const { colors } = useTheme();
  const user = useAuthStore((s) => s.user);

  return (
    <Card variant="elevated" padding="lg" style={styles.headerCard}>
      <Row align="center" gap="lg">
        <Avatar name={user?.fullName || 'Utilisateur'} size="xl" />
        <View style={styles.headerInfo}>
          <Text variant="h3" numberOfLines={1}>
            {user?.fullName || 'Utilisateur'}
          </Text>
          <Text variant="body" color="secondary" numberOfLines={1}>
            {user?.email || 'email@example.com'}
          </Text>
          <Badge variant="primary" size="sm" style={styles.roleBadge}>
            Infirmier(ère)
          </Badge>
        </View>
      </Row>

      {/* Edit Profile Button */}
      <TouchableOpacity
        style={[styles.editButton, { borderColor: colors.border }]}
        activeOpacity={0.7}
        onPress={onEditPress}
      >
        <Ionicons name="pencil" size={16} color={colors.primary} />
        <Text variant="label" color="primary" style={styles.editButtonText}>
          Modifier
        </Text>
      </TouchableOpacity>
    </Card>
  );
}

// =============================================================================
// MAIN COMPONENT
// =============================================================================

export default function ProfileScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<ProfileNavigationProp>();
  const clearAuth = useAuthStore((s) => s.clearAuth);

  // Backend profile data
  const { data: profile } = useUserProfile();
  const updatePreference = useUpdatePreference();

  // Local preferences (for immediate UI feedback)
  const themeMode = usePreferencesStore((s) => s.themeMode);
  const setThemeMode = usePreferencesStore((s) => s.setThemeMode);
  const notifications = usePreferencesStore((s) => s.notifications);
  const setNotificationPreference = usePreferencesStore(
    (s) => s.setNotificationPreference
  );
  const biometricsEnabled = usePreferencesStore((s) => s.biometricsEnabled);
  const setBiometricsEnabled = usePreferencesStore((s) => s.setBiometricsEnabled);
  const hapticsEnabled = usePreferencesStore((s) => s.hapticsEnabled);
  const setHapticsEnabled = usePreferencesStore((s) => s.setHapticsEnabled);
  const privacy = usePreferencesStore((s) => s.privacy);
  const setPrivacyPreference = usePreferencesStore(
    (s) => s.setPrivacyPreference
  );

  // Biometric availability
  const [biometricType, setBiometricType] = useState<
    'face' | 'fingerprint' | 'iris' | 'none'
  >('none');
  const [biometricAvailable, setBiometricAvailable] = useState(false);

  // Check biometric availability on mount
  useEffect(() => {
    checkBiometricAvailability().then((result) => {
      setBiometricAvailable(result.isAvailable);
      setBiometricType(result.biometricType);
    });
  }, []);

  // Sync preferences from backend on first load
  useEffect(() => {
    if (profile) {
      setHapticsEnabled(profile.hapticsEnabled);
      setNotificationPreference('appointments', profile.notifAppointments);
      setNotificationPreference('messages', profile.notifMessages);
      setNotificationPreference('reminders', profile.notifReminders);
      setNotificationPreference('updates', profile.notifUpdates);
      setPrivacyPreference('analyticsEnabled', profile.analyticsEnabled);
      setPrivacyPreference('crashReportsEnabled', profile.crashReportsEnabled);
      setBiometricsEnabled(profile.biometricsEnabled);
    }
  }, [profile]);

  // Theme label
  const themeModeLabel = useMemo(() => {
    switch (themeMode) {
      case 'light':
        return 'Clair';
      case 'dark':
        return 'Sombre';
      case 'system':
        return 'Système';
    }
  }, [themeMode]);

  // Biometric label
  const biometricLabel = useMemo(() => {
    return getBiometricTypeName(biometricType);
  }, [biometricType]);

  // Handler: Update preference with backend sync
  const handlePreferenceChange = useCallback(
    async (
      key: string,
      value: boolean,
      localSetter: (value: boolean) => void
    ) => {
      // Optimistic update
      localSetter(value);
      tapFeedback();

      try {
        await updatePreference.mutateAsync({ [key]: value });
      } catch (error) {
        // Rollback on error
        localSetter(!value);
        Alert.alert('Erreur', 'Impossible de sauvegarder la préférence');
      }
    },
    [updatePreference]
  );

  // Handlers
  const handleThemePress = useCallback(() => {
    tapFeedback();
    Alert.alert("Apparence", "Choisissez le thème de l'application", [
      { text: 'Clair', onPress: () => setThemeMode('light') },
      { text: 'Sombre', onPress: () => setThemeMode('dark') },
      { text: 'Système', onPress: () => setThemeMode('system') },
      { text: 'Annuler', style: 'cancel' },
    ]);
  }, [setThemeMode]);

  const handleHapticsChange = useCallback(
    (value: boolean) => {
      handlePreferenceChange('hapticsEnabled', value, setHapticsEnabled);
    },
    [handlePreferenceChange, setHapticsEnabled]
  );

  const handleNotificationChange = useCallback(
    (
      key: 'appointments' | 'messages' | 'reminders' | 'updates',
      backendKey: string
    ) => {
      const newValue = !notifications[key];
      handlePreferenceChange(backendKey, newValue, () =>
        setNotificationPreference(key, newValue)
      );
    },
    [notifications, handlePreferenceChange, setNotificationPreference]
  );

  const handleBiometricsChange = useCallback(
    async (value: boolean) => {
      if (!biometricAvailable) {
        Alert.alert(
          'Non disponible',
          `${biometricLabel} n'est pas disponible sur cet appareil`
        );
        return;
      }

      if (value) {
        const success = await enableBiometricAuth();
        if (success) {
          handlePreferenceChange(
            'biometricsEnabled',
            true,
            setBiometricsEnabled
          );
        }
      } else {
        await disableBiometricAuth();
        handlePreferenceChange(
          'biometricsEnabled',
          false,
          setBiometricsEnabled
        );
      }
    },
    [
      biometricAvailable,
      biometricLabel,
      handlePreferenceChange,
      setBiometricsEnabled,
    ]
  );

  const handlePrivacyChange = useCallback(
    (key: 'analyticsEnabled' | 'crashReportsEnabled') => {
      const newValue = !privacy[key];
      handlePreferenceChange(key, newValue, () =>
        setPrivacyPreference(key, newValue)
      );
    },
    [privacy, handlePreferenceChange, setPrivacyPreference]
  );

  const handleLogout = useCallback(() => {
    tapFeedback();
    Alert.alert('Déconnexion', 'Êtes-vous sûr de vouloir vous déconnecter ?', [
      { text: 'Annuler', style: 'cancel' },
      { text: 'Déconnexion', style: 'destructive', onPress: clearAuth },
    ]);
  }, [clearAuth]);

  const handleRateApp = useCallback(() => {
    const storeUrl = Platform.select({
      ios: 'https://apps.apple.com/app/medisync/id123456789',
      android: 'https://play.google.com/store/apps/details?id=com.medisync',
    });
    if (storeUrl) {
      Linking.openURL(storeUrl);
    }
  }, []);

  // App version
  const appVersion = Application.nativeApplicationVersion || '1.0.0';
  const buildNumber = Application.nativeBuildVersion || '1';

  return (
    <ScreenContainer noPadding>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text variant="h2">Profil</Text>
        </View>

        {/* Profile Card */}
        <View style={styles.content}>
          <ProfileHeader
            onEditPress={() => navigation.navigate('PersonalInfo')}
          />

          {/* Account Section */}
          <SettingsSection title="COMPTE">
            <SettingsItem
              icon="person-outline"
              label="Informations personnelles"
              description="Nom, téléphone, adresse"
              onPress={() => navigation.navigate('PersonalInfo')}
            />
            <Divider />
            <SettingsItem
              icon="medical-outline"
              label="Informations professionnelles"
              description="RPPS, spécialité, cabinet"
              onPress={() => navigation.navigate('ProfessionalInfo')}
            />
            <Divider />
            <SettingsItem
              icon="calendar-outline"
              label="Disponibilités"
              description="Horaires de travail"
              onPress={() => navigation.navigate('Availability')}
            />
          </SettingsSection>

          {/* Appearance Section */}
          <SettingsSection title="APPARENCE">
            <SettingsItem
              icon="color-palette-outline"
              label="Thème"
              value={themeModeLabel}
              onPress={handleThemePress}
            />
            <Divider />
            <SettingsItem
              icon="phone-portrait-outline"
              label="Retour haptique"
              description="Vibrations tactiles"
              showChevron={false}
              rightElement={
                <Switch
                  value={hapticsEnabled}
                  onValueChange={handleHapticsChange}
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={hapticsEnabled ? colors.primary : colors.surface}
                />
              }
            />
          </SettingsSection>

          {/* Notifications Section */}
          <SettingsSection title="NOTIFICATIONS">
            <SettingsItem
              icon="calendar"
              label="Rendez-vous"
              description="Rappels de visites"
              showChevron={false}
              rightElement={
                <Switch
                  value={notifications.appointments}
                  onValueChange={() =>
                    handleNotificationChange('appointments', 'notifAppointments')
                  }
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={
                    notifications.appointments ? colors.primary : colors.surface
                  }
                />
              }
            />
            <Divider />
            <SettingsItem
              icon="chatbubble"
              label="Messages"
              description="Nouveaux messages"
              showChevron={false}
              rightElement={
                <Switch
                  value={notifications.messages}
                  onValueChange={() =>
                    handleNotificationChange('messages', 'notifMessages')
                  }
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={
                    notifications.messages ? colors.primary : colors.surface
                  }
                />
              }
            />
            <Divider />
            <SettingsItem
              icon="alarm"
              label="Rappels"
              description="Tâches et suivis"
              showChevron={false}
              rightElement={
                <Switch
                  value={notifications.reminders}
                  onValueChange={() =>
                    handleNotificationChange('reminders', 'notifReminders')
                  }
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={
                    notifications.reminders ? colors.primary : colors.surface
                  }
                />
              }
            />
            <Divider />
            <SettingsItem
              icon="megaphone-outline"
              label="Mises à jour"
              description="Nouveautés de l'app"
              showChevron={false}
              rightElement={
                <Switch
                  value={notifications.updates}
                  onValueChange={() =>
                    handleNotificationChange('updates', 'notifUpdates')
                  }
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={
                    notifications.updates ? colors.primary : colors.surface
                  }
                />
              }
            />
          </SettingsSection>

          {/* Security Section */}
          <SettingsSection title="SÉCURITÉ & CONFIDENTIALITÉ">
            <SettingsItem
              icon="finger-print"
              label="Authentification biométrique"
              description={biometricLabel}
              showChevron={false}
              rightElement={
                <Switch
                  value={biometricsEnabled}
                  onValueChange={handleBiometricsChange}
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={biometricsEnabled ? colors.primary : colors.surface}
                  disabled={!biometricAvailable}
                />
              }
            />
            <Divider />
            <SettingsItem
              icon="lock-closed-outline"
              label="Modifier le mot de passe"
              onPress={() => navigation.navigate('ChangePassword')}
            />
            <Divider />
            <SettingsItem
              icon="analytics-outline"
              label="Données analytiques"
              description="Améliorer l'application"
              showChevron={false}
              rightElement={
                <Switch
                  value={privacy.analyticsEnabled}
                  onValueChange={() => handlePrivacyChange('analyticsEnabled')}
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={
                    privacy.analyticsEnabled ? colors.primary : colors.surface
                  }
                />
              }
            />
            <Divider />
            <SettingsItem
              icon="bug-outline"
              label="Rapports de crash"
              description="Signaler les erreurs"
              showChevron={false}
              rightElement={
                <Switch
                  value={privacy.crashReportsEnabled}
                  onValueChange={() =>
                    handlePrivacyChange('crashReportsEnabled')
                  }
                  trackColor={{ false: colors.border, true: colors.primaryMuted }}
                  thumbColor={
                    privacy.crashReportsEnabled ? colors.primary : colors.surface
                  }
                />
              }
            />
          </SettingsSection>

          {/* Support Section */}
          <SettingsSection title="AIDE & SUPPORT">
            <SettingsItem
              icon="help-circle-outline"
              label="Centre d'aide"
              onPress={() => navigation.navigate('HelpCenter')}
            />
            <Divider />
            <SettingsItem
              icon="mail-outline"
              label="Contacter le support"
              onPress={() => navigation.navigate('ContactSupport')}
            />
            <Divider />
            <SettingsItem
              icon="star-outline"
              label="Noter l'application"
              onPress={handleRateApp}
            />
          </SettingsSection>

          {/* Legal Section */}
          <SettingsSection title="INFORMATIONS LÉGALES">
            <SettingsItem
              icon="document-text-outline"
              label="Conditions d'utilisation"
              onPress={() => navigation.navigate('Legal', { type: 'terms' })}
            />
            <Divider />
            <SettingsItem
              icon="shield-checkmark-outline"
              label="Politique de confidentialité"
              onPress={() => navigation.navigate('Legal', { type: 'privacy' })}
            />
            <Divider />
            <SettingsItem
              icon="information-circle-outline"
              label="Version"
              value={`${appVersion} (${buildNumber})`}
              showChevron={false}
            />
          </SettingsSection>

          {/* Logout */}
          <SettingsSection title="">
            <SettingsItem
              icon="log-out-outline"
              label="Se déconnecter"
              onPress={handleLogout}
              showChevron={false}
              danger
            />
          </SettingsSection>

          {/* Footer */}
          <View style={styles.footer}>
            <Text variant="caption" color="tertiary" style={styles.footerText}>
              MediSync © 2026
            </Text>
            <Text variant="caption" color="tertiary" style={styles.footerText}>
              Fait avec soin pour les soignants
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
  },
  content: {
    paddingHorizontal: spacing.lg,
  },
  headerCard: {
    marginBottom: spacing.lg,
  },
  headerInfo: {
    flex: 1,
  },
  roleBadge: {
    marginTop: spacing.xs,
    alignSelf: 'flex-start',
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    marginTop: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
  },
  editButtonText: {
    marginLeft: spacing.xs,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    marginBottom: spacing.sm,
    marginLeft: spacing.xs,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  settingsItem: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
  },
  settingsItemRow: {
    minHeight: 44,
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingsItemContent: {
    flex: 1,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
  },
  footerText: {
    marginTop: spacing.xxs,
  },
});
