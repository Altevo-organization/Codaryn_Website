/**
 * ChangePasswordScreen - Change user password
 *
 * Secure password change with current password verification
 */

import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Input,
  Button,
  Card,
  spacing,
  useTheme,
} from '../../ui'
import { useChangePassword } from '../../features/user'
import type { ChangePasswordDto } from '../../features/user'

export default function ChangePasswordScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()
  const changePassword = useChangePassword()

  // Form state
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Password visibility toggles
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  // Check if form is filled
  const isFormFilled = currentPassword && newPassword && confirmPassword

  // Validate password strength
  const validatePasswordStrength = (password: string): string | null => {
    if (password.length < 8) {
      return 'Le mot de passe doit contenir au moins 8 caractères'
    }
    if (!/[A-Z]/.test(password)) {
      return 'Le mot de passe doit contenir au moins une majuscule'
    }
    if (!/[a-z]/.test(password)) {
      return 'Le mot de passe doit contenir au moins une minuscule'
    }
    if (!/[0-9]/.test(password)) {
      return 'Le mot de passe doit contenir au moins un chiffre'
    }
    return null
  }

  // Validate form
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!currentPassword) {
      newErrors.currentPassword = 'Le mot de passe actuel est requis'
    }

    if (!newPassword) {
      newErrors.newPassword = 'Le nouveau mot de passe est requis'
    } else {
      const strengthError = validatePasswordStrength(newPassword)
      if (strengthError) {
        newErrors.newPassword = strengthError
      }
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = 'La confirmation est requise'
    } else if (newPassword !== confirmPassword) {
      newErrors.confirmPassword = 'Les mots de passe ne correspondent pas'
    }

    if (currentPassword && newPassword && currentPassword === newPassword) {
      newErrors.newPassword =
        'Le nouveau mot de passe doit être différent de l\'actuel'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Handle save
  const handleSave = async () => {
    if (!validate()) return

    const data: ChangePasswordDto = {
      currentPassword,
      newPassword,
      confirmPassword,
    }

    try {
      await changePassword.mutateAsync(data)
      Alert.alert(
        'Succès',
        'Votre mot de passe a été modifié avec succès',
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      )
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'Une erreur est survenue'

      // Check for specific error messages
      if (message.toLowerCase().includes('incorrect')) {
        setErrors({ currentPassword: 'Mot de passe actuel incorrect' })
      } else {
        Alert.alert('Erreur', message)
      }
    }
  }

  // Handle back
  const handleBack = () => {
    if (isFormFilled) {
      Alert.alert(
        'Modifications non sauvegardées',
        'Voulez-vous quitter sans sauvegarder ?',
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Quitter',
            style: 'destructive',
            onPress: () => navigation.goBack(),
          },
        ]
      )
    } else {
      navigation.goBack()
    }
  }

  // Password visibility icon
  const PasswordIcon = ({
    visible,
    onPress,
  }: {
    visible: boolean
    onPress: () => void
  }) => (
    <TouchableOpacity onPress={onPress}>
      <Ionicons
        name={visible ? 'eye-off' : 'eye'}
        size={20}
        color={colors.textSecondary}
      />
    </TouchableOpacity>
  )

  return (
    <ScreenContainer noPadding>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text variant="h3" style={styles.headerTitle}>
            Modifier le mot de passe
          </Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView
          style={styles.flex}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingBottom: insets.bottom + 100 },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Card variant="outlined" padding="lg">
            <Input
              label="Mot de passe actuel"
              placeholder="Entrez votre mot de passe actuel"
              value={currentPassword}
              onChangeText={setCurrentPassword}
              error={errors.currentPassword}
              secureTextEntry={!showCurrentPassword}
              required
              iconRight={
                <PasswordIcon
                  visible={showCurrentPassword}
                  onPress={() => setShowCurrentPassword(!showCurrentPassword)}
                />
              }
              containerStyle={styles.inputContainer}
            />

            <Input
              label="Nouveau mot de passe"
              placeholder="Entrez votre nouveau mot de passe"
              value={newPassword}
              onChangeText={setNewPassword}
              error={errors.newPassword}
              secureTextEntry={!showNewPassword}
              required
              iconRight={
                <PasswordIcon
                  visible={showNewPassword}
                  onPress={() => setShowNewPassword(!showNewPassword)}
                />
              }
              containerStyle={styles.inputContainer}
            />

            <Input
              label="Confirmer le mot de passe"
              placeholder="Confirmez votre nouveau mot de passe"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              error={errors.confirmPassword}
              secureTextEntry={!showConfirmPassword}
              required
              iconRight={
                <PasswordIcon
                  visible={showConfirmPassword}
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                />
              }
              containerStyle={styles.inputContainer}
            />
          </Card>

          {/* Password requirements */}
          <Card
            variant="filled"
            padding="md"
            style={[styles.infoCard, { backgroundColor: colors.surfaceSecondary }]}
          >
            <Text
              variant="label"
              style={[styles.infoTitle, { color: colors.text }]}
            >
              Exigences du mot de passe
            </Text>
            <View style={styles.requirementsList}>
              <RequirementItem
                met={newPassword.length >= 8}
                text="Au moins 8 caractères"
              />
              <RequirementItem
                met={/[A-Z]/.test(newPassword)}
                text="Au moins une majuscule"
              />
              <RequirementItem
                met={/[a-z]/.test(newPassword)}
                text="Au moins une minuscule"
              />
              <RequirementItem
                met={/[0-9]/.test(newPassword)}
                text="Au moins un chiffre"
              />
            </View>
          </Card>

          <View style={styles.buttonContainer}>
            <Button
              title="Modifier le mot de passe"
              onPress={handleSave}
              loading={changePassword.isPending}
              disabled={!isFormFilled || changePassword.isPending}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  )
}

// Requirement item component
function RequirementItem({ met, text }: { met: boolean; text: string }) {
  const { colors } = useTheme()

  return (
    <View style={styles.requirementItem}>
      <Ionicons
        name={met ? 'checkmark-circle' : 'ellipse-outline'}
        size={16}
        color={met ? colors.success : colors.textTertiary}
      />
      <Text
        variant="bodySmall"
        style={{ color: met ? colors.success : colors.textSecondary }}
      >
        {text}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  inputContainer: {
    marginBottom: spacing.md,
  },
  infoCard: {
    marginTop: spacing.lg,
  },
  infoTitle: {
    marginBottom: spacing.sm,
  },
  requirementsList: {
    gap: spacing.xs,
  },
  requirementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  buttonContainer: {
    marginTop: spacing.xl,
  },
})
