/**
 * ContactSupportScreen - Contact support form
 *
 * Allows users to submit support requests
 */

import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'

import {
  ScreenContainer,
  Text,
  Input,
  Button,
  Card,
  spacing,
  radius,
  useTheme,
} from '../../ui'
import { useSubmitSupportRequest } from '../../features/user'

// Common support topics
const SUPPORT_TOPICS = [
  'Question technique',
  'Problème de connexion',
  'Bug ou dysfonctionnement',
  'Demande de fonctionnalité',
  'Question sur la facturation',
  'Protection des données',
  'Autre',
]

export default function ContactSupportScreen() {
  const { colors } = useTheme()
  const insets = useSafeAreaInsets()
  const navigation = useNavigation()
  const submitRequest = useSubmitSupportRequest()

  // Form state
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Check if form is filled
  const isFormFilled = subject.trim() && message.trim()

  // Handle topic selection
  const handleSelectTopic = () => {
    Alert.alert(
      'Sujet',
      'Choisissez le sujet de votre demande',
      [
        ...SUPPORT_TOPICS.map((topic) => ({
          text: topic,
          onPress: () => setSubject(topic),
        })),
        { text: 'Annuler', style: 'cancel' },
      ],
      { cancelable: true }
    )
  }

  // Validate form
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!subject.trim()) {
      newErrors.subject = 'Le sujet est requis'
    }

    if (!message.trim()) {
      newErrors.message = 'Le message est requis'
    } else if (message.trim().length < 10) {
      newErrors.message = 'Le message doit contenir au moins 10 caractères'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Handle submit
  const handleSubmit = async () => {
    if (!validate()) return

    try {
      await submitRequest.mutateAsync({
        subject: subject.trim(),
        message: message.trim(),
      })
      Alert.alert(
        'Message envoyé',
        'Votre demande a été transmise à notre équipe support. Nous vous répondrons dans les plus brefs délais.',
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      )
    } catch (error) {
      Alert.alert(
        'Erreur',
        error instanceof Error
          ? error.message
          : 'Impossible d\'envoyer votre message'
      )
    }
  }

  // Handle back
  const handleBack = () => {
    if (isFormFilled) {
      Alert.alert(
        'Modifications non sauvegardées',
        'Voulez-vous quitter sans envoyer ?',
        [
          { text: 'Annuler', style: 'cancel' },
          {
            text: 'Quitter',
            style: 'destructive',
            onPress: () => navigation.goBack(),
          },
        ]
      )
    } else {
      navigation.goBack()
    }
  }

  return (
    <ScreenContainer noPadding>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text variant="h3" style={styles.headerTitle}>
            Contacter le support
          </Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView
          style={styles.flex}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingBottom: insets.bottom + 100 },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Info card */}
          <Card
            variant="filled"
            padding="md"
            style={[styles.infoCard, { backgroundColor: colors.primaryMuted }]}
          >
            <View style={styles.infoContent}>
              <Ionicons
                name="information-circle"
                size={24}
                color={colors.primary}
              />
              <Text variant="bodySmall" style={{ flex: 1, color: colors.text }}>
                Notre équipe support vous répondra sous 24-48h ouvrées. Pour les
                urgences, contactez-nous par téléphone.
              </Text>
            </View>
          </Card>

          {/* Form */}
          <Card variant="outlined" padding="lg" style={styles.formCard}>
            {/* Subject selector */}
            <View style={styles.inputContainer}>
              <Text
                variant="label"
                style={[styles.inputLabel, { color: colors.text }]}
              >
                Sujet <Text style={{ color: colors.danger }}>*</Text>
              </Text>
              <TouchableOpacity
                style={[
                  styles.selectButton,
                  {
                    backgroundColor: colors.surface,
                    borderColor: errors.subject ? colors.danger : colors.border,
                  },
                ]}
                onPress={handleSelectTopic}
              >
                <Text
                  style={{
                    color: subject ? colors.text : colors.textTertiary,
                  }}
                >
                  {subject || 'Sélectionnez un sujet'}
                </Text>
                <Ionicons
                  name="chevron-down"
                  size={20}
                  color={colors.textTertiary}
                />
              </TouchableOpacity>
              {errors.subject && (
                <Text
                  variant="caption"
                  style={[styles.errorText, { color: colors.danger }]}
                >
                  {errors.subject}
                </Text>
              )}
            </View>

            {/* Message input */}
            <Input
              label="Message"
              placeholder="Décrivez votre problème ou votre question en détail..."
              value={message}
              onChangeText={setMessage}
              error={errors.message}
              multiline
              numberOfLines={6}
              required
              containerStyle={styles.inputContainer}
              inputStyle={styles.messageInput}
            />

            {/* Character count */}
            <Text variant="caption" color="tertiary" style={styles.charCount}>
              {message.length} caractère{message.length !== 1 ? 's' : ''}
            </Text>
          </Card>

          {/* Alternative contact methods */}
          <Card variant="outlined" padding="md" style={styles.alternativeCard}>
            <Text variant="label" style={styles.alternativeTitle}>
              Autres moyens de contact
            </Text>

            <TouchableOpacity style={styles.alternativeItem}>
              <View
                style={[
                  styles.alternativeIcon,
                  { backgroundColor: colors.primaryMuted },
                ]}
              >
                <Ionicons name="mail-outline" size={20} color={colors.primary} />
              </View>
              <View style={styles.alternativeInfo}>
                <Text variant="body">Email</Text>
                <Text variant="bodySmall" color="secondary">
                  support@medisync.fr
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.alternativeItem}>
              <View
                style={[
                  styles.alternativeIcon,
                  { backgroundColor: colors.primaryMuted },
                ]}
              >
                <Ionicons name="call-outline" size={20} color={colors.primary} />
              </View>
              <View style={styles.alternativeInfo}>
                <Text variant="body">Téléphone</Text>
                <Text variant="bodySmall" color="secondary">
                  01 23 45 67 89 (Lun-Ven, 9h-18h)
                </Text>
              </View>
            </TouchableOpacity>
          </Card>

          {/* Submit button */}
          <View style={styles.buttonContainer}>
            <Button
              title="Envoyer"
              onPress={handleSubmit}
              loading={submitRequest.isPending}
              disabled={!isFormFilled || submitRequest.isPending}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  infoCard: {
    marginBottom: spacing.lg,
  },
  infoContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  formCard: {
    marginBottom: spacing.lg,
  },
  inputContainer: {
    marginBottom: spacing.md,
  },
  inputLabel: {
    marginBottom: spacing.xs,
  },
  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderWidth: 1,
    borderRadius: radius.md,
    minHeight: 48,
  },
  errorText: {
    marginTop: spacing.xs,
  },
  messageInput: {
    minHeight: 120,
    textAlignVertical: 'top',
  },
  charCount: {
    textAlign: 'right',
  },
  alternativeCard: {
    marginBottom: spacing.lg,
  },
  alternativeTitle: {
    marginBottom: spacing.md,
  },
  alternativeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm,
  },
  alternativeIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  alternativeInfo: {
    flex: 1,
  },
  buttonContainer: {
    marginTop: spacing.md,
  },
})
