/**
 * LoginScreen
 *
 * Authentication screen with email and password.
 * Redesigned with MediSync design system.
 */

import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TextInput as RNTextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMutation } from '@tanstack/react-query';

import {
  ScreenContainer,
  Stack,
  Text,
  Input,
  Button,
  Card,
  spacing,
  useTheme,
} from '../../ui';
import { login } from '../../features/auth/api';
import type { LoginCredentials, LoginResponse } from '../../features/auth/types';
import { useAuthStore } from '../../stores/authStore';

// =============================================================================
// COMPONENT
// =============================================================================

export default function LoginScreen() {
  const { colors } = useTheme();
  const setAuth = useAuthStore((s) => s.setAuth);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const passwordInputRef = useRef<RNTextInput>(null);

  const { mutate, isPending, error } = useMutation<
    LoginResponse,
    Error,
    LoginCredentials
  >({
    mutationFn: login,
    onSuccess: (data) => {
      setAuth(data.user, data.accessToken);
    },
  });

  const handleSubmit = useCallback(() => {
    if (!email.trim() || !password) return;
    mutate({ email: email.trim(), password });
  }, [email, password, mutate]);

  const handleEmailSubmit = useCallback(() => {
    passwordInputRef.current?.focus();
  }, []);

  const togglePasswordVisibility = useCallback(() => {
    setShowPassword((prev) => !prev);
  }, []);

  const isFormValid = email.trim().length > 0 && password.length > 0;

  return (
    <ScreenContainer keyboardAvoiding centerContent>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        {/* Logo and header */}
        <View style={styles.header}>
          <View
            style={[
              styles.logoContainer,
              { backgroundColor: colors.primaryMuted },
            ]}
          >
            <Ionicons name="medical" size={40} color={colors.primary} />
          </View>
          <Text variant="h1" align="center" style={styles.title}>
            MediSync
          </Text>
          <Text variant="body" color="secondary" align="center">
            Connectez-vous pour accéder à votre planning et vos patients.
          </Text>
        </View>

        {/* Login form */}
        <Card variant="outlined" padding="lg" style={styles.formCard}>
          <Stack gap="lg">
            {/* Email input */}
            <Input
              label="Email"
              placeholder="exemple@mail.com"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete="email"
              returnKeyType="next"
              onSubmitEditing={handleEmailSubmit}
              iconLeft={
                <Ionicons
                  name="mail-outline"
                  size={20}
                  color={colors.textTertiary}
                />
              }
            />

            {/* Password input */}
            <Input
              ref={passwordInputRef}
              label="Mot de passe"
              placeholder="Votre mot de passe"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete="password"
              returnKeyType="done"
              onSubmitEditing={handleSubmit}
              iconLeft={
                <Ionicons
                  name="lock-closed-outline"
                  size={20}
                  color={colors.textTertiary}
                />
              }
              iconRight={
                <Ionicons
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color={colors.textTertiary}
                />
              }
              onPressIconRight={togglePasswordVisibility}
            />

            {/* Error message */}
            {error && (
              <View
                style={[
                  styles.errorContainer,
                  { backgroundColor: colors.dangerMuted },
                ]}
              >
                <Ionicons
                  name="alert-circle"
                  size={18}
                  color={colors.danger}
                  style={styles.errorIcon}
                />
                <Text variant="bodySmall" style={{ color: colors.danger, flex: 1 }}>
                  Identifiants invalides ou erreur de connexion. Veuillez réessayer.
                </Text>
              </View>
            )}

            {/* Submit button */}
            <Button
              label={isPending ? 'Connexion en cours...' : 'Se connecter'}
              onPress={handleSubmit}
              loading={isPending}
              disabled={!isFormValid || isPending}
              fullWidth
              size="lg"
            />
          </Stack>
        </Card>

        {/* Footer */}
        <View style={styles.footer}>
          <Text variant="caption" color="tertiary" align="center">
            Application sécurisée pour professionnels de santé
          </Text>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xxl,
  },
  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  title: {
    marginBottom: spacing.sm,
  },
  formCard: {
    marginBottom: spacing.xl,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: spacing.md,
    borderRadius: 8,
  },
  errorIcon: {
    marginRight: spacing.sm,
    marginTop: 1,
  },
  footer: {
    paddingHorizontal: spacing.lg,
  },
});
