// src/screens/messages/MessagesListScreen.tsx
import React from 'react'
import { FlatList, TouchableOpacity, StyleSheet } from 'react-native'
import Screen from '../../components/layout/Screen'
import AppText from '../../components/ui/AppText'
import LoadingState from '../../components/feedback/LoadingState'
import ErrorState from '../../components/feedback/ErrorState'
import MessageRow from '../../components/messages/MessageRow'
import { useMessagesQuery } from '../../features/messages/hooks'
import type { Message } from '../../features/messages/types'
import { useNavigation } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { MessagesStackParamList } from '../../navigation/types'

type Nav = NativeStackNavigationProp<MessagesStackParamList, 'MessagesList'>

export default function MessagesListScreen() {
  const { data, isLoading, error, refetch } = useMessagesQuery()
  const navigation = useNavigation<Nav>()

  if (isLoading) {
    return (
      <Screen>
        <LoadingState message="Chargement des messages..." />
      </Screen>
    )
  }

  if (error) {
    return (
      <Screen>
        <ErrorState
          message="Impossible de charger les messages."
          onRetry={refetch}
        />
      </Screen>
    )
  }

  const messages = data ?? []

  const renderItem = ({ item }: { item: Message }) => (
    <TouchableOpacity
      onPress={() =>
        navigation.navigate('MessageDetail', { messageId: item.id })
      }
      activeOpacity={0.7}
      style={styles.itemContainer}
    >
      <MessageRow message={item} />
    </TouchableOpacity>
  )

  return (
    <Screen>
      <AppText style={styles.title}>Messagerie</AppText>

      {messages.length === 0 ? (
        <ErrorState message="Aucun message pour le moment." />
      ) : (
        <FlatList
          data={messages}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 16 }}
        />
      )}
    </Screen>
  )
}

const styles = StyleSheet.create({
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 16,
  },
  itemContainer: {
    marginBottom: 8,
  },
})
