// src/screens/messages/MessageDetailScreen.tsx
import React from 'react'
import { RouteProp, useRoute } from '@react-navigation/native'
import Screen from '../../components/layout/Screen'
import AppText from '../../components/ui/AppText'
import LoadingState from '../../components/feedback/LoadingState'
import ErrorState from '../../components/feedback/ErrorState'
import Card from '../../components/ui/Card'
import { useTheme } from '../../theme/ThemeProvider'
import { MessagesStackParamList } from '../../navigation/types'
import { useMessageQuery } from '../../features/messages/hooks'

type DetailRouteProp = RouteProp<MessagesStackParamList, 'MessageDetail'>

export default function MessageDetailScreen() {
  const route = useRoute<DetailRouteProp>()
  const { messageId } = route.params
  const { colors } = useTheme()

  const { data, isLoading, error, refetch } = useMessageQuery(messageId)

  if (isLoading) {
    return (
      <Screen>
        <LoadingState message="Chargement du message..." />
      </Screen>
    )
  }

  if (error || !data) {
    return (
      <Screen>
        <ErrorState
          message="Impossible de charger ce message."
          onRetry={refetch}
        />
      </Screen>
    )
  }

  return (
    <Screen>
      <AppText
        style={{
          fontSize: 22,
          fontWeight: '700',
          marginBottom: 16,
          color: colors.text,
        }}
      >
        Message
      </AppText>

      <Card>
        <AppText style={{ fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
          {data.subject}
        </AppText>
        <AppText style={{ color: colors.muted, marginBottom: 8 }}>
          De {data.senderName}
        </AppText>

        <AppText style={{ lineHeight: 20 }}>{data.body}</AppText>
      </Card>
    </Screen>
  )
}
