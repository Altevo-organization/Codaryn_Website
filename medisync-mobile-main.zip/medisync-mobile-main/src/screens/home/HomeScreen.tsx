/**
 * HomeScreen (Dashboard)
 *
 * Overview of today's activity: appointments, patients, documents.
 * Redesigned with MediSync design system.
 */

import React, { useCallback } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import * as Linking from 'expo-linking';

import {
  ScreenContainer,
  Row,
  Stack,
  Text,
  Card,
  Badge,
  Avatar,
  EmptyState,
  SkeletonCard,
  SkeletonListItem,
  Divider,
  spacing,
  radius,
  useTheme,
} from '../../ui';
import { useAppointmentsQuery } from '../../features/appointments/hooks';
import type { AppointmentsByDate } from '../../features/appointments/types';
import { usePatientsQuery } from '../../features/patients/hooks';
import type { Patient } from '../../features/patients/types';
import { useRecentFilesQuery } from '../../features/files/hooks';
import type { FileItem } from '../../features/files/types';
import { buildDownloadUrl } from '../../features/files/api';

// =============================================================================
// HELPERS
// =============================================================================

function todayISODate(): string {
  return new Date().toISOString().split('T')[0];
}

function formatTime(dateString: string): string {
  const d = new Date(dateString);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatShortDate(dateString: string): string {
  const d = new Date(dateString);
  if (Number.isNaN(d.getTime())) return dateString;
  return d.toLocaleDateString('fr-FR', {
    weekday: 'short',
    day: '2-digit',
    month: '2-digit',
  });
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Bonjour';
  if (hour < 18) return 'Bon après-midi';
  return 'Bonsoir';
}

// =============================================================================
// COMPONENT
// =============================================================================

export default function HomeScreen() {
  const { colors } = useTheme();
  const navigation = useNavigation<any>();
  const today = todayISODate();

  // Data fetching
  const {
    data: appointmentSections,
    isLoading: isLoadingAppointments,
    error: appointmentsError,
    refetch: refetchAppointments,
    isRefetching: isRefetchingAppointments,
  } = useAppointmentsQuery({
    limit: 50,
    sortBy: 'startDate',
    sortOrder: 'ASC',
    startDate: today,
  });

  const {
    data: patients,
    isLoading: isLoadingPatients,
    error: patientsError,
    refetch: refetchPatients,
    isRefetching: isRefetchingPatients,
  } = usePatientsQuery({
    limit: 5,
    sortBy: 'createdAt',
    sortOrder: 'DESC',
  });

  const {
    data: recentFiles,
    isLoading: isLoadingFiles,
    error: filesError,
    refetch: refetchFiles,
    isRefetching: isRefetchingFiles,
  } = useRecentFilesQuery(5);

  // Computed data
  const sections: AppointmentsByDate[] = appointmentSections ?? [];
  const todaysSection = sections.find((s) => s.date === today);
  const todaysAppointments = todaysSection?.appointments ?? [];
  const allUpcomingAppointments = sections.flatMap((s) => s.appointments);
  const nextAppointments = allUpcomingAppointments.slice(0, 3);
  const totalUpcoming = allUpcomingAppointments.length;
  const totalToday = todaysAppointments.length;

  const safePatients: Patient[] = patients ?? [];
  const safeFiles: FileItem[] = recentFiles ?? [];

  const isInitialLoading =
    isLoadingAppointments || isLoadingPatients || isLoadingFiles;
  const isRefreshing =
    isRefetchingAppointments || isRefetchingPatients || isRefetchingFiles;

  // Handlers
  const handleRefresh = useCallback(() => {
    refetchAppointments();
    refetchPatients();
    refetchFiles();
  }, [refetchAppointments, refetchPatients, refetchFiles]);

  const handleOpenFile = useCallback((fileId: number) => {
    const url = buildDownloadUrl(fileId);
    Linking.openURL(url).catch((err) => {
      console.error('[HomeScreen][OpenFile] error', err);
    });
  }, []);

  // Loading state
  if (isInitialLoading && !appointmentSections && !patients && !recentFiles) {
    return (
      <ScreenContainer>
        <View style={styles.header}>
          <Text variant="h1">{getGreeting()}</Text>
          <Text variant="body" color="secondary" style={styles.subtitle}>
            Vue d'ensemble de votre activité
          </Text>
        </View>
        <Stack gap="md">
          <SkeletonCard height={100} />
          <SkeletonCard height={100} />
          <SkeletonListItem />
          <SkeletonListItem />
        </Stack>
      </ScreenContainer>
    );
  }

  // Error state
  if (appointmentsError || patientsError || filesError) {
    return (
      <ScreenContainer centerContent>
        <EmptyState
          icon="alert-circle-outline"
          title="Erreur de chargement"
          description="Impossible de charger le tableau de bord. Vérifiez votre connexion."
          actionLabel="Réessayer"
          onAction={handleRefresh}
        />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer
      scrollable
      refreshing={isRefreshing}
      onRefresh={handleRefresh}
      contentContainerStyle={styles.content}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text variant="h1">{getGreeting()}</Text>
        <Text variant="body" color="secondary" style={styles.subtitle}>
          Vue d'ensemble de votre activité
        </Text>
      </View>

      {/* Stats cards */}
      <View style={styles.statsRow}>
        <StatCard
          icon="calendar-outline"
          label="Aujourd'hui"
          value={totalToday}
          hint="rendez-vous"
          color={colors.primary}
          backgroundColor={colors.primaryMuted}
          colors={colors}
        />
        <StatCard
          icon="time-outline"
          label="À venir"
          value={totalUpcoming}
          hint="total"
          color={colors.success}
          backgroundColor={colors.successMuted}
          colors={colors}
        />
      </View>

      {/* Upcoming appointments */}
      <SectionHeader
        title="Prochains rendez-vous"
        actionLabel="Voir le planning"
        onAction={() => navigation.navigate('Planning')}
        colors={colors}
      />

      {nextAppointments.length === 0 ? (
        <Card variant="outlined" padding="md">
          <Text variant="body" color="secondary" align="center">
            Aucun rendez-vous planifié.
          </Text>
        </Card>
      ) : (
        <Stack gap="sm">
          {nextAppointments.map((appt) => {
            const isToday = appt.startDate.startsWith(today);
            return (
              <AppointmentCard
                key={appt.id}
                patientName={appt.patientName ?? 'Patient inconnu'}
                time={formatTime(appt.startDate)}
                date={isToday ? "Aujourd'hui" : formatShortDate(appt.startDate)}
                isToday={isToday}
                colors={colors}
              />
            );
          })}
        </Stack>
      )}

      {/* Recent patients */}
      <SectionHeader
        title="Derniers patients"
        actionLabel="Voir la liste"
        onAction={() => navigation.navigate('Dossier')}
        colors={colors}
        style={styles.sectionMargin}
      />

      {safePatients.length === 0 ? (
        <Card variant="outlined" padding="md">
          <Text variant="body" color="secondary" align="center">
            Aucun patient enregistré.
          </Text>
        </Card>
      ) : (
        <Stack gap="sm">
          {safePatients.map((p) => (
            <PatientCard
              key={p.id}
              patient={p}
              onPress={() => navigation.navigate('Dossier')}
              colors={colors}
            />
          ))}
        </Stack>
      )}

      {/* Recent documents */}
      <SectionHeader
        title="Derniers documents"
        style={styles.sectionMargin}
        colors={colors}
      />

      {safeFiles.length === 0 ? (
        <Card variant="outlined" padding="md">
          <Text variant="body" color="secondary" align="center">
            Aucun document récent.
          </Text>
        </Card>
      ) : (
        <Stack gap="sm">
          {safeFiles.map((file) => (
            <FileCard
              key={file.id}
              file={file}
              onPress={() => handleOpenFile(file.id)}
              colors={colors}
            />
          ))}
        </Stack>
      )}
    </ScreenContainer>
  );
}

// =============================================================================
// SUB-COMPONENTS
// =============================================================================

interface StatCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: number;
  hint: string;
  color: string;
  backgroundColor: string;
  colors: ReturnType<typeof useTheme>['colors'];
}

function StatCard({
  icon,
  label,
  value,
  hint,
  color,
  backgroundColor,
  colors,
}: StatCardProps) {
  return (
    <Card variant="outlined" padding="md" style={styles.statCard}>
      <Row gap="md" align="center">
        <View
          style={[
            styles.statIconContainer,
            { backgroundColor },
          ]}
        >
          <Ionicons name={icon} size={22} color={color} />
        </View>
        <View style={styles.statContent}>
          <Text variant="caption" color="secondary">
            {label}
          </Text>
          <Row gap="xs" align="baseline">
            <Text variant="h2" style={{ color }}>
              {value}
            </Text>
            <Text variant="bodySmall" color="tertiary">
              {hint}
            </Text>
          </Row>
        </View>
      </Row>
    </Card>
  );
}

interface SectionHeaderProps {
  title: string;
  actionLabel?: string;
  onAction?: () => void;
  style?: any;
  colors: ReturnType<typeof useTheme>['colors'];
}

function SectionHeader({
  title,
  actionLabel,
  onAction,
  style,
  colors,
}: SectionHeaderProps) {
  return (
    <Row
      justify="space-between"
      align="center"
      style={[styles.sectionHeader, style]}
    >
      <Text variant="h4">{title}</Text>
      {actionLabel && onAction && (
        <TouchableOpacity onPress={onAction} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text variant="bodySmall" style={{ color: colors.link }}>
            {actionLabel}
          </Text>
        </TouchableOpacity>
      )}
    </Row>
  );
}

interface AppointmentCardProps {
  patientName: string;
  time: string;
  date: string;
  isToday: boolean;
  colors: ReturnType<typeof useTheme>['colors'];
}

function AppointmentCard({
  patientName,
  time,
  date,
  isToday,
  colors,
}: AppointmentCardProps) {
  return (
    <Card variant="outlined" padding="md">
      <Row gap="md" align="center">
        <View
          style={[
            styles.timeIndicator,
            { backgroundColor: isToday ? colors.primaryMuted : colors.backgroundTertiary },
          ]}
        >
          <Ionicons
            name="time-outline"
            size={14}
            color={isToday ? colors.primary : colors.textSecondary}
          />
          <Text
            variant="labelSmall"
            style={{
              color: isToday ? colors.primary : colors.textSecondary,
              marginTop: 2,
            }}
          >
            {time}
          </Text>
        </View>
        <View style={styles.appointmentContent}>
          <Text variant="label" numberOfLines={1}>
            {patientName}
          </Text>
          <Text variant="caption" color="tertiary">
            {date}
          </Text>
        </View>
        {isToday && (
          <Badge label="Aujourd'hui" variant="primary" size="sm" />
        )}
      </Row>
    </Card>
  );
}

interface PatientCardProps {
  patient: Patient;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>['colors'];
}

function PatientCard({ patient, onPress, colors }: PatientCardProps) {
  const fullName = `${patient.firstName} ${patient.lastName}`;

  return (
    <Card variant="outlined" padding="md" onPress={onPress}>
      <Row gap="md" align="center">
        <Avatar name={fullName} size="sm" />
        <View style={styles.patientContent}>
          <Text variant="label" numberOfLines={1}>
            {patient.lastName.toUpperCase()} {patient.firstName}
          </Text>
          <Text variant="caption" color="tertiary" numberOfLines={1}>
            {patient.disease}
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
      </Row>
    </Card>
  );
}

interface FileCardProps {
  file: FileItem;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>['colors'];
}

function FileCard({ file, onPress, colors }: FileCardProps) {
  const getFileIcon = (type: string): keyof typeof Ionicons.glyphMap => {
    const lower = type.toLowerCase();
    if (lower.includes('pdf')) return 'document-text-outline';
    if (lower.includes('image') || lower.includes('jpg') || lower.includes('png'))
      return 'image-outline';
    return 'document-outline';
  };

  return (
    <Card variant="outlined" padding="md" onPress={onPress}>
      <Row gap="md" align="center">
        <View
          style={[
            styles.fileIconContainer,
            { backgroundColor: colors.backgroundTertiary },
          ]}
        >
          <Ionicons
            name={getFileIcon(file.type)}
            size={20}
            color={colors.textSecondary}
          />
        </View>
        <View style={styles.fileContent}>
          <Text variant="label" numberOfLines={1}>
            {file.name}
          </Text>
          <Text variant="caption" color="tertiary">
            {file.type} • {formatShortDate(file.createdAt)}
          </Text>
        </View>
        <Ionicons name="open-outline" size={18} color={colors.textTertiary} />
      </Row>
    </Card>
  );
}

// =============================================================================
// STYLES
// =============================================================================

const styles = StyleSheet.create({
  content: {
    paddingBottom: spacing.xxxl,
  },
  header: {
    paddingTop: spacing.sm,
    marginBottom: spacing.xl,
  },
  subtitle: {
    marginTop: spacing.xs,
  },
  statsRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  statCard: {
    flex: 1,
  },
  statIconContainer: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statContent: {
    flex: 1,
  },
  sectionHeader: {
    marginBottom: spacing.md,
  },
  sectionMargin: {
    marginTop: spacing.xl,
  },
  timeIndicator: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 8,
    alignItems: 'center',
    minWidth: 50,
  },
  appointmentContent: {
    flex: 1,
  },
  patientContent: {
    flex: 1,
  },
  fileIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fileContent: {
    flex: 1,
  },
});
