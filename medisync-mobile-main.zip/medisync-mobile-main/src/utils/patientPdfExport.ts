// src/utils/patientPdfExport.ts
import * as Print from 'expo-print'
import * as Sharing from 'expo-sharing'
import { Platform } from 'react-native'
import type { Patient } from '../features/patients/types'

// ============================================================================
// UTILS
// ============================================================================

function computeBMI(heightCm: number | null, weightKg: number | null): number | null {
  if (heightCm === null || weightKg === null) return null
  if (heightCm <= 0 || weightKg <= 0) return null
  const heightM = heightCm / 100
  const bmi = weightKg / (heightM * heightM)
  return Math.round(bmi * 10) / 10
}

function getBMICategory(bmi: number | null): string {
  if (bmi === null) return ''
  if (bmi < 18.5) return 'Insuffisance pondérale'
  if (bmi < 25) return 'Poids normal'
  if (bmi < 30) return 'Surpoids'
  return 'Obésité'
}

function formatDate(dateString: string): string {
  if (!dateString) return '—'
  const parts = dateString.split('-')
  if (parts.length !== 3) return dateString
  return `${parts[2]}/${parts[1]}/${parts[0]}`
}

function formatExportDate(): string {
  const now = new Date()
  const day = String(now.getDate()).padStart(2, '0')
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const year = now.getFullYear()
  return `${day}-${month}-${year}`
}

function escapeHtml(text: string | undefined | null): string {
  if (!text) return '—'
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    .replace(/\n/g, '<br>')
}

function sanitizeFileName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .replace(/_+/g, '_')
}

// ============================================================================
// HTML TEMPLATE
// ============================================================================

function generatePdfHtml(patient: Patient, exportDate: string): string {
  const bmi = computeBMI(patient.height, patient.weight)
  const bmiDisplay = bmi !== null ? bmi.toFixed(1) : '—'
  const bmiCategory = getBMICategory(bmi)

  return `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dossier Patient - ${escapeHtml(patient.lastName)} ${escapeHtml(patient.firstName)}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      font-size: 11pt;
      line-height: 1.5;
      color: #1e293b;
      padding: 40px;
      background: #fff;
    }

    /* Header */
    .header {
      border-bottom: 3px solid #6366f1;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }

    .header-title {
      font-size: 24pt;
      font-weight: 700;
      color: #6366f1;
      margin-bottom: 8px;
      letter-spacing: -0.5px;
    }

    .header-patient {
      font-size: 18pt;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 4px;
    }

    .header-date {
      font-size: 10pt;
      color: #64748b;
    }

    /* Sections */
    .section {
      margin-bottom: 28px;
      page-break-inside: avoid;
    }

    .section-title {
      font-size: 10pt;
      font-weight: 600;
      color: #6366f1;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      margin-bottom: 14px;
      padding-bottom: 8px;
      border-bottom: 1px solid #e2e8f0;
    }

    /* Grid layout for info */
    .info-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
    }

    .info-grid-2 {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }

    .info-item {
      background: #f8fafc;
      border-radius: 8px;
      padding: 12px 14px;
      border-left: 3px solid #e2e8f0;
    }

    .info-item.highlight {
      border-left-color: #6366f1;
      background: #f1f5f9;
    }

    .info-label {
      font-size: 9pt;
      font-weight: 500;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }

    .info-value {
      font-size: 12pt;
      font-weight: 500;
      color: #1e293b;
    }

    .info-value.large {
      font-size: 16pt;
      font-weight: 600;
    }

    .info-subtext {
      font-size: 9pt;
      color: #64748b;
      margin-top: 2px;
    }

    /* Text blocks */
    .text-block {
      margin-bottom: 16px;
    }

    .text-block-label {
      font-size: 9pt;
      font-weight: 600;
      color: #475569;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
    }

    .text-block-value {
      background: #f8fafc;
      border-radius: 8px;
      padding: 14px 16px;
      font-size: 11pt;
      color: #334155;
      border: 1px solid #e2e8f0;
    }

    /* BMI card */
    .bmi-card {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border-radius: 10px;
      padding: 16px;
      text-align: center;
      border: 1px solid #bae6fd;
    }

    .bmi-value {
      font-size: 28pt;
      font-weight: 700;
      color: #0369a1;
    }

    .bmi-label {
      font-size: 9pt;
      font-weight: 600;
      color: #0369a1;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .bmi-category {
      font-size: 10pt;
      color: #0284c7;
      margin-top: 4px;
    }

    /* Footer */
    .footer {
      margin-top: 40px;
      padding-top: 16px;
      border-top: 1px solid #e2e8f0;
      font-size: 9pt;
      color: #94a3b8;
      text-align: center;
    }

    /* Dates row */
    .dates-row {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
      margin-bottom: 16px;
    }
  </style>
</head>
<body>

  <!-- En-tête -->
  <div class="header">
    <div class="header-title">Dossier Patient</div>
    <div class="header-patient">${escapeHtml(patient.lastName)?.toUpperCase()} ${escapeHtml(patient.firstName)}</div>
    <div class="header-date">Exporté le ${exportDate}</div>
  </div>

  <!-- Section 1: Informations générales -->
  <div class="section">
    <div class="section-title">Informations générales</div>
    <div style="display: flex; gap: 20px;">
      <div style="flex: 1;">
        <div class="info-grid" style="margin-bottom: 12px;">
          <div class="info-item highlight">
            <div class="info-label">Nom</div>
            <div class="info-value">${escapeHtml(patient.lastName)?.toUpperCase()}</div>
          </div>
          <div class="info-item highlight">
            <div class="info-label">Prénom</div>
            <div class="info-value">${escapeHtml(patient.firstName)}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Âge</div>
            <div class="info-value">${patient.age ?? '—'} ans</div>
          </div>
        </div>
        <div class="info-grid-2">
          <div class="info-item">
            <div class="info-label">Taille</div>
            <div class="info-value">${patient.height ?? '—'} cm</div>
          </div>
          <div class="info-item">
            <div class="info-label">Poids</div>
            <div class="info-value">${patient.weight ?? '—'} kg</div>
          </div>
        </div>
      </div>
      <div class="bmi-card" style="width: 120px; flex-shrink: 0;">
        <div class="bmi-label">IMC</div>
        <div class="bmi-value">${bmiDisplay}</div>
        ${bmiCategory ? `<div class="bmi-category">${bmiCategory}</div>` : ''}
      </div>
    </div>
  </div>

  <!-- Section 2: Pathologie -->
  <div class="section">
    <div class="section-title">Pathologie</div>

    <div class="text-block">
      <div class="text-block-label">Antécédents médicaux</div>
      <div class="text-block-value">${escapeHtml(patient.disease)}</div>
    </div>

    <div class="text-block">
      <div class="text-block-label">Antécédents chirurgicaux</div>
      <div class="text-block-value">${escapeHtml(patient.symptoms)}</div>
    </div>

    <div class="text-block">
      <div class="text-block-label">Diagnostic médical</div>
      <div class="text-block-value">${escapeHtml(patient.treatment)}</div>
    </div>

    <div class="dates-row">
      <div class="info-item">
        <div class="info-label">Date du diagnostic</div>
        <div class="info-value">${formatDate(patient.diagnosisDate)}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Dernière visite</div>
        <div class="info-value">${formatDate(patient.lastVisit)}</div>
      </div>
    </div>

    <div class="text-block">
      <div class="text-block-label">Médicaments en cours</div>
      <div class="text-block-value">${escapeHtml(patient.medications)}</div>
    </div>
  </div>

  <!-- Section 3: Suivi clinique -->
  <div class="section">
    <div class="section-title">Suivi clinique</div>

    ${patient.additionalInfo ? `
    <div class="text-block">
      <div class="text-block-label">Informations complémentaires</div>
      <div class="text-block-value">${escapeHtml(patient.additionalInfo)}</div>
    </div>
    ` : ''}

    ${patient.observations ? `
    <div class="text-block">
      <div class="text-block-label">Observations</div>
      <div class="text-block-value">${escapeHtml(patient.observations)}</div>
    </div>
    ` : ''}

    ${patient.nurse ? `
    <div class="info-item" style="max-width: 300px;">
      <div class="info-label">Infirmier(ère) référent(e)</div>
      <div class="info-value">${escapeHtml(patient.nurse)}</div>
    </div>
    ` : ''}

    ${!patient.additionalInfo && !patient.observations && !patient.nurse ? `
    <div class="text-block-value" style="color: #94a3b8; font-style: italic;">
      Aucune information de suivi renseignée.
    </div>
    ` : ''}
  </div>

  <!-- Footer -->
  <div class="footer">
    MediSync - Dossier médical confidentiel - ${exportDate}
  </div>

</body>
</html>
`
}

// ============================================================================
// EXPORT FUNCTION
// ============================================================================

export interface ExportPdfResult {
  success: boolean
  error?: string
}

export async function exportPatientPdf(patient: Patient): Promise<ExportPdfResult> {
  try {
    const exportDate = formatExportDate()
    const html = generatePdfHtml(patient, exportDate)

    // Build file name for sharing dialog
    const lastName = sanitizeFileName(patient.lastName || 'Patient')
    const firstName = sanitizeFileName(patient.firstName || '')
    const fileName = `Dossier_patient_${lastName}_${firstName}_${exportDate}.pdf`

    // Generate PDF directly with the desired filename
    const { uri } = await Print.printToFileAsync({
      html,
      base64: false,
    })

    // Check if sharing is available
    const isSharingAvailable = await Sharing.isAvailableAsync()

    if (isSharingAvailable) {
      // Share the PDF - the dialogTitle helps suggest the filename
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: fileName,
        UTI: 'com.adobe.pdf',
      })
      return { success: true }
    } else {
      // Fallback for platforms without sharing (rare)
      if (Platform.OS === 'web') {
        // Web: open in new tab
        window.open(uri, '_blank')
        return { success: true }
      }
      return {
        success: false,
        error: 'Le partage de fichiers n\'est pas disponible sur cet appareil.',
      }
    }
  } catch (error) {
    console.error('Error exporting patient PDF:', error)
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Erreur lors de l\'export du PDF.',
    }
  }
}
